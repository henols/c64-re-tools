#!/bin/sh
# Builds the clean Bruce Lee program from the generated source in src/.
#
#   build/game.prg        main.asm, checked byte by byte against unpacked/clean/image.json
#   build/bruce_lee.prg   the runnable program: src/loader.asm with one fix (see below)
#
# The fix: the generated loader stub copies its copier from the end of the PRG,
# which lies above $A000 because the game is about 46 KB. With BASIC ROM banked in,
# those reads return ROM bytes. The stub here switches BASIC ROM out first
# ($01 = $34); the copier then sets $01 from the entry state as before.
# src/ stays as c64-source generated it.
set -e
cd "$(dirname "$0")/.."
SKILLS=../.claude/skills
mkdir -p build build/src
rm -f build/src/*.asm
cp src/*.asm build/src/
python3 - <<'EOF'
import re
text = open('src/loader.asm').read()
stub = '!zone loader_stub {\n        sei\n'
assert text.count(stub) == 1, 'loader stub not found: c64-source changed its loader'
text = text.replace(stub, stub + '        lda #$34                        ; all RAM: the copier source is above $A000\n        sta $01\n')
open('build/src/bruce_lee.asm', 'w').write(text)
EOF
node $SKILLS/c64-assembler/scripts/assemble.ts --source-root src --entry main.asm --out build/game.prg \
  --compare unpacked/clean/image.json > build/game.json
node $SKILLS/c64-assembler/scripts/assemble.ts --source-root build/src --entry bruce_lee.asm \
  --out build/bruce_lee.prg > build/bruce_lee.json
python3 -c "
import json
g = json.load(open('build/game.json')); b = json.load(open('build/bruce_lee.json'))
print('game.prg      assembled:', g['assembled'], ' identical to clean image:', g['compare']['identical'])
print('bruce_lee.prg assembled:', b['assembled'], ' load range:', b['loadRange'])
"
