# Rooms 10-19: the room state machines

This part documents what makes rooms 10 to 19 change while Bruce plays in them: the init handler that runs when a room is drawn, the frame handler that runs on every main-loop pass, and the conditions, often in other rooms, that move each room from one state to the next.

The room-level flow that all rooms share is in [room_flow.md](room_flow.md): room entry, lanterns, death and respawn, the player change, enemy spawning and the end of the game.

## 0. Conventions and evidence

**Names.** Every address has its knowledge name. Labels that the batch `.c64-re-tools/local/batch_rooms_10_19.json` adds are written with their new name and their address, for example `room17_slider_tick` `$3F8C`.

**One pass.** `main_loop` `$1BC2` sets `frame_countdown` `$48` to 3 and waits for the raster IRQ to count it down to 0. A pass therefore takes at least 3 video frames, or 60 ms on PAL. The room frame handler is called once per pass by `run_room_update` `$3A6F`. All handler timings below are given in passes.

**Positions.** The room handlers draw with `print_message` `$17E2`, where A is the message number, X a **text row** and Y the column. One text row is one map row of 8x16 cells. The mapping is:
- text row `t` covers screen rows `2t-1` (top chars) and `2t` (bottom chars);
- map row = `t - 2`, as in the lantern records.

Message numbers are given in decimal with their hex value, for example "message 99 (`$63`)". The tiles a message draws are from `assets/text/messages.json`. A message draws each tile `c` as char `c` in the top row and `c|$80` in the bottom row, and it does not change colour RAM.

**Evidence labels.**
- **Observed:** seen in a run. The runs are listed below.
- **Code:** read from the code only. No run reached that code, or a run reached it but did not show the effect.

**Runs used.**

| Run | What was done | Files |
|---|---|---|
| `room_events` | Started from `runs/rooms/roomNN.vsf`. All 20 bytes of `room_lanterns_left` `$2A-$3D` were set to 0, then 100 and 400 frames were run. The lantern **records** were not changed. | `.c64-re-tools/local/room_events_diffs.json`, `runs/room_events/rNN_*.png`, coverage `evNN.bin` |
| `room_special` / wizard | Room 18 snapshot. `$4E86` (the state of the wizard's lantern record) and `room_lanterns_left+18` were set to 0, then 100 and 400 frames were run. | `.c64-re-tools/local/room_special_diffs.json`, `runs/room_special/w_t*.png`, `wizard.bin`, `wizard_defeated.vsf` |
| `room_special` / room 11 | From room 0, `room_lanterns_left+12/+14/+16` were set to 0, and room 11 was entered by forcing A=11 at `$2FA1`. The run was compared with a normal entry. | `r11_special*.png`, `room11_special.bin`, `room11_normal.bin` |
| `room_special` / ending | Room 19 snapshot, run for 200, 1000 and 2500 frames. | `e_t*.png`, `ending.bin` |
| `room_events2` | From `runs/explore3/room0.vsf`, each room was entered through `enter_room` (A forced at `$2FA1`) twice: normally (n) and with **every lantern record state and every `room_lanterns_left` byte set to 0** (c). Cell diffs n→c at t60 and c t60→t400, and `room_script_vars` at t400. | `.c64-re-tools/local/room_events2_diffs.json`, `runs/room_events2/nNN.png`, `cNN_t60/t400.png`, coverage `allNN.bin` |

**Important limit of the `room_events` runs.** Most handlers of rooms 10-17 test the **state byte of single lantern records**, not the counters in `room_lanterns_left`. Setting the counters to 0 therefore triggers only the events that test a counter: room 15 (its third event) and room 16. The `room_events2` run (c) zeroed the records too and triggered all the lantern events at once; it shows the end state of each room, not the order of the events.

## 1. Building blocks shared by the handlers

### 1.1 `room_script_vars` `$4E97-$4E9B`: five bytes of room state

`redraw_taken_lanterns` `$336E` sets these five bytes to 0 every time a room is drawn, at `dispatch_room_init` `$33B3`. The room init handler runs next and can preset them. They are not saved per player.

Rooms 10-17 use them as **one-shot flags**: an event fires while its flag is not negative (`bmi`) or not zero (`beq`), and the event decrements the flag.

What makes the events persistent is that their **conditions** are persistent: lantern record states and the counters in `room_lanterns_left`. On every later entry the flags are 0 again, so the handler fires the event again on the first pass and redraws the changed tiles over the freshly drawn map. A room therefore always looks as its lantern state says. This is a conclusion from the code; the room 16 run shows it (section 8).

**Double firing (Code; Observed in room 15).** Rooms 12, 14 and 15 preset some flags to 1, and test them with `bmi`. So 1 → 0 fires once, then 0 → `$FF` fires a second time. These events draw their tiles twice and play sound `$8A` twice on two passes in a row. Room 15, event C, was observed going `01 → FF`. Room 17 uses `beq` with a preset of 1, so it fires once.

### 1.2 Drawing helpers

| Routine | Address | What it draws |
|---|---|---|
| `draw_column_63_64` | `$3AB4` | Sound `$8A` (`play_sound_8a` `$424F`), then message 99 (`$63`, tile `$07`) at text rows A and A+1, and message 100 (`$64`, tile `$0E`) at text row A+2, all at column Y, through `draw_tile_down` `$3AD4`. Every time rooms 10-16 use it, it replaces a wall column of `$45` cells (`$C5` in the map: tile `$45` with colour `$F8`) by an open passage `$07`, `$07`, `$0E`. Behind the passage lies an exit cell. **The knowledge comment says "tiles $63, $63, $64"; those are message numbers.** |
| `draw_sliding_tile` | `$404E` | Sound `$89`, message 28 (`$1C`, tile `$65`) at the previous column `slider_prev_col` `$70`, then message 27 (`$1B`, tile `$64`) at the new column `slider_col` `$6E`, on text row `slider_row` `$6F`. |
| `draw_sliding_tile_alt` | `$4063` | The same with message 85 (`$55`, tile `$67`) at the old column and message 84 (`$54`, tile `$66`) at the new one. |
| `draw_hazard0/1/2_frame` | `$4086`/`$4090`/`$409A` | Message `$1F+A` (31-37) at `hazard_row+n` `$74+n`, `hazard_col+n` `$71+n`. |
| `animate_floor_traps` | `$3228` | The three floor-trap slots (see [room_flow.md](room_flow.md) section 6.3). |
| `animate_scrolling_chars` | `$2C70` | The moving climbing-texture chars (`scroll_direction` `$65`, `anim_speed_index` `$4321`). |

**Deadly chars.** `handle_touched_char` `$2E89` treats these chars as deadly: `$0F`, `$40`, `$54-$5A` except `$57`, `$64`, `$71-$7C`, and `$66` from room 10 on. Bruce dies when he touches them with contact bit 1 of `actor_contact` `$B6` set. So:
- the sliding tiles `$64`/`$66` of rooms 13 and 17 are deadly, and their trail tiles `$65`/`$67` are not;
- the travelling-hazard frames `$54`/`$55`/`$56` are deadly;
- the floor-trap spikes `$71-$7C` are deadly.

### 1.3 Room summary

| Room | Lanterns (count `$4CCE`) | Combat (`$4C9E`) | Init | Frame | Events |
|---|---|---|---|---|---|
| 10 | 3 | yes | `room_init_none` `$33F5` | `room10_update` `$3C90` | passage to the exit to room 11; protection check |
| 11 | 3 | no | `room_init_none` `$33F5` | `room11_update` `$3CC0` | texture reset; **`draw_room` diverts to room 13** |
| 12 | 3 | yes | `room12_init` `$34BD` | `room12_update` `$3E4C` | two passages (one depends on room 14) |
| 13 | 0 (dummy record) | no | `room13_init` `$34C3` | `room13_update` `$3E7C` | 8 deadly sliders; 500-point floor bonuses |
| 14 | 4 | yes | `room14_init` `$358D` | `room14_update` `$3ECC` | passage to the exit to room 11 |
| 15 | 6 | yes | `room15_init` `$3593` | `room15_update` `$3EE6` | two tower openings; the exit to room 17 |
| 16 | 2 | yes | `room16_init` `$359F` | `room16_update` `$3F5B` | passage to the exit to room 11; bonus-fall object |
| 17 | 2 | no | `room17_init` `$35C4` | `room17_update` `$3F71` | two mesh pieces; slider; 3 travelling hazards; blinking ceiling |
| 18 | 1 (the wizard) | no | `room18_init` `$35FA` | `room18_wizard_update` `$3CDC` | wizard face, fireballs, defeat, exit to room 19 |
| 19 | 0 (dummy record) | no | `room19_init` `$425F` | `room19_congratulations_update` `$4272` | congratulations, `game_cycle`+1, restart in room 0 |

"Combat: no" means `room_without_enemies` `$7A` is set: no enemy spawns, enemies do not follow Bruce in, and `check_sprite_collisions` `$29C3` is skipped.

### 1.4 Cross-room dependencies (Code)

```mermaid
flowchart LR
  R12c["room 12 counter $36 = 0"] --> R12B["room 12 event B: passage to the exit to room 11"]
  R14L34["room 14 lanterns 3,4 ($4E52,$4E56) taken"] --> R12B
  R12L3["room 12 lantern 3 ($4E40) taken"] --> R12A["room 12 event A: passage to the exit to room 14"]
  R12E["room 12 counter $36 = 0"] --> R11X
  R14E["room 14 counter $38 = 0"] --> R11X
  R16E["room 16 counter $3A = 0"] --> R11X["entering room 11 goes to room 13 (draw_room $09F6)"]
  R11X --> R13["room 13"]
  R13 --> R15["room 15"]
  R15c["room 15 counter $39 = 0"] --> R15C["room 15 exit to room 17 drawn"]
  R15C --> R17["room 17"]
  R17 --> R18["room 18"]
  R18L["wizard lantern $4E86 taken"] --> R18X["defeat, then exit to room 19 drawn"]
  R18X --> R19["room 19: game_cycle+1, back to room 0"]
```

The only way into room 13 is the room 11 diversion. Room 15's exit 2 also leads back to room 13. So rooms 13-19 are reached only after rooms 12, 14 and 16 have no lanterns left (Code; the diversion was Observed).

---

## 2. Room 10

**Layout** (`assets/rooms/room10.png`, map `room10_map` `$75D8`, charset 1): three corridors stacked on each other, with pillars.

| Exit | Trigger cell (map row, column) | Destination |
|---|---|---|
| char 2 | (9, 0), bottom left | room 3 at (160, 196) |
| char 3 | (3, 39), right; behind a wall column at column 38 | room 11 at (16, 196) |

**Lanterns** (`lantern_list_room10` `$4E1E`):

| # | Record | Column | Map row |
|---|---|---|---|
| 1 | `$4E1E` | 1 | 2 |
| 2 | `$4E22` | 30 | 5 |
| 3 | `$4E26` | 30 | 8 |

Room 10's map also holds `$2D`/`$2E` cells in map row 1. Those chars are the bonus-fall object only in room 16 (`touch_bonus_fall_chars` `$2EEA` tests for room 16), so they have no effect here.

**Init:** `room_init_none` `$33F5` (RTS).

**Frame handler** `room10_update` `$3C90`:

| Variable | Meaning |
|---|---|
| `room_script_vars+0` | One-shot flag of the passage: 0 armed, `$FF` done. |

1. **Event A.** If `room_script_vars+0` ≥ 0 and records `$4E1E` and `$4E22` are both 0 (lanterns 1 and 2 taken): decrement the flag, then `draw_column_63_64` with A=4, Y=`$26`. This plays sound `$8A` and draws tiles `$07`/`$07`/`$0E` at column 38, map rows 2-4, opening the way to the room 11 exit at (3, 39).
2. **Protection** `room10_check_cpu_port_ddr` `$3CA7`: reads `$00` (CPU port DDR) with `LDX $00,Y`. Unless it is `$EF`, `room10_sabotage_room_data` `$3CAF` writes `$80` (map end) into the first byte of `room00_map`, `room05_map` and `room01_map`, and jumps to `title_screen` `$0584`. This passes in this release.
3. `room10_animate_traps` `$3CBD` → `animate_floor_traps`.

```mermaid
stateDiagram-v2
  state "Passage closed (vars+0 = 0)" as Closed
  state "Passage open (vars+0 = $FF)" as Open
  [*] --> Closed: room drawn
  Closed --> Open: $4E1E = 0 and $4E22 = 0 / sound $8A, msg 99,99,100 at col 38 rows 4-6
  Open --> Open: every pass, floor traps
  Closed --> Title: $00 is not $EF / corrupt 3 maps
```

| From | Condition | To | Effect |
|---|---|---|---|
| Closed | lanterns 1 and 2 of room 10 taken | Open | sound `$8A`; message 99 at (text 4, col 38), 99 at (5, 38), 100 at (6, 38) |
| any | `$00` ≠ `$EF` | title | `$80` into `$68F9`, `$6F82`, `$6A09`; `jmp title_screen` |

**Evidence.**
- **Observed:** the handler and the floor traps ran (`ev10.bin`), and a floor trap fired: the cells at screen rows 11-12, columns 18/20 and 23/25 changed `$0D`→`$7D`. That is message 51 (`$7D $60 $7D`), drawn at step 20 of the trap animation. The flag stayed 0, as expected, because the records were not changed.
- **Observed (`room_events2`, c):** event A: column 38, screen rows 7-10 `$45`/`$C5` → `$07`/`$87` (message 100 at text row 6 matched the cell already there); `room_script_vars` = `FF 00 …` at t400; the three lanterns are drawn as their collected tile `$1F`. Between t60 and t400 a floor trap showed its spikes `$71-$76` at screen rows 9-12, columns 18-20.
- **Code:** the order of events and the sabotage path.

---

## 3. Room 11

**Layout** (`room11.png`, map `$774C`): a hub. A climbing-texture column runs at the left. Three doorways are at map row 5, columns 9-12, 18-21 and 27-30.

**Exits.** `check_exit_direction` `$30D4` returns "allowed" in room 11 without testing the direction, so touching a doorway cell is enough.

| Exit | Trigger cells | Destination |
|---|---|---|
| char 2 | (9, 0) | room 10 at (160, 90) |
| char 3 | (5, 9-12) | room 12 at (16, 92) |
| char 4 | (5, 18-21) | room 14 at (16, 94) |
| char 5 | (5, 27-30) | room 16 at (16, 92) |

**Lanterns** (`$4E2B`): (row 1, col 18) `$4E2B`, (1, 21) `$4E2F`, (8, 7) `$4E33`. No enemies (flag `$FF`).

### 3.1 The special path in `draw_room` `$09BC`

At `draw_room_special` `$09F6`, after the screen has been blanked and colour RAM filled:
- **Condition:** `current_room` = 11 and `room_lanterns_left+12`, `+14` and `+16` (`$36`, `$38`, `$3A`) are all 0.
- **Action:** restore `SPENA` from `saved_sprite_enable` `$47`, set X=13 (`$0A09`) and jump to `respawn_in_room` `$3217`.

`respawn_in_room` puts Bruce at room 13's spawn point (`room_spawn_x/y`: 152, 50) and calls `enter_room` `$2F8E` with destination 13. That draws room 13. Room 11 itself is then never drawn, it gets no entry bonus and its handler does not run.

Because every exit into room 11 (from rooms 10, 12, 14 and 16) goes through `draw_room`, room 11 is replaced by room 13 for the rest of this cycle. A respawn into room 11 after a lost fall is diverted the same way (Code).

**Observed** (`room_special` / room 11): `current_room` `$29` = `$0D` after the entry, the screen equals the room 13 map (row 0 `45 43 11 10 11 45 00 2d 2e …` = `room13.json` row 0 without bit 7), the coverage shows `$0A04-$0A0D` and `room13_update`, and the room 11 handler did not run. The "678 changed cells" are the room 13 layout.

### 3.2 Frame handler `room11_update` `$3CC0`

| Variable | Meaning |
|---|---|
| `room_script_vars+0` | One-shot flag. |

1. **Event A.** If the flag ≥ 0 and record `$4E33` = 0 (lantern 3 at (8, 7) taken): decrement the flag, then set `scroll_direction` `$65` = 0 and `anim_speed_index` `$4321` = 7. `draw_room` sets the same two values on entry. So the event only matters when `animate_scrolling_chars` has reversed the direction since the entry: it puts the texture animation back to forward at the start speed. It plays no sound and draws no tiles.
2. `room11_animate` `$3CD6`: `animate_floor_traps`, then `animate_scrolling_chars`.

```mermaid
stateDiagram-v2
  state "Diverted to room 13" as Div
  state "Texture free (vars+0 = 0)" as Free
  state "Texture reset done (vars+0 = $FF)" as Reset
  [*] --> Div: draw_room, $36 = $38 = $3A = 0
  [*] --> Free: draw_room, otherwise
  Free --> Reset: $4E33 = 0 / $65 = 0, $4321 = 7
```

| From | Condition | To | Effect |
|---|---|---|---|
| room entry | rooms 12, 14 and 16 have no lanterns left | room 13 | `respawn_in_room(13)` |
| Free | lantern 3 of room 11 taken | Reset | `scroll_direction`=0, `anim_speed_index`=7 |

**Evidence.**
- **Observed:** the diversion, in two runs (`room_special` and `room_events2` c: `current_room` 13 after entering room 11, 678 cells = the room 13 map). The handler ran in the `room_events` run with no change, because the counter, not the record, was zeroed.
- **Code:** event A (in `room_events2` c room 11 is never drawn).

---

## 4. Room 12

**Layout** (`room12.png`, map `$7843`): three floors. Two diagonal climbing slopes. A wall column at column 38.

| Exit | Trigger cell | Destination |
|---|---|---|
| char 3 | (6, 39) | room 11 at (52, 190) |
| char 4 | (9, 39) | room 14 at (16, 190) |

Code 2 has an entry x of 0, so a char-2 cell would fall through to group 3; the map has none.

**Lanterns** (`$4E38`): all at column 36, map rows 2 (`$4E38`), 5 (`$4E3C`) and 8 (`$4E40`).

**Init** `room12_init` `$34BD`: `room_script_vars+0` = 1.

**Frame handler** `room12_update` `$3E4C`:

| Variable | Meaning |
|---|---|
| `room_script_vars+0` | Event A flag. Preset 1, so A fires twice (1 → 0 → `$FF`). |
| `room_script_vars+1` | Event B flag (0 → `$FF`). |

1. **Event A.** Flag ≥ 0 and record `$4E40` = 0 (lantern 3, row 8): decrement, then `draw_column_63_64` with A=`$0A`, Y=`$26`. Column 38, map rows 8-10 open, which uncovers the exit to room 14 at (9, 39).
2. `room12_check_upper_passage` `$3E60`, **event B.** Flag+1 ≥ 0 and `room_lanterns_left+12` (`$36`) = 0 **and** records `$4E52` and `$4E56` = 0. Those are **room 14's lanterns 3 and 4** at map row 8, columns 9 and 30. Then decrement, and `draw_column_63_64` with A=7, Y=`$26`: column 38, map rows 5-7 open, which uncovers the exit to room 11 at (6, 39).
3. `room12_animate_traps` `$3E79` → `animate_floor_traps`.

```mermaid
stateDiagram-v2
  state EventA {
    state "A armed (vars+0 = 1)" as A1
    state "A fired once (vars+0 = 0)" as A0
    state "A done (vars+0 = $FF)" as AD
    [*] --> A1: room12_init
    A1 --> A0: $4E40 = 0 / passage col 38 text rows 10-12
    A0 --> AD: next pass / same passage drawn again
  }
  state EventB {
    state "B armed (vars+1 = 0)" as B0
    state "B done (vars+1 = $FF)" as BD
    [*] --> B0
    B0 --> BD: $36 = 0 and $4E52 = 0 and $4E56 = 0 / passage col 38 text rows 7-9
  }
```

| Event | Condition | Effect (text row, column) |
|---|---|---|
| A (×2) | room 12 lantern 3 taken | sound `$8A`; message 99 at (10, 38), 99 at (11, 38), 100 at (12, 38) |
| B | room 12 empty **and** room 14 lanterns 3+4 taken | sound `$8A`; message 99 at (7, 38), 99 at (8, 38), 100 at (9, 38) |

**Evidence.**
- **Observed:** the handler ran, and a floor trap fired (screen rows 11-12, columns 14-20, `$0D`→`$7D`). The flags stayed `01 00`.
- **Observed (`room_events2`, c):** both events. Column 38 changed to `$07`/`$87` at screen rows 13-16 (event B, text rows 7-8) and 19-22 (event A, text rows 10-11); `room_script_vars` = `FF FF` at t400, so event A went 1 → 0 → `$FF` (double firing).
- **Code:** the conditions one by one (all lanterns were zeroed together).

---

## 5. Room 13: the sliders

**Layout** (`room13.png`, map `$79C6`, the shortest map): four long ledges in a zigzag, with a top band of decorations. Bruce arrives at the top right (152, 50) and has to get down to the exit at the bottom right.

| Exit | Trigger cell | Destination |
|---|---|---|
| char 2 | (9, 39) | room 15 at (16, 195) |

**Other properties:**
- **Lanterns:** none. `lantern_list_room13` `$4E45` holds one dummy record (state 1, column 0, row 0) that nothing can match.
- **Enemies:** none (flag `$FF`). The handler also writes `SPENA` = `SPENA` AND 3 on every pass, so only Bruce's sprites 0 and 1 are shown.
- **Cell coordinates:** `actor_char_coords` `$1C39` adds 4 to the y of every actor in room 13 before it computes the cell row.

### 5.1 Init `room13_init` `$34C3`: the slider table

The table is ten slots of six arrays at `$010F-$014A`: `sliders_dir` `$010F`, `sliders_col` `$0119`, `sliders_row` `$0123`, `sliders_prev_col` `$012D`, `sliders_min_col` `$0137`, `sliders_max_col` `$0141`.

`room13_init` fills it as follows:
- **Direction:** slots 0-4 get `sliders_dir` = 2 (bit 7 clear: move left), slots 5-9 get `$82` (bit 7 set: move right).
- **Inactive slots:** slots 3 and 9 are then set to 0. `animate_room_objects` only walks slots 8..0.
- **Row and column:** the start column is copied to `sliders_prev_col`. The values depend on whether `game_cycle` `$40` is 0.

| Slot | Text row (map row) | Direction | Start col (cycle 0 / ≥1) | Min col | Max col (cycle 0 / ≥1) |
|---|---|---|---|---|---|
| 5 | 5 (3) | right | 6 | 6 | 34 / 38 |
| 6 | 5 (3) | right | 22 | 6 | 34 / 38 |
| 0 | 7 (5) | left | 33 | 20 / 18 | 33 |
| 7 | 7 (5) | right | 6 / 2 | 6 / 2 | 20 / 18 |
| 1 | 10 (8) | left | 19 / 21 | 6 | 19 / 21 |
| 8 | 10 (8) | right | 20 / 22 | 20 / 22 | 34 / 38 |
| 2 | 12 (10) | left | 2 | 2 | 33 / 37 |
| 4 | 12 (10) | left | 22 | 2 | 33 / 37 |

### 5.2 `animate_room_objects` `$104B`

For each slot 8..0 with `sliders_dir` ≠ 0:
- **Save:** the slot's column goes to `sliders_prev_col` and `slider_prev_col` `$70`, and its row to `slider_row` `$6F`.
- **Move left** (bit 7 clear): decrement the column; when it drops below `sliders_min_col`, it jumps to `sliders_max_col`.
- **Move right** (bit 7 set): increment the column; when it reaches `sliders_max_col`, it jumps to `sliders_min_col`.
- **Draw:** text rows 5 and 10 use `draw_sliding_tile_alt` (deadly `$66` with the `$67` trail); rows 7 and 12 use `draw_sliding_tile` (deadly `$64` with the `$65` trail). Each move plays sound `$89`.

`$66` counts as deadly only from room 10 on, which includes room 13.

### 5.3 Frame handler `room13_update` `$3E7C`

| Variable | Meaning |
|---|---|
| `room13_floor_bonus_flags` `$014B` (new name) | 4 bytes per player at `$014B + 4*current_player`; bytes 0-2 used, one per floor band. 1 = bonus still due. Set to 1 by `init_game_vars` (`$0F8D`, all 8 bytes) and by the room 19 restart (4 bytes of the current player). |
| `frame_parity` `$7B` | Toggled by `main_loop` every pass; the sliders move when it is 0. |

1. **Floor bonus.** If Bruce's `actor_y` `$A1` ≥ `$64`, the band is:
   - 0 when y < `$8A`;
   - 1 (`room13_check_band1` `$3E96`) when y < `$B6`;
   - 2 (`room13_check_band2` `$3EA6`) otherwise.

   If that band's flag is not 0, the handler decrements it and `room13_award_500` `$3EAF` adds `$0100` + `$F4` = **500 points** (two `add_score` calls).
2. `room13_update_objects` `$3EBC`: when `frame_parity` = 0, `animate_room_objects`. So each slider moves one column every 2 passes (6 frames).
3. `room13_keep_bruce_sprites` `$3EC3`: `SPENA` AND 3.

```mermaid
stateDiagram-v2
  state "Band flags 1,1,1 (per player)" as F3
  state "Band 0 taken" as B0
  state "Band 1 taken" as B1
  state "Band 2 taken" as B2
  [*] --> F3: init_game_vars or room 19 restart
  F3 --> B0: y in $64-$89 / +500
  F3 --> B1: y in $8A-$B5 / +500
  F3 --> B2: y at least $B6 / +500
  note right of F3 : each band pays once per player per game cycle, in any order
  state Sliders {
    [*] --> Move
    Move --> Move: every 2nd pass / 8 sliders step one column, sound $89, wrap at min/max
  }
```

| Trigger | Effect |
|---|---|
| Bruce y in band k and `$014B+4p+k` ≠ 0 | flag 0, +500 points |
| `frame_parity` = 0 | all active sliders step; sound `$89` per slider |
| Bruce touches `$64`/`$66` (contact bit 1) | `touch_deadly_char` `$304B` → dying state `$19` → `lose_fall` |

**Evidence.**
- **Observed:** the sliders. 32 cells changed at t100 and at t400, exactly 8 sliders × (old column, new column) × 2 char rows, on screen rows 9/10 (text 5, `$66`/`$67`), 13/14 (text 7, `$64`/`$65`), 19/20 (text 10, `$66`/`$67`) and 23/24 (text 12, `$64`/`$65`). The cycle-0 ranges match the positions seen. The room 11 diversion also ran this handler.
- **Code:** the floor bonus (`$3E87-$3EBB` never ran in any run, including `room_events2`), the cycle ≥ 1 layout, and slider deaths.

---

## 6. Room 14

**Layout** (`room14.png`, map `$7A46`): two floors, two slopes, a wall column at column 38.

| Exit | Trigger cell | Destination |
|---|---|---|
| char 3 | (3, 39), behind the wall column | room 11 at (80, 190) |
| char 4 | (9, 0) | room 12 at (160, 190) |
| char 5 | (9, 39) | room 16 at (16, 190) |

**Lanterns** (`$4E4A`):

| # | Record | Map row | Column |
|---|---|---|---|
| 1 | `$4E4A` | 5 | 9 |
| 2 | `$4E4E` | 5 | 30 |
| 3 | `$4E52` | 8 | 9 |
| 4 | `$4E56` | 8 | 30 |

Lanterns 3 and 4 are part of room 12's event B.

**Init** `room14_init` `$358D`: `room_script_vars+0` = 1.

**Frame handler** `room14_update` `$3ECC`:
1. **Event A** (fires twice, flag 1 → 0 → `$FF`). Records `$4E4A` and `$4E4E` = 0 (both row-5 lanterns): decrement, then `draw_column_63_64` with A=4, Y=`$26`. Column 38, map rows 2-4 open, which uncovers the exit to room 11.
2. `room14_animate_traps` `$3EE3` → `animate_floor_traps`.

```mermaid
stateDiagram-v2
  state "Armed (1)" as A1
  state "Fired once (0)" as A0
  state "Done ($FF)" as AD
  [*] --> A1: room14_init
  A1 --> A0: $4E4A = 0 and $4E4E = 0 / passage col 38 text rows 4-6
  A0 --> AD: next pass / drawn again
```

| Event | Condition | Effect |
|---|---|---|
| A (×2) | room 14 lanterns 1 and 2 taken | sound `$8A`; message 99 at (4, 38), 99 at (5, 38), 100 at (6, 38) |

**Evidence.**
- **Observed:** in `room_events` the handler ran with no change and the flag stayed 1. In `room_events2` (c): column 38, screen rows 7-10 → `$07`/`$87`, and `room_script_vars` = `FF` at t400 (double firing).
- **Code:** the condition alone (all lanterns were zeroed together).

---

## 7. Room 15

**Layout** (`room15.png`, map `$7BB4`): a pagoda tower in the middle with ledges on both sides, and a fence and floor at the bottom.

| Exit | Trigger cell | Destination |
|---|---|---|
| char 2 | (9, 0) | room 13 at (160, 196) |
| char 3 | **none in the map**; drawn by event C at (5, 39) and (6, 39) | room 17 at (16, 179) |

**Lanterns** (`$4E5B`), on the tower ledges:

| # | Record | Map row | Column |
|---|---|---|---|
| 1 | `$4E5B` | 1 | 19 |
| 2 | `$4E5F` | 1 | 21 |
| 3 | `$4E63` | 2 | 14 |
| 4 | `$4E67` | 2 | 26 |
| 5 | `$4E6B` | 4 | 13 |
| 6 | `$4E6F` | 4 | 27 |

**Init** `room15_init` `$3593`: `room_script_vars+0`, `+1` and `+2` = 1. All three events therefore fire twice.

**Frame handler** `room15_update` `$3EE6` (no floor traps):

| Event | Flag | Condition | Effect |
|---|---|---|---|
| A (×2) | vars+0 | record `$4E5B` = 0 (lantern 1) | message 87 (`$57`, tile `$00`) at (text 3, col 17), message 88 (`$58`, tile `$2F`) at (4, 17); sound `$8A`. This replaces the `$45` wall cells at map rows 1-2, column 17 (the tower's left wall). |
| B (×2) | vars+1 (written through the operand `l_4e98`) | records `$4E5F`, `$4E63` and `$4E6B` = 0 (lanterns 2, 3, 5) | the same messages at column 23 (the right wall, `$43` cells); sound `$8A` |
| C (×2) | vars+2 | `room_lanterns_left+15` `$39` = 0 (all six) | message 89 (`$59`: `$2F $2F $2F`) at (9, 37), message 90 (`$5A`: `$00 $00 $03`) at (8, 37), message 91 (`$5B`: `$00 $00 $03`) at (7, 37); sound `$8A`. **This creates the exit char `$03` at map rows 5-6, column 39** (exit 3 → room 17) and a floor of `$2F` at map row 7, columns 37-39. |

The labels are `room15_check_right_wall` `$3F08`, `room15_check_exit` `$3F30` and `room15_update_done` `$3F5A`.

```mermaid
stateDiagram-v2
  state EventA {
    state "armed 1" as a1
    state "0" as a0
    state "done $FF" as ad
    [*] --> a1
    a1 --> a0: $4E5B = 0 / open left wall col 17
    a0 --> ad: next pass / again
  }
  state EventB {
    state "armed 1" as b1
    state "0" as b0
    state "done $FF" as bd
    [*] --> b1
    b1 --> b0: $4E5F = $4E63 = $4E6B = 0 / open right wall col 23
    b0 --> bd: next pass / again
  }
  state EventC {
    state "armed 1" as c1
    state "0" as c0
    state "exit open $FF" as cd
    [*] --> c1
    c1 --> c0: $39 = 0 / exit chars $03 at col 39
    c0 --> cd: next pass / again
  }
```

**Evidence.**
- **Observed:**
  - event C: `room_script_vars` went `01 01 01` → `01 01 FF`, which also proves the double firing;
  - 18 cells changed at screen rows 13-18, columns 37-39, exactly as messages 91, 90 and 89 draw them. Row 13/14 `46 07 45` → `00 00 03`, row 15/16 the same, row 17/18 `42 42 45` → `2F 2F 2F`;
  - the coverage shows `$3F39`.
- **Observed (`room_events2`, c):** all three events. Screen rows 5/6 columns 17 and 23 → `$00`/`$80`, rows 7/8 the same columns → `$2F`/`$AF` (events A and B); the event C cells as above; `room_script_vars` = `FF FF FF` at t400.
- **Code:** the conditions one by one.

---

## 8. Room 16: the bonus-fall object

**Layout** (`room16.png`, map `$7C5C`): three floors, a wall column at column 1 on the left. The **bonus-fall object** is at the bottom right: chars `$2D`/`$2E` at map rows 8-9, columns 36-37.

| Exit | Trigger cell | Destination |
|---|---|---|
| char 3 | (6, 0), behind the wall column | room 11 at (128, 190) |
| char 4 | (9, 0) | room 14 at (160, 190) |

**Lanterns** (`$4E74`): (row 2, col 32) `$4E74`, (5, 5) `$4E78`.

**Init** `room16_init` `$359F`:
- Colour RAM `$DB1C/$DB1D`, `$DB44/$DB45`, `$DB6C/$DB6D` and `$DB94/$DB95` = `$FF`. Those are screen rows 19-22, columns 36-37: the object is drawn in colour 7.
- If `bonus_falls_left` `$4E95+current_player` = 0, it calls `erase_bonus_fall_object` `$2FEF`, which draws message 86 (`$56`: `$00 $00`) at text rows 10 and 11, column 36. The object is then gone.
- The `bonus_falls_left` bytes are set to 5 for both players by `init_game_vars` (`$0F9B`). Nothing else resets them; the room 19 restart does not.

**Picking up the object** (`room16_bonus_fall` `$2FD6`, from `handle_touched_char` through `touch_bonus_fall_chars` `$2EEA`):
- `$2D`/`$2E` are tested **before** the contact-bit test, so any overlap of the 3x2 cells that the actor tests counts.
- It works only in room 16 (`current_room` = `$10`), only for Bruce (X = 0), and only when `actor_y` ≥ `$A0`.
- **Effect:**
  - `bonus_falls_left[current_player]` - 1, `falls_left` `$28` + 1;
  - `print_falls_count`, sound `$8E`;
  - `erase_bonus_fall_object`.
- So the object gives one extra fall per visit, at most five per player per game.

**Frame handler** `room16_update` `$3F5B`:
1. **Event A** (flag vars+0 = 0, fires once). `room_lanterns_left+16` `$3A` = 0: decrement, then `draw_column_63_64` with A=7, Y=1. Column 1, map rows 5-7 open, which uncovers the exit to room 11 at (6, 0).
2. `room16_animate_traps` `$3F6E` → `animate_floor_traps`.

```mermaid
stateDiagram-v2
  state Passage {
    state "Passage closed (0)" as P0
    state "Passage open ($FF)" as P1
    [*] --> P0
    P0 --> P1: $3A = 0 / sound $8A, msg 99,99,100 at col 1 text rows 7-9
  }
  state BonusObject {
  state "Object present" as O1
  state "Object gone" as O0
  [*] --> O1: room drawn and bonus_falls_left[p] > 0
  [*] --> O0: room drawn and bonus_falls_left[p] = 0
  O1 --> O0: Bruce touches $2D/$2E with y at least $A0 / falls+1, bonus_falls_left-1, sound $8E
  }
```

**Evidence.**
- **Observed:**
  - event A: the flag went 0 → `$FF`, and screen rows 13-16, column 1 changed `$45`/`$C5` → `$07`/`$87`. Message 100 at text row 9 matched the cell already there, so it changed nothing;
  - a floor trap fired (rows 11-12, columns 9/11 at t100);
  - Bruce died during the run: `touch_deadly_char` `$304B`, `set_character_hit_state` `$407D`, `lose_fall`, `respawn_in_room` and `draw_room` ran, and `falls_left` went 4 → 3. The room was redrawn and the passage was drawn again (still `$07` at t400). This confirms that the events are re-applied on every entry.
- **Conclusion (not proven):** the death came from the floor-trap spikes, since `trigger_floor_trap` and the trap step 8 ran in the same run.
- **Observed (`room_events2`, c, t60):** event A at column 1 as above, and both lanterns drawn as collected (`$1E`, `$1F`). The bonus object stayed (`bonus_falls_left` was 5). Bruce lost a fall in that run too (`touch_deadly_char`, `set_character_hit_state` and `lose_fall` in `all16.bin`); the t400 screen is the player-turn screen.
- **Code:** the bonus-fall pickup (`$2FD6-$3000` never ran) and the erase in `room16_init` (`$35C0` never ran).

---

## 9. Room 17

**Layout** (`room17.png`, map `$7D8D`): corridors at map rows 1, 5 and 7, a strip of `$64` tiles at map row 3, columns 11-27, and yellow mesh pieces (tiles `$44`/`$49`) at the left and right.

| Exit | Trigger cell | Destination |
|---|---|---|
| char 2 | (8, 0) | room 15 at (160, 147) |
| char 3 | (1, 39) | room 18 at (16, 198) |

**Lanterns** (`$4E7D`): (8, 38) `$4E7D`, (9, 31) `$4E81`. No enemies (flag `$FF`, though the spawn tables hold delays).

**Init** `room17_init` `$35C4`:
- colour RAM `$DB1E` = `$FF` (screen row 19, column 38: lantern 1 in colour 7);
- `room_script_vars+0` = `+1` = 1;
- `slider_row` `$6F` = 5, `slider_col` `$6E` = `$0B`;
- the three travelling hazards all at column 8, on text rows 3, 7 and 9 (map rows 1, 5, 7), with `hazard_timer` `$77-$79` = `$F8`, `$F1` and `$EA` (they wait 8, 15 and 22 passes).

**Frame handler** `room17_update` `$3F71`:

| Variable | Meaning |
|---|---|
| `room_script_vars+0` / `+1` | One-shot flags of events A and B (1 armed, 0 done, `beq` test). |
| `room_script_vars+2` | Ceiling blink counter, reloaded with 10. |
| `room_script_vars+3` | Slider half-rate toggle. |
| `slider_col`/`slider_prev_col`/`slider_row` `$6E-$70` | The slider. |
| `hazard_col` `$71-$73`, `hazard_row` `$74-$76`, `hazard_timer` `$77-$79` | The travelling hazards. |

1. **Ceiling blink.** Decrement vars+2. When it goes negative: reload 10, then `room17_colour_flip_loop` `$3F86` writes `((colour RAM $D880 AND 7) XOR 2) OR $F8` into `$D880-$D89B`. That is screen row 3, columns 8-35: the top chars of map row 0. With room colour `$FF` this blinks yellow (7) and green (5) every 11 passes.
2. **Slider** (`room17_slider_tick` `$3F8C`).
   - Rate: vars+3 counts down from 0. On `$FF` it is set to 1 and the slider moves; on 0 it skips. So the slider moves every 2nd pass.
   - Move (`room17_move_slider` `$3F98`): the old column goes to `slider_prev_col`, then the column + 1. When the old column was ≥ `$1B`, the column restarts at `$0B`. The slider runs over columns 11-27 of text row 5 (map row 3), drawn with `draw_sliding_tile` (`room17_draw_slider` `$3FA6`): deadly `$64` at the new column, `$65` at the old one, sound `$89`.
   - The map fills that strip with `$64` (cells `$E4`), so until the slider has passed, the whole strip is deadly (Code).
3. **Event A** (`room17_check_lantern_a` `$3FA9`): vars+0 ≠ 0 and record `$4E7D` = 0 (lantern 1). Decrement, then message 93 (`$5D`: tiles `$44 $44`) at (text 10, col 37), which fills map row 8, columns 37-38. No sound.
4. **Event B** (`room17_check_lantern_b` `$3FBF`): vars+1 ≠ 0 and record `$4E81` = 0 (lantern 2). Decrement, then message 92 (`$5C`: `$49 $49 $49`) at (text 10, col 24), map row 8, columns 24-26. No sound.
5. `room17_traps_and_hazards` `$3FD5`: `animate_floor_traps`, then `step_travelling_hazards` `$3FDC` for hazards 2..0.

**The travelling hazards** (`step_travelling_hazards`; frame k = message `31+k`):

| `hazard_timer` after the increment | Action |
|---|---|
| negative | wait |
| 0, 1, 2 | draw frame k: 31 `$56`, 32 `$55`, 33 `$55 $56` |
| 3, column below the limit (`$23` for hazard 0, `$25` for 1/2) | `hazard_move_column` `$4016`: frame 6 (message 37, blank) at the old column, column + 1, timer = 2, draw frame 2 at the new column. So the hazard moves one column per pass. |
| 3 at the limit, then 4, 5, 6 | frames 34 `$54 $55`, 35 `$00 $55`, 36 `$00 $54`, 37 blank: the hazard fades out |
| 7 | `hazard_restart_wait` `$4039`: column = 8, timer = `$CA` (hazard 0: `$C8`), so it waits 54 or 56 passes |

The chars `$54`-`$56` are deadly. Each hazard crosses its corridor from column 8 to 35 or 37 in about 27-29 passes (1.6-1.8 s).

```mermaid
stateDiagram-v2
  state Hazard {
    state "Wait (timer below 0)" as W
    state "Appear (frames 0-2)" as Ap
    state "Travel (timer 2/3, 1 col per pass)" as T
    state "Fade (frames 3-6)" as Fd
    [*] --> W: room17_init timers $F8/$F1/$EA
    W --> Ap: timer reaches 0
    Ap --> T: timer 3
    T --> T: column below limit
    T --> Fd: column reaches $23 or $25
    Fd --> W: timer 7 / column 8, timer $C8 or $CA
  }
  state Lanterns {
    state "A armed" as LA
    state "A done" as LAd
    state "B armed" as LB
    state "B done" as LBd
    [*] --> LA
    [*] --> LB
    LA --> LAd: $4E7D = 0 / msg 93 at (10,37)
    LB --> LBd: $4E81 = 0 / msg 92 at (10,24)
  }
```

| Trigger | Effect | Timing |
|---|---|---|
| vars+2 < 0 | ceiling colour XOR 2 at `$D880-$D89B` | every 11 passes |
| vars+3 toggle | slider one column right, wraps after 27 → 11; sound `$89` | every 2 passes |
| lantern 1 taken | tiles `$44 $44` at map (8, 37-38) | once per entry |
| lantern 2 taken | tiles `$49 $49 $49` at map (8, 24-26) | once per entry |
| hazard timers | travel, fade and restart as above | per pass |

The map uses `$44` and `$49` for the yellow mesh pieces at map rows 2-6. So the events add mesh pieces next to where the lanterns were (from the map; what the mesh does for movement was not checked).

**Evidence.**
- **Observed (`room_events2`, c, t60):** events A and B. Screen rows 19/20, columns 24-26 → `$49`/`$C9`, and columns 37-38 → `$44`/`$C4` (the lantern cell at 38 is overwritten). Lantern 2 is drawn as collected (`$1E`) at (21, 31). `room_script_vars` = `00 00 09` at t400: both flags went 1 → 0 (one firing each), and the ceiling counter was running. `all17.bin` shows `room17_update`, the slider, events A and B, and `hazard_move_column` `$4016` executed.
- **Observed, room 17 freezes.** In every room 17 capture the game stops:
  - `room_events`: only `$1C32`/`$1C34` (`main_loop_wait`) executed;
  - `room_events2`: no cell changed between t60 and t400, and hazard 1's first frame (`$3FF6`, 15 passes after entry) never ran;
  - the snapshot `runs/rooms/room17.vsf` has PC = `$1C34`, the I flag clear (status `$30`), `frame_countdown` = 3 and `irq_chain_vector` `$0408` = `$491E` (`irq_playfield_top`, waiting for raster line `$40`).

  So the main loop waits for a raster IRQ that never comes. The screen keeps the status charset `$32` that `irq_frame_top` set, which is the `$D018`=`$32` the report noted for room 17. The cause was found afterwards (runs/r17_freeze, see rooms.md section "PAL freeze bug"): `draw_room` reads `$D011` at `$09BC` and `$0B33` and writes it back. When the read happens on raster lines 256-311, bit 7 (raster bit 8) is set, so the store sets bit 8 of the raster compare. The pending IRQ line `$40` becomes `$140` (320), which a PAL frame never reaches. In the capture, the redraw read `$9B` on line 279 and the closing RMW ran on line 287, so the bit stayed set. This is a timing bug of the original game on PAL, not something specific to room 17; room 17's redraw just ended in the window in these captures.
- **Code:** the ceiling blink, the slider path over many passes, hazards 1 and 2, and the hazard fade and restart.

---

## 10. Room 18: the wizard

**Layout** (`room18.png`, map `$7E90`, charset 2 `$B000`, `$D018`=`$3C`): the wizard's face fills the top centre, above a long floor on columns. Bruce enters at the bottom left (16, 198 from room 17; spawn 24, 198).

The single "lantern" `$4E86` is at map row 9, column 37, the bottom right. Its map cell is `$93`, the lantern char `$13`.

**The wizard's life is the state byte of this lantern record.** Bruce defeats the wizard by touching that cell, like any lantern:
- Bruce only, contact bit 1;
- +125 points, sound `$8E`;
- record byte 1 (`$9E`, tile `$1E`) is drawn in the cell;
- `room_lanterns_left+18` is decremented.

| Exit | Trigger cell | Destination |
|---|---|---|
| char 2 | (9, 0) | room 17 at (160, 68) |
| char 3 | **none in the map**; drawn after the defeat at (9, 39) | room 19 at (16, 150) |

Charset 2 also uses chars `$04` and `$05` in map row 0 and rows 6-7 (the wizard and the columns). For those codes the exit groups 4 and 5 have x = 0, so the code falls through to group 5 and would enter room 0 at (0, 0) if `check_exit_direction` allowed it (Code; see the open questions).

`touch_deadly_char` returns at once in room 18 (`$304B`: `current_room` = `$12`). There are no deadly chars there; the only danger is the fireballs. No enemies (flag `$FF`), so `check_sprite_collisions` is skipped and the handler tests the sprite collisions itself.

### 10.1 Init `room18_init` `$35FA`
- Colour RAM `$D878-$DBFF` = `$FE` (colour 6, multicolour), together with `$D900-$D9FF` and the other pages it fills.
- Clears `sprite_blocks+$1C0` = `$8340-$83BF` (the fireball shapes), sets `YXPAND` = 0 and `XXPAND` = `$FF`.
- `room_script_vars+0` = 1 (wizard alive) and `+1` = 1 (face timer: redraw on the first pass).
- `fireball_active` `$432E/$432F` = 0; `fireball_launch_delay` `$4330` = 0 and `$4331` = `$10` (fireball 1 starts 16 passes later).
- `room18_unused_init_bytes` `$4336/$4337` = 6, 7. Nothing reads them.

### 10.2 Variables

| Variable | Meaning |
|---|---|
| `room_script_vars+0` | 1 = wizard alive, 0 = defeated (effect or exit phase). |
| `room_script_vars+1` | Alive: face timer (8 passes). Defeated: effect countdown from `$50` (80 passes). |
| `room_script_vars+2` | Face zone 0-2. |
| `room_script_vars+3` (written through the operand `l_4e9a`) | Alive: face frame set toggle (1 → message set +6, 0 → set +0). Effect: body-tile toggle. |
| `lantern_list_room18` `$4E86` | Wizard state: ≠ 0 alive. |
| `fireball_active`, `fireball_launch_delay`, `fireball_x`, `fireball_y` `$432E-$4335` | 2 bytes each. |

### 10.3 Wizard alive (`room18_wizard_alive` `$3D1D`)

1. **Fireballs** `update_fireballs` `$4133`. Fireball 0 is sprite 6 (pointer `$0D`, block `$8340`) and fireball 1 is sprite 7 (pointer `$0E`, block `$8380`).
   - **Shape:** each pass, rows 0, 3, 6 and 9 of both shapes get random bytes AND `fireball_shape_masks` `$4322` (`$18 $3C $3C $18`), which makes a flickering ball.
   - **Launch:** an inactive fireball counts its delay down. At 0, `launch_fireball0` `$4201` / `launch_fireball1` `$4220` puts it at x=`$50` / `$5E`, y=`$37` (sprite y = y+`$1D`), enables its sprite and plays sound `$86`.
   - **Fall:** y += 5 per pass. At y ≥ `$E0` the fireball becomes inactive with a delay of 2.
   - **Steering:** x moves toward Bruce's `actor_x` `$9E` by up to 3 steps per pass while y < `$A8`, and up to 2 steps below that.
   - **VIC:** the position is written to `SP6X/SP6Y` and the MSB to `MSIGX`, and the colour is random OR `$F0`.
2. **Hit test.** Reading `SPSPCL` `$D01E`: if a bit of sprites 0/1 (Bruce, `actor_body_sprite`=0, `actor_overlay_sprite`=1) **and** a bit of sprites 6/7 are set, and Bruce's `actor_state` ≠ `$19`, then `set_character_hit_state` `$407D` (X=0): state `$19` (dying), timer `$10`. When the timer runs out, `action_dying` calls `lose_fall`.
3. **Face** `room18_face_timer` `$3D38`. Decrement vars+1. At 0: reload 8, then pick the zone from `actor_x` against `room18_zone_x_limits` `$4A89` (`$00 $3A $76`):
   - zone 2 if x ≥ `$76`;
   - zone 1 if x ≥ `$3A`;
   - zone 0 otherwise.

   `room18_draw_face` `$3D4E` then:
   - stores the zone in vars+2;
   - draws message 56+zone (`$38`) at text row 2, column 16 (8 tiles, screen rows 3-4);
   - toggles vars+3: if it was 0 it is set to 1 and messages 65+zone and 68+zone are drawn (set +6); else it is set to 0 and messages 59+zone and 62+zone are drawn (`room18_face_frame_set0` `$3D73`);
   - draws those two messages at text rows 3 and 4, column 18 (`draw_wizard_face_row3` `$3D81`, `draw_wizard_face_row4` `$3D8E`).

   So the face is redrawn every 8 passes (24 frames). The zone follows Bruce's x (conclusion: the eyes follow him), and the lower face alternates between two frames.

### 10.4 Defeat trigger and effect

**Trigger** `room18_wizard_just_defeated` `$3CE9`: vars+0 ≠ 0 and `$4E86` = 0.
- vars+0 = 0;
- `clear_fireball_shapes` `$423F`; `SPENA` AND `$1F` (sprites 5-7 off);
- **message 97** (`$61`, tile `$06`) at (text 11, column 0). This replaces the exit char `$02` at map (9, 0), so **the way back to room 17 is closed**;
- **+3000 points** (`$0BB8`: `$B8` to byte 2 at `$3D00`, `$0B` to byte 1 at `$3D07`);
- vars+3 = 0, vars+1 = `$50`;
- jump to `room18_draw_face` with zone 1 (one last redraw of the face).

**Effect** `room18_defeat_effect` `$3DAF`, while vars+1 ≠ 0. Each pass:
- **Colours:** the wizard area of colour RAM gets one random colour (random AND 7, OR `$F8`):
  - `$D8D3`, `$D8FB`, `$D923`, `$D94B` + 0..17 (screen rows 5-8, columns 11-28);
  - `$D886`, `$D8AE`, `$D976`, `$D99E`, `$D9C6`, `$D9EE` + 0..11 (rows 3-4 and 9-12, columns 14-25).

  On the last pass (counter 1) the colour is `$F8` (black).
- **Charset:** `room_charset_d018` `$F2` = `$3E`, charset 3 at `$B800`: the room without the wizard. While the counter is ≥ `$11` (the first 64 passes), a random byte below `$10` (1 in 16) sets `$3C` (charset 2, the wizard) instead. So the wizard flashes in and out, then stays gone.
- **Sound** `$8B`.
- **Body tiles:** vars+3 XOR 1, then
  - message 71+t at (3, 12) and 73+t at (3, 25);
  - message 75+t at (6, 14) and 77+t at (6, 23).

The effect lasts 80 passes (about 240 frames, 4.8 s). The charset stays `$3E` afterwards.

**Exit** `room18_draw_open_exit` `$3D9B`, on every pass once vars+1 = 0:
- message 94 (`$5E`: `$00 $00 $03`) at (11, 37), so map row 9, column 39 becomes **exit char `$03`** (exit 3 → room 19 at (16, 150)), and the lantern cell at column 37 is blanked;
- message 95 (`$5F`: `$5A $5A`) at (12, 38): a floor under it.

```mermaid
stateDiagram-v2
  state "Alive (vars+0 = 1)" as Alive
  state "Bruce dying (state $19)" as Dying
  state "Defeat start" as Def
  state "Effect (vars+1 = 80..1)" as Eff
  state "Exit open (vars+1 = 0)" as Exit
  [*] --> Alive: room18_init
  Alive --> Alive: every pass, fireballs. Every 8 passes, face redraw (zone from Bruce x, frame toggle)
  Alive --> Dying: SPSPCL bits 0-1 and 6-7 / set_character_hit_state
  Dying --> [*]: timer out / lose_fall, respawn in room 18
  Alive --> Def: $4E86 = 0 (Bruce took the lantern at map 9,37)
  Def --> Eff: fireballs off, msg 97 closes exit to room 17, +3000, vars+1 = $50
  Eff --> Eff: per pass, random colours, charset $3E (1/16 $3C while at least $11), sound $8B, body tiles
  Eff --> Exit: vars+1 reaches 0
  Exit --> Exit: per pass, msg 94/95 (exit char $03 at col 39)
  Exit --> Room19: Bruce touches the exit char $03
```

| From | Condition | To | Effects |
|---|---|---|---|
| Alive | fireball sprite 6/7 collides with Bruce's sprites 0/1 | Dying | state `$19`, timer `$10` → `lose_fall` |
| Alive | `$4E86` = 0 | Effect | fireballs and sprites 5-7 off, message 97 at (11, 0), +3000, vars+1=`$50` |
| Effect | vars+1 > 0 | Effect | colours, charset, sound `$8B`, messages 71-78 |
| Effect | vars+1 = 0 | Exit | messages 94 at (11, 37) and 95 at (12, 38) every pass |
| Exit | Bruce touches `$03` (exit test passes at x > `$A1` moving right) | room 19 | `enter_room` |

**Evidence.**
- **Observed, normal run:** fireballs ran (`$4133`, coverage); the face was redrawn (screen rows 5-8, columns 18-20: message set 65/68 → 59/62 for zone 0); vars `01 05 00 01` → `01 08 00 00`.
- **Observed, wizard-defeat run:**
  - the score went `$0007D0` → `$001388` (+3000);
  - `room_script_vars` was `00 30 01 01 00` at t100 (32 passes in 100 frames) and `00 00 01 01 00` at t400;
  - `$F2` was `$3E` at t400;
  - the face cells show message 57 at rows 3/4 and messages 66/69 at rows 5-8 (zone 1, set +6);
  - the body-tile messages changed at rows 5/6 (columns 12, 14, 25, 27) and 11/12 (columns 14-16, 23-24);
  - (21, 0) changed `$02` → `$06` (exit to room 17 closed);
  - at t400, rows 21-24, columns 37-39 hold `00 00 03` and `5A 5A` (exit drawn);
  - the screenshots `w_t400.png` show the room without the wizard;
  - coverage: `$3CE9`, `$3DAF` and `$3D9B` ran.
- **Observed (`room_events2`, c):** entering room 18 with `$4E86` already 0 runs the defeat on the first pass. At t60 the face shows zone 1, (21, 0) is `$06`, and the lantern cell (21, 37) is the collected tile `$1E` (drawn by `redraw_taken_lanterns`). At t400 the exit cells are drawn and `room_script_vars` = `00 00 01 01`.
- **Code:** the fireball hit (`$3D28-$3D37` never ran), the flash to `$3C`, a real pickup of the lantern by touch, and the steering to the right (`$41B8`).

---

## 11. Room 19: congratulations and the next cycle

**Layout** (`room19.png`, map `$7FE0`): castle walls and arches with flames at the bottom. There are no exits and no lanterns: `$4E8B` is a dummy record. No enemies.

**Init** `room19_init` `$425F`:
- `attract_countdown` `$49` = `$58` and `title_timeout_hi` `$4A` = `$04`, so the 16-bit countdown is `$0458` = **1112 frames** (22 s PAL). The raster IRQ's `game_frame_update` counts it down once per **frame**, not per pass (`$1678-$1688`).
- Clears the top text line `$8C00-$8C27`.

**Bruce's input in room 19** (`update_actors` `$179E`, `$17C4-$17D6`): while `current_room` = `$13`, Bruce's `actor_joy_dir` `$98` is forced on every pass:
- `$0E` (joystick up) while `room_timer` `$88` < 2, which is the first 512 frames;
- `$0F` (none) after that.

The player has no control in this room (Code).

**Frame handler** `room19_congratulations_update` `$4272`:

1. **While the countdown is not 0** (`room19_flash_and_message` `$4298`):
   - one random colour (AND 7, OR `$F8`) into colour RAM `$DAAC`, `$DAD4`, `$DAFC`, `$DB24`, `$DB4C`, `$DB74`, `$DB9C` and `$DBC4` + 0..28 (screen rows 17-24, columns 4-32: the flames);
   - message 4 "** CONGRATULATIONS **" at text row 0, column 10.
2. **When it is 0** (one pass, `$4278-$4297`):
   - `inc game_cycle` `$40` (`$4278`);
   - `room13_floor_bonus_flags` + 4·`current_player` + 0..3 = 1 (`room19_reset_floor_bonus_loop` `$4283`);
   - `reset_room_table_2a` `$10C5`: `room_lanterns_left` from `room_lantern_counts` `$4CCE`;
   - `reset_all_lanterns` `$33CA`: every lantern record of rooms 0-19 present;
   - `reset_player_room_flags` `$10E0`: the current player's entry bonus flags for rooms 1-19 = 1, room 0 = 0;
   - `respawn_in_room` with X=0: Bruce at room 0's spawn point (26, 196), and room 0 is drawn.

**Kept:** score, falls, `bonus_falls_left` (room 16), `high_score` and the extra-life threshold. The waiting player's saved lanterns are not touched.

### 11.1 What `game_cycle` changes

`game_cycle` is only ever tested for zero (`beq`/`bne`). Cycle 1 and every later cycle play the same, until the byte wraps after 255. Everything it changes, `room_timer` ≥ `$20` also changes (both are tested by the same code), except the room 13 layout and the Ninja postponement:

| Where | Address | Cycle 0 | Cycle ≥ 1 |
|---|---|---|---|
| `draw_room`, first spawn delays | `$0A58` | `ninja_first_spawn_delay` `$130B` / `yamo_first_spawn_delay` `$1347` per room | both 3 passes (the Yamo still 8 with a human opponent) |
| respawn delay after a spawn | `try_spawn_yamo` `$0D35`, `try_spawn_ninja` `$0DF0` | room table, halved when `room_timer` ≥ `$19`, 3 when ≥ `$20` | 3 |
| respawn delay after a removal | `reset_yamo_timer` `$0D6A`, `reset_ninja_timer` `$0D91` | the same | 3 |
| Ninja postponed while the Yamo is active | `try_spawn_ninja` `$0DBB` | with a computer Yamo, random ≥ `$19` (about 90 %) sets the Ninja timer to `$10` | never postponed |
| enemy action timer | `$22AD` (object_actions) | table value | 1 |
| enemy recovery after a hit | `$2B72` (combat_hits) | `$18` | 2 |
| enemy wake-up recovery | `$2DCE` (actor_checks) | `$18` | 1 |
| room 13 slider ranges | `room13_init` `$34F9-$355D` | section 5.1 | wider ranges and other start columns |

So from cycle 1 on, enemies appear about 3 passes after Bruce enters, return 3 passes after they are removed, and recover from hits and wake-ups at once. The sliders in room 13 cover more columns.

```mermaid
stateDiagram-v2
  state "Countdown (attract_countdown > 0)" as C
  state "Restart" as R
  [*] --> C: room19_init, $0458 frames
  C --> C: per pass, flame colours and CONGRATULATIONS. Bruce input forced
  C --> R: countdown = 0
  R --> Room0: game_cycle+1, floor flags, lantern counters, lantern records, entry flags, respawn_in_room(0)
```

**Evidence.**
- **Observed, ending run:**
  - `room19_flash_and_message` ran;
  - `game_cycle` was 0 at the start and 1 at t1000, and room 0 was drawn (`current_room` 0, `$F2` = `$38`);
  - the score stayed `$0007D0`: no entry bonus for room 0;
  - `$4278-$4297` ran (coverage `ending.bin`);
  - at t2500 `falls_left` was 3: `lose_fall` ran, so Bruce died in room 0 in cycle 1 with no input.
- **Code:** the floor-flag reset, the entry-flag reset, the input override and the cycle-1 difficulty.

---

## 12. Evidence summary

| Room | Observed | Code only |
|---|---|---|
| 10 | handler runs; floor trap; passage event (all lanterns zeroed) | single conditions, protection sabotage |
| 11 | diversion to room 13 when rooms 12, 14 and 16 are empty (two runs) | texture reset event |
| 12 | floor trap; events A (double) and B with all lanterns zeroed | each cross-room condition alone |
| 13 | 8 sliders and their tiles; reached through the diversion | 500-point bands, cycle ≥ 1 layout |
| 14 | event A (double) with all lanterns zeroed | the condition alone |
| 15 | events A, B, C (exit to 17), double firing | the conditions alone |
| 16 | event A, re-applied after a death; floor trap; death | bonus-fall object |
| 17 | events A and B; the game freezes in room 17 in every capture | ceiling blink, slider and hazards over time |
| 18 | face, fireballs, defeat trigger (also on entry with `$4E86` = 0), +3000, effect, charset `$3E`, exit to 19, exit to 17 closed | fireball hit, a lantern pickup by touch |
| 19 | countdown, `game_cycle` 0→1, restart in room 0 | flag resets, input override, difficulty changes |

## 13. Open questions

1. **Room 17 freeze:** in all three captures the main loop waits in `main_loop_wait` `$1C32` with interrupts enabled, and the raster IRQ `irq_playfield_top` (line `$40`) never fires. Resolved: The cause was found afterwards (runs/r17_freeze, see rooms.md section "PAL freeze bug"): `draw_room` reads `$D011` at `$09BC` and `$0B33` and writes it back. When the read happens on raster lines 256-311, bit 7 (raster bit 8) is set, so the store sets bit 8 of the raster compare. The pending IRQ line `$40` becomes `$140` (320), which a PAL frame never reaches. In the capture, the redraw read `$9B` on line 279 and the closing RMW ran on line 287, so the bit stayed set. This is a timing bug of the original game on PAL, not something specific to room 17; room 17's redraw just ended in the window in these captures.
2. **Room 18, chars `$04`/`$05`:** these cells fall through to exit group 5 (room 0, x = 0, y = 0) when `check_exit_direction` allows it, for example moving up with y < `$31`. Whether Bruce can ever reach such a cell was not tested.
3. **Room 18, later redraws:** a draw of room 18 with `$4E86` = 0 runs the defeat path again (Observed in `room_events2`), so it gives another 3000 points (Code; the score was not recorded there). In normal play this needs a respawn in room 18 after the defeat; no way to die there after the defeat was found (no fireballs, no deadly chars, no enemies).
4. **Room 19:** what joystick "up" does for Bruce during the first 512 frames was not looked at.
5. **Room 17:** what the mesh tiles `$44`/`$49` do for movement.
