# Room flow: the room-level game state machine

This part describes what every room shares:
- how a game starts and reaches room 0;
- what the main loop does on each pass;
- room entry, exits and how enemies follow;
- lanterns and score;
- death, respawn and the change of player;
- enemy spawning;
- the end of the game.

The individual room handlers of rooms 10-19 are in [rooms_10_19.md](rooms_10_19.md).

Conventions are the same as in that part:
- a **pass** is one run of `main_loop` `$1BC2`, at least 3 video frames;
- a **frame** is one raster IRQ (`game_frame_update` `$15A8`, 50 per second on PAL);
- **Observed** marks facts seen in a run (the `room_events` and `room_special` runs, `cov_all.bin`); **Code** marks facts read from the code only.

## 1. Overview

```mermaid
stateDiagram-v2
  state "Cold start $0400" as Cold
  state "Title $0584 (title_menu_loop $08B1)" as Title
  state "Demo $0531 (game_playing = 0)" as Demo
  state "start_game $070E" as Start
  state "Room play (main_loop $1BC2)" as Play
  state "Room change (enter_room $2F8E)" as Enter
  state "Bruce dying (state $19) or energy negative" as Dying
  state "lose_fall $1818" as Lose
  state "next_player_turn $182A" as Turn
  state "game_over $188E" as Over
  state "Room 19 end ($4278)" as End
  [*] --> Cold
  Cold --> Title: restart_to_title $050F
  Title --> Demo: title countdown ends
  Demo --> Title: key or fire (check_demo_exit), or a lost fall
  Title --> Start: F7 or port-1 fire
  Start --> Play: init_game_vars, init_game_screen, draw_room(0)
  Play --> Enter: Bruce touches an exit char 2-5
  Enter --> Play: draw_room, stack reset, jmp main_loop
  Play --> Dying: deadly char, fireball, hits
  Dying --> Lose: timer out, or energy negative
  Lose --> Over: falls_left becomes negative
  Lose --> Turn: falls left
  Turn --> Play: swap players if 2P, respawn_in_room(current_room)
  Over --> Turn: 2P and the other player has falls
  Over --> Title: otherwise, after $FE + $40 frames
  Play --> End: room 19 countdown over
  End --> Play: game_cycle+1, resets, respawn_in_room(0)
  Play --> Title: F1 key
```

## 2. Game start → room 0

`start_game` `$070E` (after F7 or fire on the title):
1. Blanks the screen and sprites, sets `current_player` `$03` = 0, stops the music, and keeps the options in `saved_two_player_mode` / `saved_human_opponent_mode`.
2. `show_player_turn_screen` `$0EA7`: the "PLAYER 1" screen for 64 frames (128 with two players).
3. Stack = `$FD`, then `init_game_vars` `$0F72`:
   - clears zero page `$03-$F5`, so `current_room` `$29` = 0 and `game_cycle` `$40` = 0;
   - clears `$4EED-$4FE7`;
   - sets `$0100-$0107` to 1 (`game_playing` `$0104` = 1) and `room13_floor_bonus_flags` `$014B-$0152` = 1;
   - `bonus_falls_left` `$4E95/$4E96` = 5;
   - `reset_room_table_2a` `$10C5`: `room_lanterns_left` `$2A-$3D` from `room_lantern_counts` `$4CCE`;
   - `room_entry_bonus_flags` `$0300-$0327` = 1, except `$0300/$0301` (room 0) = 0;
   - `reset_all_lanterns` `$33CA` (every lantern record state = 1);
   - `init_saved_lantern_flags` `$0FE2` (`saved_lantern_flags` `$0340-$03A0` = 1);
   - `falls_left` `$28` = 4, or 9 with a human opponent;
   - `next_extra_life_score` and `other_next_extra_life_score` from `first_extra_life_score` `$438B` (`$009C40` = 40000);
   - copies the player block `$28-$43` to `other_player_state` `$439F` (28 bytes).
4. `init_game_screen` `$0763`: game IRQ, keyboard, text-row tables, VIC bank, status line, then `init_actor` for Bruce (X=0) at `room_spawn_x/y` `$4BAE/$4BC2` of room 0 (26, 196).
5. `draw_room` `$09BC` for room 0 (section 4.2), then `jmp main_loop`.

`start_demo` `$0531` does the same with `game_playing` = 0 and the options cleared. In the demo, Bruce's input comes from `demo_input_data` `$F300`, and `lose_fall` goes back to `title_screen`.

## 3. Per-pass and per-frame work

### 3.1 `main_loop` `$1BC2` (one pass)

```mermaid
flowchart TD
  A["frame_countdown $48 = 3"] --> B["check_demo_exit $19B8"]
  B --> C{"game_playing $0104?"}
  C -- yes --> D["handle_game_keys $1B29, pause_debounce_tick $19EC, check_fire_unpause $1A08"]
  D --> E{"pause_state $0105 negative?"}
  E -- yes --> W
  E -- no --> F
  C -- no --> F["main_loop_frame_work $1BDF: clear flag bits in actor_energy+1/+2"]
  F --> G["blink_player_label $1A96, flicker_lights $40BC"]
  G --> H{"room_without_enemies $7A = 0?"}
  H -- yes --> I["tick_enemy_timers $0DA4, try_spawn_yamo $0D0F, try_spawn_ninja $0DB1"]
  H -- no --> J
  I --> J["main_loop_toggle_parity $1BFE: frame_parity $7B 0/1"]
  J --> K["run_room_update $3A6F: frame handler of current_room"]
  K --> L["actor_background_collision $5212"]
  L --> M["check_actors_background $2E39: exits, lanterns, deadly chars, traps"]
  M --> N["protection key 2"]
  N --> O{"room_no_combat_flags $4C9E,room = 0?"}
  O -- yes --> P["check_sprite_collisions $29C3"]
  O -- no --> Q
  P --> Q["update_high_score $3184"]
  Q --> R["update_actors $179E: input, movement, poses"]
  R --> S["draw_object_sprites $2584"]
  S --> T["check_actor_knockouts $2D55"]
  T --> W["main_loop_wait $1C32: until frame_countdown = 0"]
  W --> A
```

Two of these calls leave the pass early:
- `check_actors_background` → `enter_room` resets the stack (`TXS $FF`), draws the new room and jumps to `main_loop` (section 4);
- `action_dying` and `check_actor_knockouts` jump to `lose_fall`, which does not return (section 6).

### 3.2 Per frame, in the raster IRQ (`game_frame_update` `$15A8`)

These counters count frames, not passes:

| Counter | Rule |
|---|---|
| `frame_countdown` `$48` | -1 per frame down to 0. It paces the main loop and every wait loop. |
| `attract_countdown` `$49` / `title_timeout_hi` `$4A` | 16-bit countdown, -1 per frame down to 0. Title timeout; in the game only room 19 uses it (`$0458` frames). |
| `room_timer_lo` `$87` / `room_timer` `$88` | While `game_playing` ≠ 0 and the game is not paused: `$87` + 1 per frame, and on its wrap `$88` + 1 until `$88` reaches `$80`. So `room_timer` counts 256-frame units (5.12 s PAL) since the room was drawn. |
| `yamo_idle_timer` `$89/$8A` | Only with a human Yamo: counts frames without input on the Yamo's port. At `$0700` frames: `human_opponent_mode` = 0, `room_timer` = `$20`, sound `$8A`, and `falls_left` and `other_player_state` lose 5 each, down to at least 0. So the 9 falls of a human-opponent game turn back into the 4 of a computer game (Code). |

## 4. Room entry and exits

### 4.1 Exits

`check_actors_background` `$2E39` runs every pass for each active actor (2..0) that is not dying:
- `actor_char_coords` `$1C39` computes the cell row and column: (y-12)/16 and (x-12)/4, with y+4 in room 13;
- `check_three_cells` `$2E6E` passes the three chars at columns col..col+2 of that row, and then of the row below, to `handle_touched_char` `$2E89`.

**Exit chars** are the codes 2, 3, 4 and 5 (after AND `$7F`). Each code is an exit group with four 20-byte tables indexed by room:

| Code | Destination | Entry x | Entry y |
|---|---|---|---|
| 2 | `exit2_room` `$4B5E` | `exit2_x` `$4BFE` | `exit2_y` `$4C12` |
| 3 | `exit3_room` `$4B72` | `exit3_x` `$4C26` | `exit3_y` `$4C3A` |
| 4 | `exit4_room` `$4B86` | `exit4_x` `$4C4E` | `exit4_y` `$4C62` |
| 5 | `exit5_room` `$4B9A` | `exit5_x` `$4C76` | `exit5_y` `$4C8A` |

`take_exit_char02` `$2F3C`, `take_exit_char03` `$2F51`, `take_exit_char04` `$2F66` and `take_exit_char05` `$2F7B` each call `check_exit_direction` `$30D4` first:

| Room | The exit is allowed when |
|---|---|
| 11 | always (C=0) |
| other rooms | the actor moves left (`actor_moved_left` `$4F5D`) with x < `$10`, **or** moves right (`actor_moved_right` `$4F60`) with x > `$A1`, **or** is in state `$0E` with y > `$C5`, **or** has `actor_move_counters` `$4F57` ≠ 0 with y < `$31` |

When an exit is allowed but its group has entry x = 0, the code falls through to the next group: 2 → 3 → 4 → 5. Group 5 always enters, even with x = 0.

`enter_room` `$2F8E` takes A = entry x, Y = entry y and `$4E` = the destination:
- **An enemy** (X ≠ 0) is only removed (`remove_actor` `$3001`): it left the room.
- **Bruce** (`enter_room_bruce` `$2F9A`):
  1. `actor_x` `$9E` and `actor_y` `$A1` = the entry point; `current_room` `$29` = the destination.
  2. **Enemies follow** (`enter_room_enemy_loop` `$2FA5`). For each enemy slot 2..1:
     - if it is active: `enemy_saved_energy-1+X` `$8F/$90` = its energy, and `enemy_entry_x-1+X` `$8B/$8C` and `enemy_entry_y-1+X` `$8D/$8E` = **Bruce's entry point**;
     - otherwise both entry bytes = 0 (`enter_room_no_follow` `$2FB9`).

     Then `remove_actor`.
  3. `reset_enemy_timer` `$0D42`, stack = `$FF`, `draw_room` `$09BC`, `draw_object_sprites`, `jmp main_loop`.

When the enemy's spawn timer later runs out in the new room, `init_actor` `$0B8E` → `actor_pick_spawn` `$0BFA` finds `enemy_entry_x` ≠ 0. It then places the enemy at Bruce's entry point with its saved energy (`actor_use_entry_pos` `$0C3F`) and clears the entry byte.

In rooms with `room_no_combat_flags` set, `draw_room` clears `enemy_entry_x/x+1`, so enemies do not follow there. Those rooms are 3, 8, 9, 11, 13, 17, 18 and 19. `lose_fall` also clears them.

### 4.2 `draw_room` `$09BC`

```mermaid
flowchart TD
  A["blank screen line 0, colour RAM = room_char_colours, clear_fireball_shapes, silence_all_sound"] --> B{"room 11 and $36,$38,$3A all 0?"}
  B -- yes --> R13["draw_room_special $09F6: respawn_in_room(13)"]
  B -- no --> C{"room_entry_bonus_flags $0300+2*room+player set?"}
  C -- yes --> C2["clear flag, add_score $07D0 = 2000 points"]
  C -- no --> D
  C2 --> D["draw_room_reset $0A2A: clear $4F57-$4FDA, room_timer, scroll_direction=0, anim_speed_index=7"]
  D --> E["room_without_enemies = room_no_combat_flags; if set, enemy_entry_x/x+1 = 0"]
  E --> F["draw_room_spawn_timers $0A4E: Ninja/Yamo first spawn delays, 3 if game_cycle not 0, Yamo 8 with a human opponent"]
  F --> G["draw_room_reset_bruce $0A6B: Bruce contact, state, timer; trap timers $4FDE-$4FE0 = 0; raster colour record; charset $F2"]
  G --> H["decode the RLE map onto rows 3-24"]
  H --> I["redraw_taken_lanterns $336E"]
  I --> J["dispatch_room_init $33B3: room_script_vars = 0, room init handler via room_setup_handlers $4E9C"]
  J --> K["run_room_update $3A6F: first pass of the room frame handler"]
```

- **Room 11 diversion:** `draw_room_special` is described in [rooms_10_19.md](rooms_10_19.md) section 3.1. Observed in two runs: entering room 11 with `$36`/`$38`/`$3A` = 0 ended in room 13 (`current_room` = 13).
- **Entry bonus:** 2000 points (`$07`→ byte 1 and `$D0` → byte 2 of `add_score` `$3175`), once per room and player. The flag byte is `room_entry_bonus_flags` + 2·room + `current_player`. `init_game_vars` sets them all except room 0. The room 19 restart sets them again for the current player (`reset_player_room_flags` `$10E0`), again except room 0.
  - Observed: after the room 19 restart, the score stayed `$0007D0` in room 0.
  - Observed: the `room_events` snapshots all show 2000 points after one room entry.
- **Charset:** `room_charset_d018` `$F2` = `$38` for rooms 0-9, `$3C` for room 18 and `$3A` for the others.

### 4.3 Room exit graph

Solid arrows: exit cells present in the map. Dashed arrows: exits that are in the tables but have no trigger cell in the map; a room handler draws the cell at run time (rooms 15 and 18; for rooms 0-9 see that part), or the exit is not used. The thick arrows are the special transfers.

```mermaid
flowchart LR
  R0((0)) --> R1((1))
  R1 --> R0
  R1 --> R2((2))
  R1 -.-> R5((5))
  R2 --> R1
  R2 -.-> R3((3))
  R3 --> R2
  R3 -.-> R10((10))
  R3 -.-> R0
  R4((4)) --> R5
  R4 --> R7((7))
  R5 --> R6((6))
  R5 -.-> R4
  R5 -.-> R1
  R6 --> R5
  R6 -.-> R2
  R6 -.-> R0
  R7 --> R8((8))
  R7 -.-> R0
  R8 --> R7
  R8 --> R9((9))
  R9 --> R8
  R9 -.-> R6
  R10 --> R3
  R10 --> R11((11))
  R11 --> R10
  R11 --> R12((12))
  R11 --> R14((14))
  R11 --> R16((16))
  R12 --> R11
  R12 --> R14
  R14 --> R11
  R14 --> R12
  R14 --> R16
  R16 --> R11
  R16 --> R14
  R11 ==>|"rooms 12,14,16 empty"| R13((13))
  R13 --> R15((15))
  R15 --> R13
  R15 -.->|"room 15 empty"| R17((17))
  R17 --> R15
  R17 --> R18((18))
  R18 -->|"closed at the defeat"| R17
  R18 -.->|"wizard defeated"| R19((19))
  R19 ==>|"countdown, game_cycle+1"| R0
```

The edges come from `assets/rooms/roomNN.json` (`exits`, `trigger_cells`). No room leads into room 4 except from room 5 (dashed).

## 5. Lanterns

**Data:**
- `lantern_list_ptrs` `$4CE2` points to one list per room, from `lantern_list_room00` `$4D0C` to `lantern_list_room19` `$4E8B`.
- Each record is 4 bytes: state (≠ 0 present), collected cell (`|$80` style), column, text row (map row = text row - 2). The list ends with a byte that has bit 7 set.
- `room_lantern_counts` `$4CCE` holds 90 lanterns in all. Rooms 13 and 19 have none, but each list holds one dummy record, so there are 92 records.

**Collecting** (`handle_touched_char` → `pick_up_lantern` `$2F04`):
1. The chars `$13`, `$14` and `$31` count only when contact bit 1 of `actor_contact` `$B6` is set (the mask touched colour-2 pixels), and only for Bruce (X = 0).
2. `collect_lantern_at` `$331C` scans the current room's list (`lantern_search_loop` `$3334`) for a record that is present, has column = the touched column, and has text row = `actor_char_row` `$E9`. When found (`lantern_found` `$335C`), it sets the state byte to 0, decrements `room_lanterns_left+room` and returns the collected cell. When not found, it returns C=1 (`lantern_not_found` `$335A`).
3. The collected cell (AND `$7F`) is written into the top and bottom chars, then **+125 points** (`$7D`, `add_score` with X=2) and sound `$8E`.

Observed: the room 18 record `$4E86` after the run holds `00 9E 25 0B`.

**Drawing on entry:** `redraw_taken_lanterns` `$336E` replaces every collected lantern of the room by its collected cell after the map is drawn (`redraw_lantern_loop` `$337E`).

**Two kinds of lantern state.** Room events depend on both:

| State | Where | Reset by | Per player |
|---|---|---|---|
| record state bytes | in the lists `$4D0C-$4E94` (byte 0 of each record) | `reset_all_lanterns` `$33CA` at game start and at the room 19 end | the live lists belong to `current_player`; the waiting player's states are in `saved_lantern_flags` `$0340` (97 bytes, 92 used) and are exchanged by `swap_player_lantern_flags` `$0FED` |
| counters | `room_lanterns_left` `$2A-$3D` | `reset_room_table_2a` `$10C5` at game start and at the room 19 end | part of the player block `$28-$43`, exchanged with `other_player_state` |

How the room handlers use them is in rooms_10_19.md section 1.

## 6. Death, the lost fall and respawn

### 6.1 Causes of death

| Cause | Code | Path |
|---|---|---|
| Deadly char (`$0F`, `$40`, `$54-$5A` except `$57`, `$64`, `$71-$7C`, `$66` from room 10) with contact bit 1 | `touch_deadly_char` `$304B` (not in room 18) | sound `$8C`. Bruce: `set_character_hit_state` `$407D` (state `$19`, timer `$10`). An enemy is removed. |
| Fireball in room 18 | `room18_wizard_alive`, `$3D28` | `set_character_hit_state` |
| Out of energy (hits by the Yamo and Ninja) | `check_actor_knockouts` `$2D55` | `actor_energy` `$D1` negative, and no running state `$13`/`$19` timer → `lose_fall` |
| State `$19` timer out | `action_dying` `$216B` | Bruce (X=0) at timer 1 → `lose_fall` |

Observed (room 16 run): `touch_deadly_char` → `set_character_hit_state` → `lose_fall` → `respawn_in_room` → `draw_room` ran, and `falls_left` went 4 → 3.

### 6.2 `lose_fall` `$1818` and `next_player_turn` `$182A`

```mermaid
stateDiagram-v2
  state "lose_fall $1818" as LF
  state "next_player_turn $182A" as NPT
  state "swap player blocks" as Swap
  state "respawn_after_fall $1886" as Resp
  [*] --> LF
  LF --> Title: demo (game_playing = 0)
  LF --> GameOver: dec falls_left, negative
  LF --> NPT: falls_left at least 0
  NPT --> TurnScreen: one player, or the other player is out (other_player_state negative)
  NPT --> Swap: 2P and other_player_state at least 0 / current_player XOR 1
  Swap --> TurnScreen
  TurnScreen --> Resp: init_game_screen
  Resp --> [*]: respawn_in_room(current_room)
  GameOver --> NPT: 2P and the other player has falls
  GameOver --> Title: otherwise
```

Step by step:
1. `silence_all_sound`. In the demo: `title_screen`.
2. `dec falls_left`. If it becomes negative: `game_over` `$188E`.
3. `next_player_turn`:
   - `actor_energy` of all three actors = `$24`;
   - `enemy_entry_x/x+1` = 0 (enemies do not follow the respawn);
   - `clear_fireball_shapes`.
4. **Two players** (`two_player_mode` `$42C9` ≠ 0 and `other_player_state` `$439F` ≥ 0, which is the waiting player's `falls_left`): `current_player` XOR 1.
5. `show_next_turn_screen` `$184B`: `show_player_turn_screen` for the new current player.
6. **Swap** (same condition):
   - `swap_player_block_loop` `$1862` exchanges zero page `$28-$43` (28 bytes) with `other_player_state` `$439F-$43BA`. The block holds `falls_left`, `current_room`, `room_lanterns_left[20]`, two unused bytes `$3E/$3F`, `game_cycle` and `score`;
   - `swap_player_lantern_flags` `$0FED` exchanges the record states;
   - `swap_extra_life_loop` `$1875` exchanges `next_extra_life_score` `$4392` with `other_next_extra_life_score` `$4395`.
7. `respawn_after_fall` `$1886`: `init_game_screen` (which inits Bruce), then `respawn_in_room` `$3217` with X = `current_room`. That is the room where this player died, or, after a swap, the room where the other player died last.

`respawn_in_room` sets `current_actor` = 0 and calls `enter_room` with the room's `room_spawn_x` `$4BAE` / `room_spawn_y` `$4BC2` (the "respawn" tables). Those tables are also Bruce's start point and enemy spawn point A. So the room is drawn again from its map: the lanterns are redrawn, the vars are cleared, and init and the first handler pass run.

**Indexed by `current_player`, not swapped:**
- `room_entry_bonus_flags` `$0300` (room·2 + player);
- `bonus_falls_left` `$4E95+player`;
- `room13_floor_bonus_flags` `$014B` + 4·player.

**Neither swapped nor per player:** `room_script_vars`, the spawn timers, the trap and slider state. All of them are set again by `draw_room` and the room init.

### 6.3 Floor traps (`room_entry_traps.asm`)

Char `$60` with contact bit 1 → `trigger_floor_trap` `$306B`:
1. It reads the colour RAM of the touched cell. If its low 3 bits are not 5 (the trap is not already firing), it takes a free slot of `tile_anim_timer` `$4FDE-$4FE0` (timer = 1), with `tile_anim_row` `$4FE4` = the cell row - 1 and `tile_anim_col` `$4FE1` = the column - 1.
2. `mark_floor_trap` `$30C8` writes `$FD` to the cell's colour.

Any actor can trigger it.

`animate_floor_traps` `$3228` runs from the handlers of rooms 6, 7, 10, 11, 12, 14, 16 and 17. For each slot (`floor_trap_slot_loop` `$322C`), it increments the timer and acts on the value **before** the increment:

| Value | Action |
|---|---|
| 8 | sound `$8D`; message 47 (`$71-$73`) at the row and message 48 (`$74-$76`) one row lower: deadly spikes |
| 12 | messages 49 (`$77-$79`) and 50 (`$7A-$7C`) |
| 16 | messages 47/48 again |
| 20 | message 0 (blank) at the row; colour `$F8` back on the trap cell (re-armed); message 51 (`$7D $60 $7D`) one row lower |
| 24 | slot free |

Observed: rooms 10, 12 and 16 show `$0D` → `$7D` at the cells beside a `$60`, which is message 51 at step 20.

### 6.4 Game over (`game_over` `$188E`)

The game-over screen shows the big "GAME OVER" tiles, the player banner and the score in big digits, for `$FE` frames.
- With two players and the other player still in (`other_player_state` ≥ 0): `next_player_turn`. The finished player's block is stored with `falls_left` = `$FF`, so there are no further swaps.
- Otherwise: another `$40` frames, then `title_screen`.

The two-player branch `$1971-$1978` never ran (Code).

## 7. Score and extra falls

- `add_score` `$3175` adds A to byte X of `score_add` `$25` and calls `add_score_and_check_bonus` `$312C`. `score` `$41-$43` is 24-bit, high byte first.

| Event | Points |
|---|---|
| Lantern | 125 (`$007D`) |
| First entry into a room | 2000 (`$07D0`) |
| Room 13 floor band | 500 (`$01F4`) |
| Wizard defeated | 3000 (`$0BB8`) |
| Hits on enemies | see combat_hits |

- **Extra falls from score:** when the score is ≥ `next_extra_life_score` in **every one of its three bytes** (`$313A`, a byte-wise test, not a 24-bit compare), `falls_left` + 1 and the threshold + `extra_life_interval` `$438E` (`$007530` = 30000). The first threshold is 40000 (`$009C40`). Because of the byte-wise test, the extra fall comes at the first score addition after the low byte also reaches `$40` (Code; `$3146-$3159` never ran).
- **Extra falls from room 16:** the bonus-fall object, up to 5 per player per game ([rooms_10_19.md](rooms_10_19.md) section 8).
- `update_high_score` `$3184` copies the score to `high_score` `$4388` each pass when it is higher. It copies 4 bytes, so the 4th byte overwrites the first byte of `first_extra_life_score` (a known bug).

## 8. Enemy spawning

The **actors** are: 0 = Bruce (VIC sprites 0 and 1), 1 = Yamo (sprites 2 and 3), 2 = Ninja (sprite 4).

**Per-room tables** (20 bytes each, `actor_room_tables.asm`):

| Table | Address | Use |
|---|---|---|
| `ninja_first_spawn_delay` | `$130B` | `ninja_spawn_timer` `$5D` when the room is drawn |
| `ninja_respawn_delay` | `$131F` | reload after a spawn or a removal |
| `ninja_entry_preference` | `$1333` | 0: random side; ≠ 0: 3 out of 4 times the side comes from the **sign of `yamo_entry_preference`** (the code reads the Yamo table here) |
| `yamo_first_spawn_delay` | `$1347` | `yamo_spawn_timer` `$5E` when the room is drawn |
| `yamo_respawn_delay` | `$135B` | reload |
| `yamo_entry_preference` | `$136F` | the side: positive = spawn point A (`room_spawn_x/y`), negative = B (`room_alt_spawn_x/y` `$4BD6/$4BEA`) |
| `room_no_combat_flags` | `$4C9E` | ≠ 0: no spawning, no following, no `check_sprite_collisions` |

The timers count **passes**. For rooms 10-19 (Ninja first/respawn, Yamo first/respawn):

| Room | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 |
|---|---|---|---|---|---|---|---|---|---|---|
| Ninja | 8/12 | 0/0 | 4/4 | 18/8* | 8/8 | 8/8 | 8/8 | 18/8* | 0/0 | 0/0 |
| Yamo | 48/48 | 0/0 | 32/32 | 192/238* | 32/48 | 48/80 | 32/48 | 192/238* | 0/0 | 0/0 |

\* Rooms 13 and 17 have the no-combat flag, so these values are never used.

**Level from `room_timer`:** `get_room_time_level` `$10D0` returns:
- V=1 when `room_timer` ≥ `$20` (8192 frames, 164 s in the room);
- C=1 when it is ≥ `$19` (6400 frames, 128 s);
- neither, below that.

Each reload then does this:
- V=1, or `game_cycle` ≠ 0 → timer = 3 (`yamo_timer_minimum` `$0D3D`, `ninja_timer_minimum` `$0D99`);
- C=1 → timer halved (`yamo_timer_halve` `$0D3A`, `ninja_timer_halve` `$0DF5`, and the `_on_reset` variants `$0D6F`/`$0D96`).

The enemy action, recovery and wake-up timers use the same level test (rooms_10_19.md section 11.1).

```mermaid
stateDiagram-v2
  state "Timer running" as Run
  state "Timer 0, enemy absent" as Ready
  state "Enemy active" as Act
  [*] --> Run: draw_room, first spawn delay (3 if game_cycle not 0, Yamo 8 with human)
  Run --> Run: each pass, tick_enemy_timers -1
  Run --> Ready: timer = 0
  Ready --> Act: try_spawn_yamo or try_spawn_ninja / sound $82, init_actor (entry point if following, else spawn A or B)
  Ready --> Run: Ninja only, Yamo active, game_cycle 0, computer Yamo, level 0, random at least $19 / timer $10
  Act --> Run: on spawn the timer is reloaded (respawn delay, level rules)
  Act --> Run: remove_actor (knock-out, deadly char, exit) / reset_enemy_timer reloads
```

**Spawn details:**
- `spawn_yamo` `$0CD5` caps the energy at `$14`; `spawn_ninja` `$0DF8` caps it at `$07` and turns the Ninja toward Bruce.
- With a human opponent, the Yamo's respawn delay is `$30`.
- Observed: in the ending run Bruce lost a fall in room 0 in cycle 1, with no input.

## 9. End of the game

There are two ends:
1. **Completion.** Room 19 counts `$0458` frames, then increments `game_cycle` and sends Bruce back to room 0 with all lanterns, the room 13 bonuses and the current player's entry bonuses restored. Score and falls are kept. Cycles ≥ 1 are harder (rooms_10_19.md section 11). There is no "game won" end: play continues until the falls are used up.
   - Observed: `game_cycle` 0 → 1 and room 0 by frame 1000 from the room 19 snapshot.
2. **Game over.** The falls are used up (section 6.4). With two players the other player continues. Then `title_screen`.

F1 (`handle_game_keys`) restarts to the title at any time.

## 10. Per-room and room-flow variables

Reset points: **IGV** = `init_game_vars` `$0F72` (new game), **DR** = `draw_room` `$09BC` (every room entry and respawn), **RI** = the room's init handler, **R19** = the room 19 end `$4278`, **LF** = `lose_fall`/`next_player_turn`.

| Variable | Address | Size | Reset | Meaning |
|---|---|---|---|---|
| `falls_left` | `$28` | 1 | IGV (4 or 9) | falls; -1 per death, +1 by score and the room 16 object. Player block. |
| `current_room` | `$29` | 1 | IGV (0) | current room; written by `enter_room_bruce` `$2FA1`. Player block. |
| `room_lanterns_left` | `$2A-$3D` | 20 | IGV, R19 | lanterns left per room. Player block. |
| (unused) | `$3E-$3F` | 2 | IGV | inside the player block; no code uses them |
| `game_cycle` | `$40` | 1 | IGV (0); +1 at R19 | completed cycles; ≠ 0 = hard mode. Player block. |
| `score` | `$41-$43` | 3 | IGV | 24-bit score, high byte first. Player block. |
| `other_player_state` | `$439F-$43BA` | 28 | IGV (copy) | the waiting player's `$28-$43` |
| `next_extra_life_score` / `other_next_extra_life_score` | `$4392` / `$4395` | 3+3 | IGV | extra-fall thresholds, swapped |
| lantern record states | byte 0 of each record in `$4D0C-$4E94` | 92 | IGV, R19 | lantern present (≠ 0) |
| `saved_lantern_flags` | `$0340-$03A0` | 97 (92 used) | IGV (1) | waiting player's record states |
| `room_entry_bonus_flags` | `$0300-$0327` | 40 | IGV; R19 for the current player | 2000-point entry bonus due, index room·2+player |
| `bonus_falls_left` | `$4E95-$4E96` | 2 | IGV (5) | room 16 bonus-fall uses left, per player |
| `room13_floor_bonus_flags` | `$014B-$0152` | 8 (3 per player used) | IGV, R19 (current player) | room 13 floor-band 500-point bonuses |
| `room_script_vars` | `$4E97-$4E9B` | 5 | DR (`$33B3`), then RI | room handler flags and counters |
| `room_without_enemies` | `$7A` | 1 | DR | copy of `room_no_combat_flags` |
| `ninja_spawn_timer` / `yamo_spawn_timer` | `$5D` / `$5E` | 1+1 | DR; on spawn and removal | passes until the next spawn |
| `enemy_entry_x` / `enemy_entry_y` / `enemy_saved_energy` | `$8B-$8C` / `$8D-$8E` / `$8F-$90` | 2+2+2 | set by `enter_room`; cleared by DR (no-combat rooms), LF and on use | enemies following Bruce |
| `room_timer_lo` / `room_timer` | `$87` / `$88` | 1+1 | DR | frames in the room, in 256-frame units in `$88` |
| `frame_parity` | `$7B` | 1 | (toggles) | 0/1 each pass; the handlers of rooms 0-3 and 13 test it |
| `scroll_direction` / `anim_speed_index` | `$65` / `$4321` | 1+1 | DR (0 / 7) | climbing-texture animation |
| `tile_anim_timer` / `tile_anim_col` / `tile_anim_row` | `$4FDE` / `$4FE1` / `$4FE4` | 3+3+3 | DR (timers) | floor-trap slots |
| `actor_move_counters` .. | `$4F57-$4FDA` | `$84` | DR | actor movement history and counters |
| `room_charset_d018` | `$F2` | 1 | DR | `$38`/`$3A`/`$3C`; room 18 defeat sets `$3E` |
| `slider_col` / `slider_row` / `slider_prev_col` | `$6E` / `$6F` / `$70` | 3 | RI (rooms 7, 9, 17) | one sliding tile |
| `hazard_col` / `hazard_row` / `hazard_timer` | `$71-$73` / `$74-$76` / `$77-$79` | 9 | RI (rooms 4, 5, 7, 8, 9, 17) | travelling hazards |
| `sliders_dir`/`col`/`row`/`prev_col`/`min_col`/`max_col` | `$010F`/`$0119`/`$0123`/`$012D`/`$0137`/`$0141` | 6×10 | RI (room 13) | room 13 sliders |
| `fireball_active`/`launch_delay`/`x`/`y` | `$432E`/`$4330`/`$4332`/`$4334` | 4×2 | RI (room 18) | room 18 fireballs |
| `attract_countdown` / `title_timeout_hi` | `$49` / `$4A` | 2 | RI (room 19: `$0458`) | room 19 countdown (frames) |
| `pause_state` | `$0105` | 1 | IGV | bit 7 = paused; the main loop skips the room work |

## 11. Open questions

1. The byte-wise extra-life compare (`$313A`) was not tested at run time.
2. Whether `$3E/$3F` in the player block were meant for something (no code reads them).
3. The dashed exits of rooms 0-9 (no trigger cell in the map) need the rooms 0-9 handlers to confirm which ones are drawn at run time.
4. **Room 17 stops the raster IRQ** in every capture: the main loop waits in `main_loop_wait` `$1C32` for `frame_countdown`, and `irq_playfield_top` (line `$40`, `irq_chain_vector` = `$491E`) never fires (rooms_10_19.md section 9). Every per-frame counter of section 3.2 stops with it. Resolved: The cause was found afterwards (runs/r17_freeze, see rooms.md section "PAL freeze bug"): `draw_room` reads `$D011` at `$09BC` and `$0B33` and writes it back. When the read happens on raster lines 256-311, bit 7 (raster bit 8) is set, so the store sets bit 8 of the raster compare. The pending IRQ line `$40` becomes `$140` (320), which a PAL frame never reaches. In the capture, the redraw read `$9B` on line 279 and the closing RMW ran on line 287, so the bit stayed set. This is a timing bug of the original game on PAL, not something specific to room 17; room 17's redraw just ended in the window in these captures.
