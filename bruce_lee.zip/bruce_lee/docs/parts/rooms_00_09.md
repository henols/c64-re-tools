# Rooms 0-9: the room state machines

This part documents how rooms 0-9 of *Bruce Lee* (Datasoft 1984) change while you play. It covers the per-room init and frame handlers, the shared mechanisms they drive, and the lantern conditions that link the rooms.

Sources:
- Code: `src/room_init.asm`, `src/room_update.asm`, `src/room_tiles.asm`, `src/room_state.asm`, `src/room_entry_traps.asm`, `src/background_touch.asm`, `src/animated_chars.asm`, `src/light_flicker.asm`, `src/lanterns.asm`.
- Data: `assets/rooms/roomNN.json` and `assets/text/messages.json`.
- Runtime evidence, run 1: `.c64-re-tools/local/room_events_diffs.json`, the screenshots `runs/room_events/rNN_{before,t100,t400}.png`, the coverage maps `runs/room_events/evNN.bin` and `preNN.bin`, and `.c64-re-tools/local/cov_all.bin`.
- Runtime evidence, run 2: `.c64-re-tools/local/room_events2_diffs.json`, the screenshots `runs/room_events2/nNN.png`, `cNN_t60.png` and `cNN_t400.png`, the coverage maps `runs/room_events2/allNN.bin`, and the room 4 texture log `room04_texture_every_100_frames`.
- Runtime evidence, run 3: `.c64-re-tools/local/room_events3_diffs.json`, the screenshots `runs/room_events3/*.png`, and the coverage maps `runs/room_events3/r1_hatch.bin`, `r8_l01.bin` and `tex9.bin`.

## 0. Conventions

**Evidence tags.** Every effect carries one of these tags:
- **[run]**: run 1 showed it (screen cells or `room_script_vars` bytes).
- **[run2]**: run 2 showed it (section 0.1).
- **[run3]**: run 3 showed it (section 0.1).
- **[cov]**: coverage shows the code ran, but no screen cell proves the effect.
- **[code]**: from reading the code only.
- Text marked *Conclusion* is an interpretation, not an observation.

**Pass and step.**
- A *pass* is one pass of `main_loop` (`$1BC2`). A pass takes at least 3 video frames, because `frame_countdown` (`$48`) is set to 3 each pass.
- The room handler `run_room_update` (`$3A6F`) runs once per pass.
- `frame_parity` (`$7B`) toggles every pass. A *step* is a pass with `frame_parity` = 0, so one step happens every 2 passes (6 frames).
- Observed: in the runs, 400 frames gave 133-134 passes, measured from the counters in rooms 3, 4, 7 and 9. That matches 3 frames per pass.

**Rows and columns.**
- Tiles are drawn with `print_message` (`$17E2`), which takes a message number, a *text row* X and a column. In this document, "message $1D" means message number `$1D`, not tile `$1D`.
- Text row X covers screen rows 2X-1 (top char) and 2X (bottom char, char | `$80`).
- Text row X is map row X-2.
- Columns are 0-39.
- Lantern records hold a text row.

**Lantern numbering.**
- Lantern *n* of room *r* is the record at `lantern_list_roomRR + 4n`.
- Its first byte is non-zero while the lantern is present and 0 once it is collected (`collect_lantern_at` `$331C`).
- `room_lanterns_left` (`$2A+r`) counts the lanterns still present in room *r*.
- Both are per player: the player block `$28-$43` is saved, and the lantern bytes are swapped by `$0FED`.

**Exits.**
- A cell whose tile is 2, 3, 4 or 5 is an exit trigger. It uses the exit group of that code (`exit2_room`, `exit3_room`, `exit4_room`, `exit5_room`).
- Several room events below create exits by drawing such a tile.

### 0.1 About the runtime experiments

**Run 1** (`room_events`):

- **What was done.** For each room, a snapshot inside the room was started, all 20 bytes `room_lanterns_left` `$2A-$3D` were set to 0, and the game ran for 100 and then 400 frames.
- **Limit.** The lantern records themselves (`lantern_list_roomNN`, `$4D0C-$4E94`) were **not** cleared. This creates a state the game never produces: a count of 0 while the records still say "present". The consequences:
  - Events that test `room_lanterns_left+N` fired.
  - Events that test individual lantern records (rooms 4, 5, 7, 8 and 9) did not fire.
  - Room 1's event is guarded by "room 6 still has lanterns", so it could not fire.
- **Room 5:** the "before" screenshot is the PLAYER 1 screen after a lost fall (879 changed cells). It gives no event evidence.

**Run 2** (`room_events2`) closes most of that gap:
- **Setup.** For each room *r*, Bruce walked from room 0 into `enter_room` (`$2FA1`) with A = *r*, in two ways:
  - **normal (`nNN`):** nothing changed;
  - **collected (`cNN`):** all 92 lantern record state bytes (every `$4CE2` list) **and** `room_lanterns_left` `$2A-$3D` were set to 0 before entry. This is the consistent "everything collected" state.
- **What was recorded:**
  - the cell diffs normal → collected at t60 (60 frames after entry);
  - collected t60 → t400;
  - `room_script_vars` at t400.
- **Caveats:**
  - Every collected-lantern cell also differs (lantern tile → its background tile `$1E`/`$1F`/`$12`); those diffs are not events and are left out below.
  - Bruce lost a fall in room 5, so its t60 → t400 diff is the PLAYER screen; the t60 diff is used there.
  - Because every lantern of every room was 0, the room 1 hatch (which needs room 6 *not* empty) still could not fire, and room 8's "texture down while lantern 3 is present" still could not run.
- **Coverage.** `allNN.bin` reached all the formerly unexecuted event code of rooms 4, 5, 7, 8 and 9, including `open_wall_column_2d` and the left-moving sliders. Still not executed after run 2 (see run 3 below):
  - `$368E-$36A2` (room 1 hatch);
  - `$3AFF-$3B05` (room 8 texture down);
  - `$2C79-$2C91`, `$2CC1-$2CCA`, `$2CE6-$2CEC` (texture pause, wrap/flip, downward move);
  - `$30B0-$30C5` (floor trap slot 2).

**Run 3** (`room_events3`) covers three targeted cases, each compared with a normal entry through `enter_room` (`$2FA1`):
- **`r1_hatch`:** room 1 entered with `room_lanterns_left+0..+2` = 0 and every record of rooms 0-2 = 0. Room 6's counter was left at 6.
- **`r8_l01`:** room 8 entered with records 0 and 1 of room 8 (`$4DF8`, `$4DFC`) = 0 and `room_lanterns_left+8` = 2. Lanterns 2 and 3 stayed present.
- **`tex9`:** room 9 entered normally. `$28-$29`, `$60-$66` and `$4321` were logged every 100 frames for 3000 frames.

The variable dumps cover `$4E95-$4E9B` (7 bytes), so `room_script_vars` (`$4E97`) is the third byte.

Coverage after run 3:
- `$368E-$36A2` (room 1 hatch), `$3AFF-$3B05` (room 8 texture down), and the texture pause, wrap/flip and downward move (`$2C79`, `$2C85`, `$2CC1-$2CC3`, `$2CE6-$2CEA`) all executed.
- Only `$30B0-$30C5` (floor trap slot 2) is still never executed.

### 0.2 What happens when a room is entered

`draw_room` (`$09BC`) runs on every room entry. In order, it does this (all **[code]**):
1. Resets `room_timer`, sets `scroll_direction` (`$65`) = 0 and `anim_speed_index` (`$4321`) = 7.
2. Clears the three floor-trap slots `tile_anim_timer` (`$4FDE-$4FE0`).
3. Chooses the charset: set 0 (`$D018=$38`) for rooms 0-9.
4. Decodes the map.
5. Calls `redraw_taken_lanterns` (`$336E`), which:
   - redraws every collected lantern of this room with its background tile;
   - clears `room_script_vars` `$4E97-$4E9B`;
   - jumps through `room_setup_handlers` (`$4E9C`, an RTS-dispatch table) to the room's init handler.

Consequences:
- The map is drawn again from ROM data on every entry, and the one-shot flags in `room_script_vars` start at 0. So **every event below fires again on every entry, as long as its lantern condition is still true.**
- Animated ones, such as the hatches of rooms 1 and 3, play again on every entry.
- Nothing else stores "event done" across visits.

`draw_room` does not reset the travelling-hazard (`$71-$79`) or slider (`$6E-$70`) variables. Only the init handlers of rooms 4, 5 and 7-9 set them. A room whose frame handler uses them always has an init handler that sets them.

### 0.3 Order inside one pass

`main_loop` runs these in order:
1. `flicker_lights` (`$40BC`).
2. The enemy timers.
3. The `frame_parity` toggle.
4. `run_room_update`, the room frame handler.
5. `actor_background_collision` and `check_actors_background` (`$2E39`): exits, lanterns, deadly chars, floor traps.
6. Sprites and actor movement.

A tile that the room handler draws in a pass is seen by the touch checks in the same pass.

---

## Room 0 (`room00_update` `$3642`, init `room_init_none` `$33F5`)

**Description.** Room 0 is the start room: `init_game_vars` clears zero page, so `current_room` = 0 **[code]**. It is an outdoor courtyard:
- mountains at the top;
- a white bull statue on a lattice pedestal at the left;
- a static blue vine in the middle;
- a two-storey pagoda at the right.

Six lanterns: lanterns 0-1 at text row 7 (columns 31 and 38), and lanterns 2-5 at text row 10 (columns 2, 25, 29, 38).

Exits, both on the right edge to room 1:
- exit 5 at map row 3, column 39, enters at (15,98);
- exit 2 at map row 6, column 39, enters at (16,146).

Spawn point (26,196).

**Init.** `room_init_none` is a single RTS.

**Frame handler: the snorting bull.**

| Variable | Meaning |
|---|---|
| `room_script_vars` (`$4E97`) | step countdown |
| `room_script_vars+1` (`$4E98`) | mouth state (0 = next is "close", 1 = next is "open") |
| `frame_parity` | gate: only steps with parity 0 |

```mermaid
stateDiagram-v2
    [*] --> Dormant
    Dormant --> Dormant: room_lanterns_left+6 != 0
    Dormant --> Close: room 6 empty and step and countdown underflows
    Open --> Open: step, countdown 5..0
    Open --> Close: step, countdown underflows (state 0)
    Close --> Open: next step (state 1)
    Close: Close - message $1D (tile $46) at row 9 col 7, sound $81, state=1
    Open: Open - message $1E (tile $47) at row 9 col 7, state=0, countdown=5
```

| From | Condition | To | Effect | Evidence |
|---|---|---|---|---|
| Dormant | `room_lanterns_left+6` != 0 | Dormant | none | - |
| any | `frame_parity` != 0 | same | none | [code] |
| Open (or entry, countdown 0) | step, `dec $4E97` goes negative, `$4E98`=0 | Close | sound `$81`; message `$1D` (tile `$46`, closed mouth) at text row 9, column 7; `$4E98`=1 | [code] (the run did not catch this 1-step frame) |
| Close | next step (countdown still negative), `$4E98`=1 | Open | message `$1E` (tile `$47`, open mouth) at text row 9, column 7; `$4E98`=0; `$4E97`=5 | **[run]** screen rows 17/18, column 7: `$46/$C6` → `$47/$C7` at t100 and t400; vars `00 00` → `03 00` |

**Timing.** One cycle is 7 steps (14 passes, about 42 frames): the mouth is open for 6 steps and closed for 1 step, with sound `$81` on each close.
- **[run2]** confirms it again: the same cells at t60, and `room_script_vars` `02 00` at t400. Status: Open confirmed; the 1-step Close frame and sound `$81` are still code-only.
- The run's end value `$4E97`=3 fits 67 steps, which is 133-134 passes.
- *Conclusion* from the screenshot `r00_t100.png`: tile `$47` draws the bull with its mouth open.

---

## Room 1 (`room01_update` `$3679`, init `room01_init` `$33F6`)

**Description.** A courtyard between two pagodas, with a static vine in the middle. Six lanterns: lanterns 0-1 at text row 7 (columns 9, 30) and lanterns 2-5 at text row 10 (columns 6, 15, 24, 32).

Exits:

| Exit | Trigger cell | Destination |
|---|---|---|
| 4 | map row 3, column 0 | room 0 at (161,98) |
| 2 | map row 6, column 0 | room 0 at (160,146) |
| 5 | map row 3, column 39 | room 2 at (16,98) |
| 3 | none in the map; created by the hatch below | room 5 at (44,50) |

**Init.** `room_script_vars` = 3 (hatch steps).

**Frame handler: the floor hatch to room 5.**

| Variable | Meaning |
|---|---|
| `room_script_vars` | hatch step: 3 → 2 → 1 → 0 → `$FF` (done) |
| `frame_parity` | gate |

The guard is checked in this order:
1. `frame_parity` = 0;
2. `$4E97` >= 0;
3. `room_lanterns_left+6` != 0 (room 6 must **still have** lanterns);
4. `room_lanterns_left+0 | +1 | +2` = 0 (rooms 0, 1 and 2 empty).

```mermaid
stateDiagram-v2
    [*] --> Closed: init step=3
    Closed --> Closed: rooms 0-2 not empty, or room 6 empty
    Closed --> S2: step (sound $8A), message $12
    S2 --> S1: step, message $11
    S1 --> S0: step, message $10
    S0 --> Open: step, message $0F (exit tiles 3)
    Open --> Open: step < 0, nothing
```

| Step (`$4E97` after `dec`) | Message at text row 12, column 17 (5 cells) | Tiles | Sound |
|---|---|---|---|
| 2 | `$12` | `$11 $5C $5D $5E $5F` | `$8A` |
| 1 | `$11` | `$11 $22 $22 $03 $03` | - |
| 0 | `$10` | `$5C $5D $5E $03 $03` | - |
| `$FF` | `$0F` | `$22 $22 $03 $03 $03` | - |

- After the last step, tiles 3 at columns 19-21 of map row 10 are exit triggers to room 5.
- Timing: 4 steps = 8 passes (24 frames).

**Evidence.**
- **[run], negative:** with every count at 0, including room 6, nothing changed and `$4E97` stayed 3.
- **[cov]:** run 1 executed `$367D-$3684` up to the room-6 test and branched out; the drawing code `$368E-$36A2` first ran in run 3.
- **[run2]:** the collected entry also had room 6 empty. No cell changed and `$4E97` = 3 at t400: a second negative confirmation of the guard.
- **[run3]** (`r1_hatch`, rooms 0-2 empty, room 6 full): the hatch fired.
  - Rows 23/24, columns 17-21 changed `$11 $11 $22 $22 $11` → `$22 $22 $03 $03 $03` (bottom row `$A2 $A2 $83 $83 $83`), already at t60 and unchanged at t400.
  - `$4E97` = `$FF` at t400.
  - `$368E-$36A2` executed.
- **Status:** the guard (both directions) and the final cells are confirmed. The intermediate steps and sound `$8A` are code-only. Walking onto the hatch into room 5 was not tested.

*Conclusion:* once room 6 is cleared, the hatch no longer opens on later visits, because the map redraws it closed. The route room 1 → room 5 then disappears. This looks deliberate, since room 6's own event opens another route (room 6 → room 5).

---

## Room 2 (`room02_update` `$36A6`, init `room_init_none`)

**Description.** Pagodas on two levels, a static vine in the middle, and a bull statue on a pedestal at the right.

Ten lanterns: lanterns 0-4 at text row 7 (columns 5, 9, 22, 26, 30) and lanterns 5-9 at text row 10 (columns 5, 9, 15, 21, 27).

Exits:

| Exit | Trigger cell | Destination |
|---|---|---|
| 4 | map row 3, column 0 | room 1 at (161,98) |
| 2 and 3 | not defined | fall through to group 4 |
| 5 | none in the map; created by the event | room 3 at (16,196) |

**Init.** None.

**Frame handler.** Two parts: a one-shot that opens the exit, and the bull's mouth (the same machine as room 0).

The handler first runs a protection remnant at `$36A6`: `LDX $00,Y` must read `$EF` from the 6510 DDR, or the handler loops forever **[code]**. The crack keeps `$00`=`$EF`.

| Variable | Meaning |
|---|---|
| `room_script_vars+1` | exit one-shot (0 → `$FF`) |
| `room_script_vars+2` | mouth step countdown |
| `room_script_vars` | mouth state |

```mermaid
stateDiagram-v2
    [*] --> Dormant
    Dormant --> ExitOpen: room_lanterns_left+6 == 0 (first pass)
    ExitOpen --> Close: step, countdown underflow, state 0
    Close --> Open: next step
    Open --> Close: 6 steps later
    ExitOpen: one-shot - sound $8A, msg $1A row 11 col 37, msg $07 row 12 col 37
```

| Transition | Condition | Effect | Evidence |
|---|---|---|---|
| Dormant → ExitOpen | `room_lanterns_left+6` = 0 and `$4E98` >= 0 | `$4E98`=`$FF`; sound `$8A`; message `$1A` (`$00 $00 $05`) at text row 11, column 37; message `$07` (`$11 $11 $11`) at text row 12, column 37. Column 39 of map row 9 becomes exit tile 5 (to room 3) in place of the wall `$32`, and the floor below becomes `$11`. | **[run]** row 21: column 37 `$1C`→`$00`, column 39 `$32`→`$05`; row 22: `$9C`→`$80`, `$B2`→`$85`; row 23: column 37 `$4E`→`$11`, column 39 `$39`→`$11`; row 24: `$CE`→`$91`, `$B9`→`$91`. `$4E98`=`$FF`. |
| mouth Close/Open | as room 0, using `$4E99`/`$4E97` | message `$1D` / `$1E` at text row 9, column 33; sound `$81` on close | **[run]** rows 17/18, column 33: `$46`→`$47`. `$4E99`=3 and `$4E97`=0 at the end. |

Timing: the exit appears on the first pass; the mouth runs a 7-step cycle (42 frames).

**[run2]:** the identical cells (rows 17/18 column 33; rows 21-24 columns 37 and 39) and `room_script_vars` `00 FF 03` at t400. Status: confirmed.

---

## Room 3 (`room03_update` `$3702`, init `room03_init` `$33FC`)

**Description.**
- Castle towers.
- Two spike pits at the bottom: tile `$0F` (deadly) at map row 10, columns 9-15 and 21-27.
- A bridge row at text row 6 (map row 4) above the pits.
- Two lanterns at text row 10, columns 29 and 38.

Exits:

| Exit | Trigger cell | Destination |
|---|---|---|
| 4 | map row 9, column 0 | room 2 at (161,197) |
| 3 | none in the map; created by the hatch | room 10 at (16,176) |
| 5 | none; no code in rooms 0-9 draws one | room 0 at (16,98) |

`room_no_combat_flags`=`$FF` and all spawn delays are 0, so no enemies appear here.

**Init.** `room_script_vars` = 3.

**Frame handler.** Two independent machines.

*A. Hatch to room 10* (`$4E97`; the same pattern as room 1):
- Guard: `frame_parity` = 0, `$4E97` >= 0 and `room_lanterns_left+3` = 0.
- Messages `$12`, `$11`, `$10`, `$0F` at text row 12, column 29 (sound `$8A` at the first).

*B. Bridge over the pits.*

| Variable | Meaning |
|---|---|
| `room_script_vars+2` | pass countdown (reload `$20`) |
| `room_script_vars+1` | side (1 = bridge on the right) |

This machine runs on every pass, without the parity gate and without a lantern condition.

```mermaid
stateDiagram-v2
    state "Hatch" as H {
        [*] --> Closed
        Closed --> Opening: room_lanterns_left+3 == 0
        Opening --> Opened: 4 steps (msgs $12,$11,$10,$0F)
    }
    state "Bridge" as B {
        [*] --> Right: first pass (countdown 0 -> -1)
        Right --> Left: 33 passes
        Left --> Right: 33 passes
    }
```

| Machine | Transition | Effect | Evidence |
|---|---|---|---|
| Hatch | steps 2, 1, 0, `$FF` | Text row 12, columns 29-33, ending as `$22 $22 $03 $03 $03`. Tiles 3 are exit triggers to room 10. | **[run]** rows 23/24, columns 29-33: `$11 $11 $22 $22 $11` → `$22 $22 $03 $03 $03`; `$4E97` 3 → `$FF` |
| Bridge | `$4E99` < 0 and `$4E98`=1 | `$4E98`=0. Message 6 (7 × tile `$4B`) at text row 6, column 9, and message `$60` (7 × tile `$09`) at text row 6, column 21: bridge over the left pit. | **[run]** t100: rows 11/12, columns 9-15 `$09`→`$4B` and columns 21-27 `$4B`→`$09` |
| Bridge | `$4E99` < 0 and `$4E98`=0 | `$4E98`=1. Message `$60` at column 9 and message 6 at column 21: bridge over the right pit (as in the map). | **[run]** t400: back to the map state; `$4E99` `$0F`→`$0E` fits 133 passes |

**[run2]:** the hatch cells at t60 are identical to run 1, and `room_script_vars` = `FF 01 20` at t400 (bridge timer just reloaded). Status: hatch and bridge confirmed.

Timing:
- Bridge: 33 passes (about 99 frames) per side.
- Hatch: 8 passes.
- *Conclusion:* tile `$4B` is a walkable bridge. The code does not show this; it rests on the screenshots.

---

## Room 4 (`room04_update` `$3760`, init `room04_init` `$3402`)

**Description.** A purple cave:
- an animated climbing texture (tiles `$61-$63`) in columns 18-21 from top to bottom, with deadly spikes `$0F` under it;
- a lantern in a small chamber on each side at text row 4: lantern 0 at column 11 (tile `$13`), lantern 1 at column 28 (tile `$14`);
- a floor shaft at the bottom left.

Exits:
- exit 2 at map row 2, column 39 → room 5 at (16,194);
- exit 3 at map row 10, columns 1-4 (the shaft) → room 7 at (31,50).

**Init**, in order:
1. `room_script_vars+3` = `$1F`.
2. The hazards (text row, column):

   | Hazard | Position | `hazard_timer` |
   |---|---|---|
   | 0 | (11, 1) | `$FF` |
   | 1 | (7, 11) | `$FF` |
   | 2 | (7, 26) | `$F4` |

**Frame handler.** Six machines run in sequence each pass. Run order: blink L0, L0 taken, blink L1, L1 taken, hazard 0, hazard 1, hazard 2, `animate_scrolling_chars`.

| Variable | Meaning |
|---|---|
| `room_script_vars` | lantern-0 one-shot |
| `room_script_vars+1` | lantern-1 one-shot |
| `room_script_vars+2` | lantern-0 blink counter (0-`$3F`) |
| `room_script_vars+3` | lantern-1 blink counter (init `$1F`) |
| `hazard_*` | 3 travelling hazards (section 4.2) |

```mermaid
stateDiagram-v2
    state "Lantern n (n=0,1)" as L {
        [*] --> Lit
        Lit --> Dark: counter reaches $40 (msg $36/$37)
        Dark --> Lit: counter reaches $20 (msg $34/$35)
        Lit --> Taken: Bruce collects it
        Taken --> Opened: one-shot, sound $8A, blank 4x2 cells, erase hazard n+1
    }
```

| Machine | Condition | Effect | Evidence |
|---|---|---|---|
| Blink L0 | `lantern_list_room04` != 0; `$4E99`+1 = `$20` | message `$34` (tile `$13`, collectible lantern) at text row 4, column 11 | **[run]** t100: rows 7/8, column 11 `$66`→`$13` |
| Blink L0 | `$4E99`+1 = `$40` | `$4E99`=0; message `$36` (tile `$66`, dark, not collectible) at text row 4, column 11 | [code] |
| Blink L1 | `lantern_list_room04+4` != 0; `$4E9A`+1 = `$20` / `$40` | message `$35` (tile `$14`) / message `$37` (tile `$67`) at text row 4, column 28 | **[run]** t100: column 28 `$14`→`$67`. t400 equals "before" for both lanterns; the counters went `$08/$27` → `$0D/$2C`, which is +5 mod 64 (about 133 passes). |
| L0 taken | `lantern_list_room04` = 0, `$4E97` >= 0 | `$4E97`=`$FF`; sound `$8A`; message `$16` (4 blanks) at text rows 8 and 9, column 11 (map rows 6-7, columns 11-14: the chamber floor and the rock below it); `draw_hazard1_frame` frame 6 erases hazard 1 | **[run2]** rows 15/16, columns 11-14 `$2A/$AA`→`$00/$80`; rows 17/18 `$50 $53 $4F $51`→`$00`; `$4E97`=`$FF`. No hazard-1 cell appeared. Sound: code-only. |
| L1 taken | `lantern_list_room04+4` = 0, `$4E98` >= 0 | `$4E98`=`$FF`; `scroll_direction`=0 and `anim_speed_index`=7 (texture restarts its speed ramp upwards); sound `$8A`; message `$16` at text rows 8 and 9, column 25; hazard 2 erased | **[run2]** rows 15-18, columns 25-28 → `$00/$80`; `$4E98`=`$FF`. No hazard-2 cell appeared. The texture reset is code-only (direction was already 0). |
| Hazard 0 | always | text row 11, columns 1-4 (above the exit shaft); alternate frames (tiles `$58-$5A`); start column 1, limit 3, restart wait `$A0`; cycle 105 passes | **[run2]** rows 21/22, column 4: `$58/$D8` (frame 5 at limit column 3) at t60, erased by t400 |
| Hazard 1 | only while lantern 0 is present | text row 7, columns 11-13; normal frames (tiles `$54-$56`); limit `$0C`, wait `$E4`; cycle 36 passes | [cov] |
| Hazard 2 | only while lantern 1 is present | text row 7, columns 26-28; normal frames; limit `$1B`, wait `$E4`; cycle 36 passes | [cov] |

Timing and behaviour:
- Each lantern is lit for 32 passes and dark for 32 passes.
- Because `$4E9A` starts at `$1F`, the two lanterns blink about half a period apart. Lantern 0 is lit for the first 64 passes after entry.
- Lantern chars `$13`/`$14` are the only collectible chars (`pick_up_lantern`), so a lantern can be taken only in its lit half **[code]**.
- No hazard cell appeared in the run 1 screens: hazards 1 and 2 wait for 27 of their 36 passes, and hazard 0 for 95 of its 105 passes.
- **[run2]:** with both lanterns collected, `room_script_vars` = `FF FF 00 1F` at t400. The blink counters `$4E99`/`$4E9A` never moved from their entry values, so the blink code is skipped for collected lanterns (confirmed).

---

## Room 5 (`room05_update` `$38AB`, init `room05_init` `$3428`)

**Description.** A blue cave with three floors of ledges.
- Two lattice ladders at columns 13-15 and 17-19.
- An animated climbing texture at columns 34-36, topped by deadly spikes (tile `$40`) at map row 0, columns 34-36.
- Ten lanterns:
  - text row 3: lanterns 0-4 at columns 2, 6, 28, 32, 38;
  - text row 6: lantern 5 at column 30;
  - text row 10: lanterns 6-9 at columns 2, 23, 26, 30.

Exits:

| Exit | Trigger cell | Destination |
|---|---|---|
| 3 | map row 2, column 39 | room 6 at (16,64) |
| 4 | map row 5, column 39 | room 6 at (16,116) |
| 2 | created at map row 9, column 0 | room 4 at (156,81) |
| 5 | created at map row 0, column 35 | room 1 at (88,102) |

**Init**, in order:
1. A protection remnant loops forever unless `$02` = `$32` **[code]**.
2. Colour RAM `$D89A-$D89C` and `$D8C2-$D8C4` = `$FC` (the spike cells at screen rows 3/4, columns 34-36).
3. The hazards:

   | Hazard | Position | `hazard_timer` |
   |---|---|---|
   | 0 | (9, 27) | `$FF` |
   | 1 | (10, 27) | `$FC` |
   | 2 | (5, 1) | `$F8` |

**Frame handler.**

| Variable | Meaning |
|---|---|
| `room_script_vars+2` | lantern-8 one-shot |
| `room_script_vars+3` | lantern-6 one-shot |
| `room_script_vars+4` | top-exit one-shot |
| `room_script_vars`, `+1` | unused |

```mermaid
stateDiagram-v2
    [*] --> Running
    Running --> L8Done: lantern 8 taken / open cols 25,26 rows 10-12, erase hazard 1
    Running --> L6Done: lantern 6 taken / open col 0 rows 10-12, exit 2 at row 11
    Running --> TopDone: room 6 empty AND (lantern 2 OR lantern 4 taken) / exit 5 at top, open col 30 rows 3-5, col 32 rows 6-8
```

(The three one-shots are independent; each can fire in any order.)

| Event | Condition | Effect | Evidence |
|---|---|---|---|
| L8 | `lantern_list_room05+$20` = 0, `$4E99` >= 0 | `open_wall_column` at text row 10, column 25, and at text row 10, column 26. Each: sound `$8A`, then tiles `$00`, `$00`, `$3E` in text rows 10-12. Hazard 1 erased (frame 6) and stopped. | **[run2]** column 25 rows 19-24: `$32 $32 $2E`→`$00 $00 $3E`. Column 26: row 19 `$13`→`$00` (the column overwrites lantern 8's own cell); rows 21-24 already held `$00`/`$3E`. Hazard-1 stop: code-only. |
| L6 | `lantern_list_room05+$18` = 0, `$4E9A` >= 0 | `open_wall_column` at text row 10, column 0; message `$15` (tile `$02`) at text row 11, column 0: exit to room 4 | **[run2]** column 0: rows 19/20 `$32`→`$00`, rows 21/22 `$32`→`$02/$82` (exit tile), rows 23/24 `$2E`→`$3E` |
| Top | `room_lanterns_left+6` = 0 and (`lantern_list_room05+8` = 0 or `+$10` = 0), `$4E9B` >= 0 | message `$19` (`$61 $05 $63`) at text row 2, column 34 (the spikes become climbing texture with exit tile 5 to room 1 in the middle); `open_wall_column` at text row 3, column 30 and at text row 6, column 32 (sound `$8A` twice) | **[run2]** rows 3/4, columns 34-36: `$40`→`$61 $05 $63`; column 30 rows 5-10: `$32 $32 $2E`→`$00 $00 $3E`; column 32 rows 11-16 the same |
| Hazard 0 | always | text row 9, columns 27-29; normal frames; limit `$1C`, wait `$E0`; cycle 40 passes | [cov] |
| Hazard 1 | while lantern 8 is present | text row 10, columns 27-29; normal; cycle 40 | [cov] |
| Hazard 2 | always | text row 5, columns 1-3; alternate frames; limit 2, wait `$E2`; cycle 38 | [cov] |

Then `animate_scrolling_chars`.

**Runtime.**
- Run 1: no screen evidence (the snapshot was in the PLAYER 1 screen); `room_script_vars` stayed `00 00 00 00 00`.
- **Run 2:** all three events fired; `room_script_vars` = `00 00 FF FF FF`. Bruce lost a fall afterwards, so only the t60 cells count.
- Status: the cells of all three events are confirmed. The sounds and the hazard-1 stop are code-only.

---

## Room 6 (`room06_update` `$39AA`, init `room_init_none`)

**Description.** A purple cave with a two-storey pagoda in the middle.
- An animated climbing texture at columns 35-38 on the right, with spikes (tile `$40`) at map row 0 above it.
- A wall column at column 1 (text rows 5-7) in front of exit 2.
- One floor trap (tile `$60`) at map row 9, column 18.
- Eight lanterns: lanterns 0-5 at text row 5 (columns 8, 10, 14, 22, 26, 28) and lanterns 6-7 at text row 9 (columns 6, 30).

Exits:
- exit 2 at map row 4, column 0 → room 5 at (160,128);
- exits 3 (→ room 5), 4 (→ room 2) and 5 (→ room 0) are defined in the tables but have no trigger cell in the map.

**Init.** None.

**Frame handler.**

| Variable | Meaning |
|---|---|
| `room_script_vars` | wall one-shot |

Then the shared floor-trap machine (section 4.4) and the texture (section 4.5).

```mermaid
stateDiagram-v2
    [*] --> Closed
    Closed --> Open: room_lanterns_left+6 == 0 / open_wall_column_17 row 5 col 1
```

| Event | Condition | Effect | Evidence |
|---|---|---|---|
| Wall | `room_lanterns_left+6` = 0, `$4E97` >= 0 | `$4E97`=`$FF`; sound `$8A`; tiles `$00`, `$00`, `$11` at text rows 5, 6, 7, column 1. Exit 2 at column 0 becomes reachable. | **[run]** column 1: rows 9-12 `$32/$B2`→`$00/$80`, rows 13/14 `$32/$B2`→`$11/$91`; `$4E97`=`$FF` |

Timing: the wall opens on the first pass. **[run2]** gives the identical cells and `$4E97`=`$FF`. Status: confirmed.

---

## Room 7 (`room07_update` `$39C3`, init `room07_init` `$3461`)

**Description.** A brown cave with two upper floors and a bottom corridor. The corridor floor strip (map row 9, columns 5-35) is drawn from the map as tile `$64`, which is deadly.

Thirteen lanterns:
- text row 2: lanterns 0-4 at columns 3, 12, 13, 25, 26;
- text row 5: lanterns 5-10 at columns 5, 6, 12, 13, 25, 26;
- text row 9: lanterns 11-12 at columns 2, 3.

Five floor traps (tile `$60`): map row 2, columns 7 and 29; map row 5, columns 3, 17 and 21.

Exits:
- exit 3 at map row 4, column 39 → room 8 at (15,70);
- exit 4 at map row 8, column 39 → room 8 at (16,192);
- exits 2 and 5 (→ room 0) are defined but have no trigger cell.

**Init.**
- Slider: `slider_col` = `slider_prev_col` = 5, `slider_row` = 11.
- Hazard 0 at (4, `$22`) with `hazard_timer` = `$FF`.

**Frame handler.** Run order:
1. `animate_floor_traps`;
2. one-shot A;
3. one-shot B;
4. hazard 0;
5. slider.

| Variable | Meaning |
|---|---|
| `room_script_vars` | row-2 lanterns one-shot |
| `room_script_vars+1` | row-5 lanterns one-shot |

```mermaid
stateDiagram-v2
    [*] --> Running
    Running --> A: lanterns 0-4 all taken / open_wall_column_17 row 2 col 33 (pass ends)
    Running --> B: lanterns 5-10 all taken / open_wall_column_17 row 5 col 38 (pass ends)
    state "Slider" as S {
        [*] --> Right
        Right --> Left: lanterns 11 and 12 taken
    }
```

| Event | Condition | Effect | Evidence |
|---|---|---|---|
| A | records 0-4 all 0, `$4E97` >= 0 | `$4E97`=`$FF`; sound `$8A`; tiles `$00 $00 $11` at text rows 2-4, column 33. `JMP` ends the handler for this pass, so the hazard and slider skip one pass. | **[run2]** column 33 rows 3-8: `$32 $32 $32`→`$00 $00 $11`; `$4E97`=`$FF`. The skipped pass is code-only. |
| B | records 5-10 all 0, `$4E98` >= 0 | `$4E98`=`$FF`; the same at text rows 5-7, column 38, next to exit 3 at map row 4, column 39; ends the pass | **[run2]** column 38 rows 9-14: `$00 $00 $11`; `$4E98`=`$FF` |
| Hazard 0 | always | text row 4, columns 34-37; alternate frames; limit `$24`, restart column `$22`, wait `$E0`; cycle 41 passes | **[run]** t400: rows 7/8, column 34 `$00`→`$5A`/`$DA` (frame 0 at the start column). **[run2]** columns 36-37 `$58 $59` (frame 3 at the limit column `$24`), erased by t400. |
| Slider right | record 11 or 12 present | Every pass: `slider_prev_col`=column, column+1; when the old column is >= `$23`, the new column is 5. `draw_sliding_tile`: sound `$89`, message `$1C` (tile `$65`) at the old column, message `$1B` (tile `$64`) at the new column, text row 11. Range 5-35, 31 passes per sweep. | **[run]** t100: row 21, column 15 `$64`→`$65`, column 18 `$65`→`$64`; t400: column 25 `$65`→`$64` (+3 and +10 columns, mod 31: 34 and 134 passes) |
| Slider left | records 11 and 12 both 0 | column-1; when the old column is < 6, the new column is `$24`; range 36 down to 5 | **[run2]** t60: row 21 columns 32-36 already `$65` while columns 6-12 are still `$64` (the slider sweeps leftwards from 36); t400: columns 6-31 `$64`→`$65`. Column 36 changed `$2A`→`$65` (see below). |

*Conclusion.*
- On entry the whole strip is deadly (`$64`).
- The slider replaces `$64` with the harmless `$65` behind it, so after its first sweep only the slider cell itself is deadly. The screenshots `r07_*` show a single white-dotted cell on the strip.
- `draw_sliding_tile` plays sound `$89` on every pass while the slider runs.
- **Observed (run2):** moving left, the slider wraps to column 36 (`$24`), one cell past the strip (map row 9, columns 5-35). It overwrites the map tile `$2A` there with `$65`, so the strip grows by one cell (visible in `c07_t60.png`). Moving right never reaches column 36.
- A stray `RTS` byte (`$60`) at `$3A62` follows the handler.

---

## Room 8 (`room08_update` `$3AD4`, init `room08_init` `$3478`)

**Description.** A brown cave of rock pillars with several climbing-texture columns (tiles `$61-$63`), a central texture column, and spikes `$0F` at the bottom.

Four lanterns: lanterns 0-1 at text row 3 (columns 15, 24) and lanterns 2-3 at text row 7 (columns 6, 33).

Exits:

| Exit | Trigger cell | Destination |
|---|---|---|
| 2 | map row 1, column 0 | room 7 at (160,116) |
| 4 | map row 9, column 0 | room 7 at (161,181) |
| 3 | map row 1, column 39 | room 9 at (16,83) |
| 5 | map row 9, column 39 | room 9 at (15,198) |

No enemies: `room_no_combat_flags` = `$FF` and the spawn delays are 0.

**Init.** Hazard 0 at (5, 6) and hazard 1 at (5, `$1B`), with timers `$FF` and `$F2`.

**Frame handler.** Five one-shot passages, then hazards 0 and 1, then the texture.

| Variable | Meaning |
|---|---|
| `room_script_vars+2` | column-14 one-shot |
| `+3` | column-25 one-shot |
| `+4` | top-right one-shot |
| `+0` | left-bottom one-shot |
| `+1` | right-bottom one-shot |

```mermaid
stateDiagram-v2
    [*] --> Running
    Running --> P14: room 7 empty AND lantern 2 taken
    Running --> P25: lanterns 0 and 1 taken (texture down if lantern 3 present)
    Running --> PTopRight: room 8 empty AND room 9 lanterns 2,3 taken
    Running --> PLeftBottom: lantern 2 taken
    Running --> PRightBottom: rooms 7 and 8 empty
```

(The passages are independent one-shots; the diagram shows the trigger of each.)

**[run2]:** all five fired; `room_script_vars` = `FF FF FF FF FF` at t400.

| Event (code order) | Condition | Effect | Evidence |
|---|---|---|---|
| P14 (`$4E99`) | `room_lanterns_left+7` = 0 and `lantern_list_room08+8` = 0 | `open_wall_column` at text row 7, column 14 (tiles `$00 $00 $3E` in rows 7-9, sound `$8A`) | **[run2]** column 14 rows 13-18: `$32 $32 $2E`→`$00 $00 $3E` |
| P25 (`$4E9A`) | `lantern_list_room08` = 0 and `+4` = 0 | If `lantern_list_room08+$C` != 0: `scroll_direction`=1 (down), `anim_speed_index`=7. Then `open_wall_column` at text row 7, column 25. | **[run2]** column 25 rows 13-18: `$00 $00 $3E`. **[run3]** (`r8_l01`, lanterns 0 and 1 taken, lantern 3 present): column 25 rows 13-18 `$32 $32 $2E`→`$00 $00 $3E`; at t400 `$65` = 1 (texture down), `$4E9A` = `$FF`; `$3AFF-$3B05` executed. |
| PTopRight (`$4E9B`) | `room_lanterns_left+8` = 0 and `lantern_list_room09+8` = 0 and `lantern_list_room09+$C` = 0 | `open_wall_column_2d` at text row 2, column 38 (tiles `$00 $00 $11`), opening the way to exit 3 at map row 1, column 39 | **[run2]** column 38 rows 3-8: `$32 $32 $32`→`$00 $00 $11` |
| PLeftBottom (`$4E97`) | `lantern_list_room08+8` = 0 | `open_wall_column` at text row 10, column 1 (in front of exit 4 at map row 9, column 0) | **[run2]** column 1 rows 19-24: `$00 $00 $3E` |
| PRightBottom (`$4E98`) | `room_lanterns_left+7` = 0 and `room_lanterns_left+8` = 0 | `open_wall_column` at text row 10, column 38 (in front of exit 5 at map row 9, column 39) | **[run]** column 38: rows 19-22 `$32/$B2`→`$00/$80`, rows 23/24 `$32/$B2`→`$3E/$BE`; `$4E98`=`$FF` |
| Hazard 0 | always | text row 5, columns 6-12; normal frames; limit `$0B`, wait `$DA`; cycle 50 | **[run]** rows 9/10, columns 9-10: `$00`→`$55 $56` (frame 2 in transit). **[run2]** columns 11-12 `$55 $56` (frame 2 at the limit) at t60, erased at t400. |
| Hazard 1 | always | text row 5, columns 27-33; normal; limit `$20`, wait `$DA`; cycle 50 | **[run]** rows 9/10, columns 32-33: `$54 $55`→`$00` (frame 3 at the limit before, waiting after). **[run2]** columns 32-33 `$55 $56` at t400. |

---

## Room 9 (`room09_update` `$3BB2`, init `room09_init` `$348F`)

**Description.** A brown cave with diagonal climbing-texture "staircases", spike groups `$0F`, and a texture column at columns 35-38. The column is topped by spikes (tile `$40`) at map row 0, columns 35-38. The bottom corridor strip (map row 10, columns 4-24) is tile `$64`, as in room 7.

Five lanterns:
- lantern 0 at text row 2, column 32;
- lantern 1 at text row 7, column 15;
- lanterns 2-4 at text row 10, columns 27, 28, 32.

Exits:
- exit 2 at map row 2, column 0 → room 8 at (160,71);
- exit 3 at map row 9, column 0 → room 8 at (160,192);
- exit 4: none in the map, created at the top right → room 6 at (157,199).

No enemies.

**Init**, in order:
1. Colour RAM `$D89B-$D89E` and `$D8C3-$D8C6` = `$FA` (the spike cells).
2. Slider: column 4, previous column 4, row 12.
3. Hazard 0 at (5, `$10`) and hazard 1 at (6, `$10`), with timers `$FC` and `$FF`.

**Frame handler.**

| Variable | Meaning |
|---|---|
| `room_script_vars+2` | texture-reverse one-shot |
| `room_script_vars` | column-23 one-shot |
| `room_script_vars+1` | top-exit one-shot |

```mermaid
stateDiagram-v2
    [*] --> Running
    Running --> TexDown: lantern 0 taken / scroll_direction=1
    Running --> Col23: lantern 1 taken / open_wall_column row 7 col 23, scroll_direction=0
    Running --> TopExit: room 9 empty / scroll_direction=0, sound $8A, msg $18 row 2 col 35
    state "Slider" as S {
        [*] --> Right
        Right --> Left: lanterns 2 and 3 taken
    }
```

| Event | Condition | Effect | Evidence |
|---|---|---|---|
| TexDown (`$4E99`) | `lantern_list_room09` = 0 | `scroll_direction`=1, `anim_speed_index`=7 (no tiles, no sound) | [cov]+[run2] `$4E99`=`$FF`. In the same pass Col23 and TopExit set the direction back to 0, so no downward move resulted. The direction write of this event alone is code-only. Downward movement itself was confirmed in run 3 (section 4.5). |
| Col23 (`$4E97`) | `lantern_list_room09+4` = 0 | `open_wall_column` at text row 7, column 23; `scroll_direction`=0, `anim_speed_index`=7 | **[run2]** column 23 rows 13-18: `$32 $32 $2E`→`$00 $00 $3E`; `$4E97`=`$FF` |
| TopExit (`$4E98`) | `room_lanterns_left+9` = 0 | `scroll_direction`=0, `anim_speed_index`=7; sound `$8A`; message `$18` (`$61 $04 $04 $63`) at text row 2, column 35. The spikes become climbing texture with exit tiles 4 (to room 6) at columns 36-37. | **[run]** rows 3/4, columns 35-38: `$40`→`$61 $04 $04 $63` (bottom row `$C0`→`$E1 $84 $84 $E3`); `$4E98`=`$FF` |
| Slider right | record 2 or 3 present | column+1; when the old column is >= `$18`, the new column is 4; text row 12, range 4-24 (21 positions); sound `$89` each pass | **[run]** row 23: before column 13, t100 column 5, t400 column 21 (34 and 134 passes mod 21) |
| Slider left | records 2 and 3 both 0 | column-1; when the old column is < 5, the new column is `$18` | **[run2]** t60: row 23 columns 18-24 already `$65`, columns 5-11 still `$64`; t400: columns 5-17 `$64`→`$65` (leftward sweep) |
| Hazard 0 | always | text row 5, columns 16-21; alternate frames; limit `$14`, wait `$C0`; cycle 75 | **[run2]** rows 9/10, columns 18-19 `$59 $5A` (frame 2) at t60, erased by t400 |
| Hazard 1 | always | text row 6, columns 16-21; alternate; cycle 75; starts 3 passes earlier than hazard 0 | **[run2]** rows 11/12, columns 20-21 `$58 $59` (frame 3 at the limit `$14`) at t60, erased by t400 |

Then `animate_scrolling_chars`.

**[run2]:** the top exit cells are identical to run 1; `room_script_vars` = `FF FF FF 00 00` at t400.

---

## 4. Shared mechanisms

### 4.1 Cycling objects (`animate_room_objects` `$104B`, tables `$010F-$014A`)

Within rooms 0-19 only room 13 uses these, every second pass. Rooms 0-9 use the single slider (4.3) instead. They are documented here for completeness **[code]**.

| Table (9 slots, X = 8..0) | Meaning |
|---|---|
| `sliders_dir` `$010F` | 0 = slot off; bit 7 clear = moves left, bit 7 set = moves right |
| `sliders_col` `$0119` | current column |
| `sliders_row` `$0123` | text row. The existing knowledge comment "object type" is wrong: the value goes to `slider_row`. |
| `sliders_prev_col` `$012D` | previous column |
| `sliders_min_col` `$0137` / `sliders_max_col` `$0141` | wrap limits |

Per active slot and call:
1. prev = col.
2. Moving left: col-1, and if col < min then col = max. Moving right: col+1, and if col >= max then col = min.
3. Draw at text row `sliders_row`: `draw_sliding_tile` (messages `$1C`/`$1B`), or on rows 5 and 10 `draw_sliding_tile_alt` (messages `$55`/`$54`). Each draw plays sound `$89`.

States per slot: Off, MovingLeft, MovingRight. No transition between them happens after init (`room13_init` sets them).

### 4.2 Travelling hazards (`$71-$79`)

Three slots X = 0-2:

| Variable | Meaning |
|---|---|
| `hazard_col` `$71,x` | column |
| `hazard_row` `$74,x` | text row |
| `hazard_timer` `$77,x` | phase |

- Drawn with `draw_hazardN_frame` (`$4086`/`$4090`/`$409A`): message `$1F`+phase.
- `draw_hazardN_frame_alt` (`$40A4`/`$40AC`/`$40B4`) draws message `$26`+phase instead.
- Every room handler carries its own inlined copy of the stepping code, with its own limit, restart column and wait value. `step_travelling_hazards` (`$3FDC`) is room 17's loop version.

| Phase (after `inc`) | Normal frame (message, tiles) | Alternate frame | Action |
|---|---|---|---|
| negative | - | - | wait (nothing drawn) |
| 0 | `$1F`: `$56` | `$26`: `$5A` | grow, 1 cell at col |
| 1 | `$20`: `$55` | `$27`: `$59` | |
| 2 | `$21`: `$55 $56` | `$28`: `$59 $5A` | full, 2 cells |
| 3, col < limit | `$25` (erase) at col, then `$21` at col+1 | `$2C`, then `$28` | travel: col+1, phase := 2 |
| 3, col >= limit | `$22`: `$54 $55` | `$29`: `$58 $59` | start shrinking |
| 4 | `$23`: `$00 $55` | `$2A`: `$00 $59` | |
| 5 | `$24`: `$00 $54` | `$2B`: `$00 $58` | |
| 6 | `$25`: `$00 $00` | `$2C`: `$00 $00` | erased |
| 7 | - | - | restart: col := start, phase := W (negative) |

```mermaid
stateDiagram-v2
    [*] --> Wait: init timer (negative or $FF)
    Wait --> Grow: phase reaches 0
    Grow --> Travel: phases 0,1,2
    Travel --> Travel: phase 3 and col < limit / col+1 (1 pass)
    Travel --> Shrink: phase 3 and col >= limit
    Shrink --> Restart: phases 4,5,6
    Restart --> Wait: phase 7 / col=start, phase=W
```

**Rules.**
- Tiles `$54-$56` and `$58-$5A` are deadly: `handle_touched_char` treats `$54-$5A` except `$57` as deadly. So the hazard kills Bruce and removes enemies.
- The erase frames write tile `$00`, so a hazard runs only through empty cells.
- Cycle length = (limit - start) + 263 - W passes (W = the restart phase, unsigned).
- The first appearance after entry comes `$FF` - init timer passes after entry.

| Room | Hazard | Text row | Columns | Frames | Init timer | W | Cycle (passes) | Runs while |
|---|---|---|---|---|---|---|---|---|
| 4 | 0 | 11 | 1-4 | alt | `$FF` | `$A0` | 105 | always |
| 4 | 1 | 7 | 11-13 | normal | `$FF` | `$E4` | 36 | lantern 0 present |
| 4 | 2 | 7 | 26-28 | normal | `$F4` | `$E4` | 36 | lantern 1 present |
| 5 | 0 | 9 | 27-29 | normal | `$FF` | `$E0` | 40 | always |
| 5 | 1 | 10 | 27-29 | normal | `$FC` | `$E0` | 40 | lantern 8 present |
| 5 | 2 | 5 | 1-3 | alt | `$F8` | `$E2` | 38 | always |
| 7 | 0 | 4 | 34-37 | alt | `$FF` | `$E0` | 41 | always |
| 8 | 0 | 5 | 6-12 | normal | `$FF` | `$DA` | 50 | always |
| 8 | 1 | 5 | 27-33 | normal | `$F2` | `$DA` | 50 | always |
| 9 | 0 | 5 | 16-21 | alt | `$FC` | `$C0` | 75 | always |
| 9 | 1 | 6 | 16-21 | alt | `$FF` | `$C0` | 75 | always |

Runtime: frames 0, 2 and 3 were seen in rooms 7 and 8 (run 1). Run 2 also saw frames 2, 3 and 5 of the alternate set in rooms 4, 7 and 9 (`$58-$5A`), and the erase. Status: confirmed except the frames 1 and 4 cells, which never happened to be captured.

### 4.3 The single slider (`$6E-$70`, `draw_sliding_tile` `$404E`)

| Variable | Meaning |
|---|---|
| `slider_col` `$6E` | column |
| `slider_row` `$6F` | text row |
| `slider_prev_col` `$70` | previous column |

The room handler moves it by one column per pass, then `draw_sliding_tile` does this:
1. sound `$89`;
2. message `$1C` (tile `$65`, plain strip) at `slider_prev_col`;
3. message `$1B` (tile `$64`, the dotted strip, deadly) at `slider_col`.

`draw_sliding_tile_alt` (`$4063`) uses messages `$55`/`$54` (tiles `$67`/`$66`).

States: MovingRight and MovingLeft, chosen every pass from lantern records in rooms 7 and 9; room 17 always moves right. Wrap and range details are in rooms 7 and 9.

### 4.4 Floor traps (`trigger_floor_trap` `$306D`, `animate_floor_traps` `$3228`)

**Trigger.**
- An actor touches tile `$60` with contact bit 1 set (`handle_touched_char`). Any actor can trigger it; no actor-number check exists **[code]**.
- `trigger_floor_trap` reads the cell's colour RAM. If its low 3 bits are 5, the trap is already armed-fired and nothing happens.
- Otherwise it takes the first free slot of three: 0, then 1, then 2 (slot 2 never ran in any recorded run). It sets:
  - `tile_anim_timer,x` = 1;
  - `tile_anim_row,x` = the actor's text row - 1;
  - `tile_anim_col,x` = the column - 1;
  - the trap cell's colour RAM = `$FD`.

**Animation.** `animate_floor_traps` runs every pass in rooms 6, 7, 10, 11, 12, 14, 16 and 17. For each slot with timer != 0 it counts up and acts on the old value:

| Timer | Effect |
|---|---|
| 1-7 | delay |
| 8 | sound `$8D`; message `$2F` (`$71 $72 $73`) at (row, col) and message `$30` (`$74 $75 $76`) at (row+1, col): spikes up |
| 12 | messages `$31`/`$32` (`$77-$79` / `$7A-$7C`) |
| 16 | messages `$2F`/`$30` again |
| 20 | message 0 (3 blanks) at the upper row; colour RAM of the trigger cell = `$F8` (re-armed); message `$33` (`$7D $60 $7D`) at the lower row |
| 24 | slot freed |

`draw_room` frees all slots on room entry.

```mermaid
stateDiagram-v2
    [*] --> Armed
    Armed --> Delay: actor touches $60 (colour != 5) / slot, colour $FD
    Delay --> Spikes: timer 8 / sound $8D, msgs $2F,$30
    Spikes --> Spikes: timer 12 msgs $31,$32 / timer 16 msgs $2F,$30
    Spikes --> Retracted: timer 20 / clear, colour $F8, msg $33
    Retracted --> Armed: timer 24 slot free
```

**Timing and effects.**
- The spikes appear 7 passes (21 frames) after the touch and stay for 12 passes.
- Tiles `$71-$7C` are deadly.
- The map has `$11 $60 $11` around each trap, but the retract draws `$7D $60 $7D`. Observed in the maps of rooms 6 and 7: every trap cell sits between two `$11` tiles with colour `$F8`. Whether `$7D` looks the same as `$11` was not checked.
- The run showed no trap: nothing walked onto one.

### 4.5 Animated climbing texture (`animate_scrolling_chars` `$2C70`; `$60-$66`, `$4321`)

Rooms 4, 5, 6, 8 and 9 call it every pass. Rooms 0-3 and 7 have no tiles `$61-$63`.

**What it does.**
- It rewrites the bitmaps of chars `$61`, `$62` and `$63` (top halves) and `$E1-$E3` (bottom halves) in charset `$A000` (rooms 0-9, patterns `anim_char_patterns_rooms_0_9` `$42F1`) or `$A800` (rooms 10-19, patterns `$4309`).
- Each char uses an 8-row pattern rotated by `scroll_offset` (`$64`).
- *Conclusion:* the texture appears to move.
- While Bruce climbs it (action state `$17`, entered through tile `$62`), `action_climb` moves him 2 pixels with it whenever `scroll_timer` = 1: up for `scroll_direction` 0, down for 1 **[code]**.

| Variable | Meaning |
|---|---|
| `scroll_timer` `$60` | passes until the next move; bit 7 = pause mode |
| `scroll_offset` `$64` | 0-7 |
| `scroll_direction` `$65` | 0 = up, 1 = down; reset to 0 on room entry |
| `scroll_moves` `$66` | moves left at this speed |
| `anim_speed_index` `$4321` | 7..0 into `char_anim_delays` `$4CB2` = `$84,8,6,4,2,4,6,8`; reset to 7 on room entry |

```mermaid
stateDiagram-v2
    [*] --> Speed7: room entry (index 7, dir 0)
    Speed7 --> Speed6: 17 moves, 8 passes each
    Speed6 --> Speed5: 17 moves x 6
    Speed5 --> Speed4: 17 x 4
    Speed4 --> Speed3: 17 x 2
    Speed3 --> Speed2: 17 x 4
    Speed2 --> Speed1: 17 x 6
    Speed1 --> Pause: 17 x 8
    Pause --> Speed7: 17 periods of 4 passes / direction flips
```

**Rules.**
- Each speed level makes 17 moves.
- Index 0 (`$84`) is a pause of 17 periods × 4 passes (about 68 passes), with no movement.
- After the pause the index wraps to 7 and `scroll_direction` flips.
- One full direction lasts about 17 × 38 + 68 = 714 passes, about 43 s.
- Room events that set `scroll_direction` and `anim_speed_index` = 7 (rooms 4, 8 and 9) restart the ramp in the given direction. They do not reset `scroll_moves` or `scroll_timer`.

**[run2] texture log** (`room04_texture_every_100_frames`: room 4 snapshot, `$60-$66` and `$4321` every 100 frames for 2400 frames):

| Frames | `anim_speed_index` | Predicted duration of that level (frames) |
|---|---|---|
| 100 | 7 | - |
| 200-400 | 6 | 17 × 6 × 3 = 306 |
| 500-600 | 5 | 204 |
| 700 | 4 | 102 |
| 800-1000 | 3 | 204 |
| 1100-1300 | 6 (index jumped back) | 306 |
| 1400-1500 | 5 | 204 |
| 1600 | 4 | 102 |
| 1700-1800 | 3 | 204 |
| 1900-2100 | 2 | 306 |
| 2200 | 1 | 408 |
| 2300-2400 | 6 (jumped back again) | - |

- **Observed:**
  - The index steps down 7 → 1 at the predicted rates.
  - `scroll_timer` never exceeds the current level's delay.
  - `scroll_direction` stays 0 throughout.
- **Observed:** twice the index jumped from 3 or 1 back to 6, between frames 1000-1100 and 2200-2300.
  - *Conclusion:* only `draw_room` (`$0A3C`) and the one-shot lantern-1 event of room 4 write 7, and the one-shot cannot fire twice in one visit. So the room was redrawn: Bruce lost a fall and respawned (the Yamo attacks him in this snapshot). `draw_room` resets the index but not `scroll_moves`, so the leftover moves end level 7 quickly. The falls were not logged.
- In this room 4 log the index never reached 0.

**[run3] texture log** (`tex9`: room 9, which has no enemies; normal entry; values every 100 frames for 3000 frames). Falls stayed 4 and the room stayed 9 (`$28-$29` = `04 09`) throughout.

| Frames | `anim_speed_index` | `scroll_timer` `$60` | `scroll_direction` `$65` | Notes |
|---|---|---|---|---|
| 160-360 | 7 | ≤ 8 | 0 | level after entry |
| 460-660 | 6 | ≤ 6 | 0 | |
| 760-860 | 5 | ≤ 4 | 0 | |
| 960 | 4 | 1 | 0 | |
| 1060-1160 | 3 | ≤ 4 | 0 | |
| 1260-1460 | 2 | ≤ 6 | 0 | |
| 1560-1860 | 1 | ≤ 5 | 0 | |
| 1960, 2060, 2160 | 0 | `$83`, `$82`, `$81` | 0 | pause: bit 7 set; `scroll_moves` `$10` → `$08` → `$00`; `scroll_offset` stays 1 |
| 2260-2560 | 7 | ≤ 7 | **1** | wrapped to 7, direction flipped |
| 2660-2860 | 6 | ≤ 6 | 1 | |
| 2960-3060 | 5 | ≤ 7 | 1 | |

- **Observed:**
  - The full cycle runs as predicted: the ramp 7 → 1, then the pause at index 0 with `scroll_timer` in pause mode (bit 7) and no change of `scroll_offset`, then the wrap to 7 with `scroll_direction` flipped to 1.
  - The pause lasted between 200 and 400 frames, which fits the predicted 17 × 4 passes ≈ 204 frames.
  - `scroll_moves` falls by 8 per 100 frames in the pause (one period = 4 passes = 12 frames).
- **Observed:** in room 9 the index never jumped back, and no fall was lost. This supports the conclusion above that the two resets in the room 4 log came from room redraws after lost falls; the room 4 falls themselves were not logged.
- **[run3]** `r8_l01`: room 8's event set `$65` = 1 (see room 8).
- **Status:** the ramp, the pause, the wrap and the direction flip are confirmed. The downward move branch `$2CE6` executed in `tex9`.

Evidence:
- [cov]: the speed steps ran in rooms 4, 5, 6, 8 and 9.
- [cov] run 3: the pause (`$2C79`, `$2C85`), the wrap and flip (`$2CC1-$2CC3`) and the downward branch (`$2CE6-$2CEA`) executed in `tex9.bin`.
- The texture changes charset bytes, not screen codes, so the screen diffs cannot show it.

### 4.6 Light flicker (`flicker_lights` `$40BC`, `light_flicker_timers` `$0101-$0103`)

`main_loop` calls it every pass, in every room. Each of the three timers counts down by 1 per pass. At 0 the timer is reloaded with a random 1-15 (`random_byte`, never 0), and random bits are written into one source row (2 pixel rows) of these bottom-half chars:

| Timer | Bits | Chars changed |
|---|---|---|
| `$0101` | `AND $30` / `ORA $CC` / `AND $B8` | `$93` (bottom of lantern tile `$13`) in sets 1 and 0; `$86` (bottom of tile `$06`) in set 0 |
| `$0102` | `AND $30` / `ORA $CC` | `$B1` (bottom of lantern tile `$31`) in sets 1 and 0 |
| `$0103` | `AND $0C` / `ORA $33` / `AND $2E` | `$94` (bottom of lantern tile `$14`) in sets 1 and 0; `$E7` (bottom of room 4's dark lantern tile `$67`) in set 0 |

States per light: Counting → Flicker (new random bits, new random period 1-15 passes) → Counting. *Conclusion:* this is the flame of the collectible lanterns. In demo mode `random_byte` returns 1, so the timer reloads with 1 and the bits are constant.

### 4.7 Passage helpers (`$3A8A-$3AD3`)

| Routine | Effect |
|---|---|
| `open_wall_column` `$3A8A` (A = text row, Y = column) | `play_sound_8a` (keeps A, X and Y); `tile_row`=A, `tile_col`=Y; `draw_tile_down` of messages `$13`, `$13`, `$14` → tiles `$00`, `$00`, `$3E` in three consecutive text rows. **[run]** room 8; **[run2]** rooms 5, 8 and 9. |
| `open_wall_column_17` `$3AA0` | `open_wall_column`, then `tile_row`-1 and message `$17` (tile `$11`) over the third cell. **[run]** room 6: `$00 $00 $11`; **[run2]** rooms 6 and 7. |
| `open_wall_column_2d` `$3AAA` | The same with message `$2D`. Message `$2D` is also tile `$11`, so the result equals `open_wall_column_17` (observed in `messages.json`; the old comment called these "tile `$17`/`$2D`"). Used only by room 8. **[run2]** room 8: `$00 $00 $11`. |
| `draw_column_63_64` `$3AB4` | sound `$8A`; messages `$63`, `$63`, `$64` → tiles `$07`, `$07`, `$0E`. Rooms 10, 12, 14 and 16 only. |
| `draw_tile_down` `$3ACA` | `print_message` (A, X=`tile_row`, Y=`tile_col`), then `tile_row`+1 |

Each is a one-step effect with no state of its own; the calling room's one-shot flag is the state.

---

## 5. Dependency table (cross-room lantern conditions)

"empty" = `room_lanterns_left+r` = 0. "Lr.n" = lantern record n of room r is 0 (collected). All conditions are tested every pass while Bruce is in the room that owns the event.

| Event room | Event | Depends on (room: lanterns) | Unlocks / effect | Vars | Evidence |
|---|---|---|---|---|---|
| 0 | bull snorts | room 6 empty | cosmetic (mouth animation, sound `$81`) | +0/+1 | [run] |
| 1 | floor hatch | rooms 0, 1 and 2 empty **and room 6 NOT empty** | exit 3 → room 5 (44,50) | +0 | [run3] (fires with room 6 full); [run]/[run2] (no hatch with room 6 empty) |
| 2 | right-edge exit | room 6 empty | exit 5 → room 3 (16,196) | +1 | [run] |
| 2 | bull snorts | room 6 empty | cosmetic | +0/+2 | [run] |
| 3 | floor hatch | room 3 empty | exit 3 → room 10 (16,176) | +0 | [run] |
| 3 | bridge | none | alternating bridge over the spike pits | +1/+2 | [run] |
| 4 | blank chamber floor, hazard 1 off | L4.0 | passage below the left lantern | +0 | [run2] |
| 4 | blank chamber floor, hazard 2 off, texture up | L4.1 | passage below the right lantern | +1 | [run2] (texture: code) |
| 5 | open columns 25-26 | L5.8 | passage on the bottom floor; hazard 1 off | +2 | [run2] (hazard: code) |
| 5 | open column 0 + exit tile | L5.6 | exit 2 → room 4 (156,81) | +3 | [run2] |
| 5 | top exit + two columns | **room 6 empty** and (L5.2 or L5.4) | exit 5 → room 1 (88,102) at the top of the texture | +4 | [run2] |
| 6 | open left wall | room 6 empty | reach exit 2 → room 5 (160,128) | +0 | [run] |
| 7 | open column 33 | L7.0-L7.4 | passage at text rows 2-4 | +0 | [run2] |
| 7 | open column 38 | L7.5-L7.10 | passage to exit 3 → room 8 | +1 | [run2] |
| 7 | slider direction | L7.11, L7.12 | slider reverses (left) | - | [run2] |
| 8 | open column 14 | **room 7 empty** and L8.2 | inner passage | +2 | [run2] |
| 8 | open column 25 | L8.0 and L8.1 (texture down while L8.3 is present) | inner passage | +3 | [run2]; texture down [run3] |
| 8 | open top-right | room 8 empty and **L9.2 and L9.3** | passage to exit 3 → room 9 (16,83) | +4 | [run2] |
| 8 | open bottom-left | L8.2 | passage to exit 4 → room 7 (161,181) | +0 | [run2] |
| 8 | open bottom-right | **room 7 empty** and room 8 empty | passage to exit 5 → room 9 (15,198) | +1 | [run] |
| 9 | texture down | L9.0 | texture direction | +2 | flag [run2]; direction code |
| 9 | open column 23, texture up | L9.1 | inner passage | +0 | [run2] (texture: code) |
| 9 | top exit | room 9 empty | exit 4 → room 6 (157,199); spikes removed | +1 | [run] |
| 9 | slider direction | L9.2, L9.3 | slider reverses (left) | - | [run2] |

Rooms that other rooms depend on: **room 6** (rooms 0, 1, 2 and 5), **rooms 0-2** (room 1), **room 7** (room 8), **room 9 lanterns 2/3** (room 8). No handler of rooms 10-18 reads the lanterns of rooms 0-9. `draw_room` reads rooms 12, 14 and 16 for room 11, not rooms 0-9. Observed by the pipeline agent: entering room 11 with rooms 12, 14 and 16 empty redirects to room 13 (`respawn_in_room` with X=`$0D`).

**For room reordering** (conclusions from the code):
- Each handler hard-codes:
  - `room_lanterns_left+N` (absolute room numbers);
  - `lantern_list_roomNN+4k` (record addresses inside one room's list);
  - text rows and columns of the tiles it draws;
  - which exit code (2-5) it creates, whose destination comes from that room's row in `exit2_room`…`exit5_room` / `exit*_x` / `exit*_y`.
- Moving a room number means changing all of these.
- Also:
  - `room_setup_handlers`/`room_frame_handlers`;
  - the charset choice in `draw_room` (rooms < 10 use set 0);
  - the pattern choice in `animate_scrolling_chars` (room < 10);
  - `handle_touched_char` (tile `$66` is deadly only from room 10 on; tiles `$2D`/`$2E` give the bonus fall only in room 16).

---

## 6. Open questions

1. **Exits without trigger cells:**
   - room 3 exit 5 (→ room 0);
   - room 6 exits 3, 4 and 5 (→ rooms 5, 2 and 0);
   - room 7 exits 2 and 5 (→ room 0).

   No map cell has the tile, and no handler of rooms 0-9 draws it. Are they leftovers, or does some other code write these tiles?
2. **Is tile `$4B` (room 3 bridge) solid ground,** and is tile `$7D` (floor trap after retracting) the same graphic as `$11`?
3. **The hazards' visual nature** (sparks or flames) and the difference between the normal set (`$54-$56`) and the alternate set (`$58-$5A`): direction or colour?
4. **Does the room 1 hatch lead to room 5?** Run 3 confirmed the hatch cells (exit tile 3), but nobody walked onto them.
5. **Room 7's slider moving left overwrites map column 36** (`$2A`→`$65`). Is this an original bug or harmless?
6. **The bull's sound `$81`** is the same effect an enemy plays when it turns toward Bruce (caller `$225F` in `object_actions.asm`). Its game meaning (a snort or a growl) is not known.

## 7. Runtime experiments

**Done in run 2** (requests 1-7 of the first version, run together as the collected entry):
- Requests 2 (room 4), 3 (room 5), 4 (room 7), 5 (room 8) and 6 (room 9): done. All tile effects are confirmed (see each room).
- Request 7 (texture): done in part. The ramp 7 → 1 is confirmed; the pause and the flip were not reached.
- Request 1 (room 1): **not** done in the requested form. Every room was empty, so room 6 was empty too and the guard held.

**Done in run 3:**
- Room 1 with only rooms 0-2 empty: done. The hatch fires (room 1 section).
- Room 8 texture down: done. `$65` = 1 and `$3AFF-$3B05` executed (room 8 section).
- Texture pause and flip: done in room 9. The full cycle is confirmed (section 4.5).

**Still open** (not run; another agent owns the emulator):
1. **Room 1 → room 5:** after the hatch opens, walk Bruce onto exit tile 3 at text row 12, columns 19-21 and check that he arrives in room 5 at (44,50).
2. **Floor trap:** walk Bruce onto the `$60` tile in room 6 (map row 9, column 18) and capture every pass from timer 1 to 24. Also try two enemies on traps to fill slot 2.
3. **Bull (rooms 0/2):** capture every pass for 20 passes after the event, to see the 1-step closed frame (tile `$46`) and sound `$81`.
4. **Exits without triggers:** set a breakpoint on writes of tile values 2-5 to screen `$8C78-$8FE7` in rooms 3, 6 and 7, to find out whether anything creates them.
5. **Texture log falls** (optional): repeat the room 4 log and record falls (`$1826` `lose_fall` hits), to confirm the cause of its two index resets. Run 3's room 9 log already supports that cause.
