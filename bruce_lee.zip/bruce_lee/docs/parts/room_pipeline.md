# Room data and the room pipeline

This part describes the room data of *Bruce Lee* (Datasoft 1984, C64 REV.2) and the code that turns it into a screen. It covers:
- the per-room tables;
- the one-time preparation at boot;
- `draw_room` (`$09BC`) step by step;
- the raster IRQ chain that shows the room;
- the room transitions;
- a worked decode of room 0;
- the screen memory layout.

**Sources.**
- The unpacked image `unpacked/image.bin`, read through the DXA listing `analysis/game.lst` and the generated source `src/*.asm`.
- The project knowledge (revision `20261016T001022.813-e22lx2`).
- The coverage map `.c64-re-tools/local/cov_all.bin`.
- The room snapshots `runs/rooms/roomNN.vsf`.
- The decoded rooms `assets/rooms/roomNN.json`.
- The runtime experiment `runs/room_special` (`.c64-re-tools/local/room_special_diffs.json`).

**Conventions.**
- Addresses are C64 addresses, and names are knowledge names.
- **Observed** marks a fact read from the code, the data, a snapshot or the coverage.
- **Conclusion** marks an interpretation.
- Names in *italics* (for example *`draw_room_map_setup`*) come from the batch `.c64-re-tools/local/batch_rooms_pipeline.json`, which has not been applied yet. In today's source these addresses are still `l_xxxx`.

---------------------------------------------------------------------------------------------

## 0. Overview

```
cold_start $0400 (once)
  expand_charset $4892 x4        $9000-$9FFF (4 x 128 tiles, 8 bytes)  ->  $A000-$BFFF (4 VIC charsets)
  build_collision_masks $512F    actor frames -> 96-byte masks (over $9000-$9FBF and in $C000-$CADF)
restart_to_title / start_game / start_demo / next_player_turn
  init_game_screen $0763         game IRQ chain, text row tables $0869, colour RAM, VIC bank 2, status line, Bruce
draw_room $09BC (each room entry; IRQs off)
  blank, colour RAM <- room_char_colours, [room 11 -> room 13], entry bonus, room state,
  spawn timers, Atari colour set, charset choice ($F2), RLE map -> screen rows 3-24,
  redraw_taken_lanterns $336E -> room init handler, unblank, run_room_update $3A6F -> frame handler
every frame (raster IRQ chain)
  irq_frame_top $48C1 (line $FD) -> irq_playfield_top $491E (line $40) -> irq_colour_split $4982 (per listed line) -> ...
every main-loop pass (at most every 3 frames)
  run_room_update -> room frame handler; check_actors_background -> exits -> enter_room $2F8E -> draw_room
```

---------------------------------------------------------------------------------------------

## 1. Catalogue of the per-room data

All the tables below are indexed by `current_room` (`$29`, 0-19) unless noted.

### 1.1 Overview per room (generated from the image)

| room | map | colour RAM `$47A0` | `$F2` | bands `$480B` | raster list `$4833` | Atari set `$4AA8` | lanterns `$4CCE` | lantern list `$4CE2` | no-combat `$4C9E` | init handler | frame handler |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | $68F9 | $FE | $38 | $47C8 | $47F9: $78,$97 | $4AD0 | 6 | $4D0C | $00 | $33F5 | $3642 |
| 1 | $6A09 | $FE | $38 | $47C8 | $47FC: $78,$97 | $4AD0 | 6 | $4D25 | $00 | $33F6 | $3679 |
| 2 | $6B3E | $FE | $38 | $47C8 | $47FF: $78,$97 | $4AD0 | 10 | $4D3E | $00 | $33F5 | $36A6 |
| 3 | $6C9D | $FE | $38 | $47C8 | $4802: $62,$97 | $4AD0 | 2 | $4D67 | $FF | $33FC | $3702 |
| 4 | $6E1B | $FC | $38 | $47D1 | $4805: - | $4AE4 | 2 | $4D70 | $00 | $3402 | $3760 |
| 5 | $6F82 | $FC | $38 | $47D1 | $4805: - | $4AE4 | 10 | $4D79 | $00 | $3428 | $38AB |
| 6 | $70DD | $FC | $38 | $47D1 | $4805: - | $4AE4 | 8 | $4DA2 | $00 | $33F5 | $39AA |
| 7 | $7227 | $FF | $38 | $47D4 | $4805: - | $4AE9 | 13 | $4DC3 | $00 | $3461 | $39C3 |
| 8 | $7311 | $FA | $38 | $47D4 | $4805: - | $4AE9 | 4 | $4DF8 | $FF | $3478 | $3AD4 |
| 9 | $7491 | $FA | $38 | $47D4 | $4805: - | $4AE9 | 5 | $4E09 | $FF | $348F | $3BB2 |
| 10 | $75D8 | $F9 | $3A | $47D7 | $4806: $56 | $4AEE | 3 | $4E1E | $00 | $33F5 | $3C90 |
| 11 | $774C | $FB | $3A | $47DD | $4805: - | $4AFD | 3 | $4E2B | $FF | $33F5 | $3CC0 |
| 12 | $7843 | $F9 | $3A | $47D7 | $4806: $56 | $4AEE | 3 | $4E38 | $00 | $34BD | $3E4C |
| 13 | $79C6 | $FA | $3A | $47E0 | $4805: - | $4B02 | 0 | $4E45 | $FF | $34C3 | $3E7C |
| 14 | $7A46 | $F9 | $3A | $47D7 | $4806: $56 | $4AEE | 4 | $4E4A | $00 | $358D | $3ECC |
| 15 | $7BB4 | $FC | $3A | $47E3 | $4808: $B6,$C7 | $4B0C | 6 | $4E5B | $00 | $3593 | $3EE6 |
| 16 | $7C5C | $F9 | $3A | $47D7 | $4806: $56 | $4AEE | 2 | $4E74 | $00 | $359F | $3F5B |
| 17 | $7D8D | $FF | $3A | $47EC | $4805: - | $4B1B | 2 | $4E7D | $FF | $35C4 | $3F71 |
| 18 | $7E90 | $FE | $3C | $47EF | $4805: - | $4B25 | 1 | $4E86 | $FF | $35FA | $3CDC |
| 19 | $7FE0 | $FF | $3A | $47F2 | $4805: - | $4B2A | 0 | $4E8B | $FF | $425F | $4272 |

The handler columns give the targets: the table value plus 1.

| room | exit 2: dest / x / y | exit 3 | exit 4 | exit 5 | spawn A `$4BAE/$4BC2` | spawn B `$4BD6/$4BEA` |
|---|---|---|---|---|---|---|
| 0 | 1 / $10 / $92 | - | - | 1 / $0F / $62 | $1A / $C4 | $9F / $62 |
| 1 | 0 / $A0 / $92 | 5 / $2C / $32 | 0 / $A1 / $62 | 2 / $10 / $62 | $18 / $62 | $95 / $92 |
| 2 | - | - | 1 / $A1 / $62 | 3 / $10 / $C4 | $30 / $C4 | $96 / $C4 |
| 3 | - | 10 / $10 / $B0 | 2 / $A1 / $C5 | 0 / $10 / $62 | $20 / $C0 | $38 / $C4 |
| 4 | 5 / $10 / $C2 | 7 / $1F / $32 | - | - | $94 / $B4 | $96 / $B4 |
| 5 | 4 / $9C / $51 | 6 / $10 / $40 | 6 / $10 / $74 | 1 / $58 / $66 | $22 / $51 | $28 / $C2 |
| 6 | 5 / $A0 / $80 | 5 / $A0 / $66 | 2 / $16 / $51 | 0 / $20 / $51 | $86 / $B3 | $81 / $72 |
| 7 | 0 / $30 / $51 | 8 / $0F / $46 | 8 / $10 / $C0 | 0 / $20 / $51 | $1C / $44 | $1F / $74 |
| 8 | 7 / $A0 / $74 | 9 / $10 / $53 | 7 / $A1 / $B5 | 9 / $0F / $C6 | $14 / $46 | $00 / $00 |
| 9 | 8 / $A0 / $47 | 8 / $A0 / $C0 | 6 / $9D / $C7 | - | $12 / $C6 | $00 / $00 |
| 10 | 3 / $A0 / $C4 | 11 / $10 / $C4 | - | - | $34 / $8C | $96 / $5C |
| 11 | 10 / $A0 / $5A | 12 / $10 / $5C | 14 / $10 / $5E | 16 / $10 / $5C | $40 / $4C | $00 / $00 |
| 12 | - | 11 / $34 / $BE | 14 / $10 / $BE | - | $18 / $5C | $70 / $5C |
| 13 | 15 / $10 / $C3 | - | - | - | $98 / $32 | $00 / $00 |
| 14 | - | 11 / $50 / $BE | 12 / $A0 / $BE | 16 / $10 / $BE | $18 / $5C | $92 / $BE |
| 15 | 13 / $A0 / $C4 | 17 / $10 / $B3 | - | - | $1C / $C3 | $7A / $C4 |
| 16 | - | 11 / $80 / $BE | 14 / $A0 / $BE | - | $18 / $5C | $81 / $8E |
| 17 | 15 / $A0 / $93 | 18 / $10 / $C6 | - | - | $18 / $B4 | $00 / $00 |
| 18 | 17 / $A0 / $44 | 19 / $10 / $96 | - | - | $18 / $C6 | $00 / $00 |
| 19 | - | - | - | - | $12 / $95 | $00 / $00 |

A `-` means that the destination, x and y are all 0.

| room | `ninja_first_spawn_delay` $130B | `ninja_respawn_delay` $131F | `ninja_entry_preference` $1333 | `yamo_first_spawn_delay` $1347 | `yamo_respawn_delay` $135B | `yamo_entry_preference` $136F |
|---|---|---|---|---|---|---|
| 0 | $68 | $A0 | $02 | $F0 | $EE | $80 |
| 1 | $78 | $A0 | $02 | $EE | $EE | $80 |
| 2 | $78 | $A0 | $00 | $EE | $EE | $00 |
| 3 | $00 | $00 | $00 | $00 | $00 | $00 |
| 4 | $70 | $70 | $80 | $C0 | $EE | $80 |
| 5 | $18 | $0C | $80 | $C0 | $60 | $02 |
| 6 | $30 | $30 | $02 | $A0 | $EE | $00 |
| 7 | $50 | $18 | $02 | $B0 | $C0 | $80 |
| 8 | $00 | $00 | $00 | $00 | $00 | $00 |
| 9 | $00 | $00 | $00 | $00 | $00 | $00 |
| 10 | $08 | $0C | $02 | $30 | $30 | $80 |
| 11 | $00 | $00 | $00 | $00 | $00 | $00 |
| 12 | $04 | $04 | $80 | $20 | $20 | $80 |
| 13 | $12 | $08 | $00 | $C0 | $EE | $00 |
| 14 | $08 | $08 | $02 | $20 | $30 | $00 |
| 15 | $08 | $08 | $00 | $30 | $50 | $00 |
| 16 | $08 | $08 | $80 | $20 | $30 | $02 |
| 17 | $12 | $08 | $00 | $C0 | $EE | $00 |
| 18 | $00 | $00 | $00 | $00 | $00 | $00 |
| 19 | $00 | $00 | $00 | $00 | $00 | $00 |

### 1.2 Table by table

The "Readers" column gives the instruction address. A reader marked *(not run)* is in code that no recorded run executed.

| Table | Address, name | Size | Element / encoding | Readers (routine, address) and when |
|---|---|---|---|---|
| **Map pointers** | `$4B34` `room_map_ptrs_lo`, `$4B49` `room_map_ptrs_hi` | 21 + 21 bytes | Split low and high bytes of the map stream address. Entry 20 = entry 19 (`$7FE0`). | `draw_room` `$0AAF`/`$0AB4` (*`draw_room_map_setup`*), at each room draw. Entry 20 is never read: the index is `current_room` <= 19. |
| **Map streams** | `$68F9-$817F` `room00_map`..`room19_map` | 6279 bytes, 128-416 per room | RLE byte stream (section 2.7). It ends with `$80`. The streams are contiguous. | `room_decode_next` `$0AD7`, `room_literal_loop` `$0AE3`, `room_run_loop` `$0B0B`, through `(work_ptr_b),y` (`$06/$07`), at each room draw. |
| **Charset selection** | Code at `$0A9B-$0AAD`, no table. Result in `room_charset_d018` `$F2`. | 1 byte of RAM | `$D018` value: `$38` for rooms 0-9 (set 0 `$A000`), `$3C` for room 18 (set 2 `$B000`), `$3A` for the others (set 1 `$A800`). `$3E` (set 3 `$B800`) is set only by the room 18 defeat effect. | **Writers:** `init_game_screen` `$07E3` (`$38`), `draw_room` `$0AAD`, `room18_defeat_effect` `$3DFA` (`$3E`) and `$3E09` (`$3C`). **Readers:** `irq_playfield_top` `$492A` every frame; `game_frame_update` `$15D0` every frame, which derives `charset_hi` `$7C` = `$A0/$A8/$B0/$B8` for the collision test (`$5330`, `$5350`, `$5378`) and for `animate_scrolling_chars` (`$2D1E`). |
| **Colour RAM colour** | `$47A0` `room_char_colours` | 20 bytes | Colour RAM byte, always `$F8-$FF`. Bit 3 = multicolour; bits 0-2 = the colour of `%11` pixels. | `draw_room` `$09DC`. The value fills `$D878-$DBFF` at each room draw. |
| **Split colour pointers** | `$480B` `room_split_colour_ptrs` | 20 words | Pointer to 12 bytes = 4 triplets (`$D021`, `$D022`, `$D023`) in the pool `$47C8-$47F4`. | `irq_frame_top` `$48EE`/`$48F3`, every frame. |
| **Split colour pool** | `$47C8` `room_band_colours` (rooms 0-3), then *`band_colours_rooms_4_6`* `$47D1`, *`_7_9`* `$47D4`, *`_10_12_14_16`* `$47D7`, *`band_colours_room11`* `$47DD`, *`_room13`* `$47E0`, *`_room15`* `$47E3`, *`_room17`* `$47EC`, *`_room18`* `$47EF`, *`_room19`* `$47F2` | 45 bytes (15 triplets) | `$Fx` colour bytes. The low nibble is the colour; the VIC ignores the high nibble. The rooms read 12 bytes from their pointer, so the groups overlap. | `irq_frame_top` loop `$4904` (*`irq_copy_room_colours`*): copies to `raster_colours` `$0153-$015E` every frame. |
| **Raster line pointers** | `$4833` `room_raster_line_ptrs` | 20 words | Pointer to a list of raster lines ended by `$FD`. | `irq_frame_top` `$48F9`/`$48FE`, every frame. |
| **Raster line lists** | `$47F9` `room_raster_split_lists` (room 0), *`raster_lines_room1`* `$47FC`, *`_room2`* `$47FF`, *`_room3`* `$4802`, *`raster_lines_none`* `$4805` (`$FD` only), *`raster_lines_rooms_10_12_14_16`* `$4806`, *`raster_lines_room15`* `$4808` | 18 bytes | 0-2 raster lines, then `$FD`. | `irq_frame_top` `$490C`: copies 4 bytes to `current_raster_splits` `$47F5-$47F8` every frame. Bytes after the `$FD` are copied too, and nothing uses them. |
| **Atari colour set** (leftover) | `$4AA8` `room_atari_colour_ptrs` -> `$4AD0` `room_atari_colour_records` | 20 words; pool of 100 bytes = 20 records of 5 | 20 bytes per room = 4 records of 5. Values such as `$04 $00 $06 $88 $0E`. | `draw_room` `$0A87`/`$0A8C`, loop `$0A93` (*`draw_room_copy_atari_set`*): copies 20 bytes to `$0153-$0166` at each room draw. `irq_frame_top` overwrites `$0153-$015E` on the next frame. Only `save_raster_colours` `$102D` (screen saver, *not run*) reads `$015F-$0166`. Section 1.3. |
| **Exit destination** | `$4B5E` `exit2_room`, `$4B72` `exit3_room`, `$4B86` `exit4_room`, `$4B9A` `exit5_room` | 4 x 20 bytes | Destination room for map tile 2, 3, 4 or 5. | `take_exit_char02..05` `$2F43`, `$2F58`, `$2F6D`, `$2F82`, when an actor touches an exit tile. |
| **Exit entry x** | `$4BFE` `exit2_x`, `$4C26` `exit3_x`, `$4C4E` `exit4_x`, `$4C76` `exit5_x` | 4 x 20 bytes | `actor_x` in the destination room: multicolour pixels, sprite X = 2*x. **0 = fall through to the next group** (2 -> 3 -> 4 -> 5; group 5 has no fall-through). | `$2F4C`, `$2F61`, `$2F76`, `$2F8B`. |
| **Exit entry y** | `$4C12` `exit2_y`, `$4C3A` `exit3_y`, `$4C62` `exit4_y`, `$4C8A` `exit5_y` | 4 x 20 bytes | `actor_y`. Sprite Y = y + `$1D`. | `$2F48`, `$2F5D`, `$2F72`, `$2F87`. |
| **Spawn point A** | `$4BAE` `room_spawn_x`, `$4BC2` `room_spawn_y` | 2 x 20 bytes | Start position of Bruce, and enemy spawn point A. | `init_actor` `$0BE9`/`$0BED` (Bruce at `init_game_screen`; enemies, and always in demo mode); `respawn_in_room` `$321E`/`$3222`; `action_blocked_step` `$24E3`/`$24E7`. |
| **Spawn point B** | `$4BD6` `room_alt_spawn_x`, `$4BEA` `room_alt_spawn_y` | 2 x 20 bytes | Enemy spawn point B. It is 0/0 in rooms 8, 9, 11, 13, 17, 18 and 19. | `init_actor` `$0C20`/`$0C24` (`actor_use_spawn_b`). |
| **Enemy spawn delays** | `$130B` `ninja_first_spawn_delay`, `$1347` `yamo_first_spawn_delay` | 2 x 20 bytes | Start value of `ninja_spawn_timer` `$5D` / `yamo_spawn_timer` `$5E`. The timers count main-loop passes (`tick_enemy_timers` `$0DA4`). | `draw_room` `$0A4E`/`$0A53`, at each room draw. |
| **Enemy respawn delays** | `$131F` `ninja_respawn_delay`, `$135B` `yamo_respawn_delay` | 2 x 20 bytes | The timer reload value after a spawn. | `try_spawn_yamo` `$0D20`, `try_spawn_ninja` `$0DE4`. `reset_yamo_timer`/`reset_ninja_timer` `$0D46`/`$0D76` read them through a self-modified operand (`$0D55`, `$0D85`). |
| **Enemy entry preference** | `$1333` `ninja_entry_preference`, `$136F` `yamo_entry_preference` | 2 x 20 bytes | 0 = random spawn point A or B. Non-zero = 3 times in 4 (random < `$C0`) the sign of `yamo_entry_preference` chooses: positive = A, negative = B. The Ninja path also uses the **Yamo** sign (`$0C38`). | `init_actor` `$0C04`, `$0C10`, `$0C2C`, `$0C38`, at each enemy spawn. |
| **No-combat flag** | `$4C9E` `room_no_combat_flags` | 20 bytes | 0 or `$FF`. `$FF` in rooms 3, 8, 9, 11, 13, 17, 18 and 19. | `draw_room` `$0A41`: copies to `room_without_enemies` `$7A` and, when non-zero, clears `enemy_entry_x`. `main_loop` `$1BF1` (via `$7A`): no `tick_enemy_timers`/`try_spawn_*`. `main_loop` `$1C1E` (table): skips `check_sprite_collisions`. |
| **Lantern counts** | `$4CCE` `room_lantern_counts` | 20 bytes | Lanterns per room (90 in all). | `reset_room_table_2a` `$10C7` copies to `room_lanterns_left` `$2A-$3D` at game start (`init_game_vars`) and after the ending (`room19_congratulations_update`, *not run*). |
| **Lantern lists** | `$4CE2` `lantern_list_ptrs` -> `lantern_list_room00..20` `$4D0C-$4E94` | 21 words; 4-byte records | Records: [state (non-zero = present), cell drawn when taken (bit 7 ignored), column 0-39, **text row** of `set_text_line_ptrs` (map row = row - 2)]. A byte with bit 7 set ends the list. Rooms 13, 19 and 20 hold one placeholder record (`01 00 00 00`). Entry 20 is never read: every reader indexes by a room number 0-19 (`swap_player_lantern_flags` stops at `cmp #$14`). | `redraw_taken_lanterns` `$3372` (room draw); `collect_lantern_at` `$3328` (lantern touched); `reset_room_lanterns` `$33DA` (game start); `swap_room_object_bytes` `$1007` (player change). |
| **Lanterns left (RAM)** | `$2A-$3D` `room_lanterns_left` | 20 bytes | Count per room. | `draw_room` `$09FC` (rooms 12, 14 and 16 for the room 11 redirect); `collect_lantern_at` `$3365` (decrement); the room frame handlers (passages open). |
| **Room init handlers** | `$4E9C` `room_setup_handlers` | 20 words, RTS addresses (target - 1) | Run once per room draw. | `redraw_taken_lanterns` `$33C1`/`$33C5` (*`dispatch_room_init`* `$33B3`). |
| **Room frame handlers** | `$4EC4` `room_frame_handlers` | 20 words, RTS addresses | Run once at the end of `draw_room` and then on every main-loop pass. | `run_room_update` `$3A73`/`$3A77`. |
| **Room script variables (RAM)** | `$4E97-$4E9B` `room_script_vars` | 5 bytes | Counters and one-shot flags of the room handlers. | Cleared at `$33B3` before each init handler. |
| **Entry bonus flags (RAM)** | `$0300` `room_entry_bonus_flags` | 40 bytes, index room*2 + player | 1 = the 2000-point first-entry bonus is still due. `init_game_vars` `$0FA8` sets all of them to 1, then clears room 0 for both players (`$0FB0`). | `draw_room` `$0A14` (test), `$0A19` (LSR clears it). `reset_player_room_flags` `$10E0` (*not run*). |
| **Saved lantern flags (RAM)** | `$0340` `saved_lantern_flags` | 97 bytes (92 used) | The lantern states of the waiting player, one byte per record of rooms 0-19. | `swap_player_lantern_flags` `$0FED` (player change). |
| **Unreferenced** | `$4CBA-$4CCD` | 20 bytes | `32 1F 1E 1A 18 1D 1B 33 35 30 72 5F 5E 5A 58 5D 5B 73 75 70`. The second 10 bytes are the first 10 plus `$40`. | No reader in the code or in the coverage. Meaning unknown. |

**Per-room behaviour coded by room number** (observed, no table):
- `check_exit_direction` `$30D4`: room 11 takes exits in any direction.
- `actor_char_coords` `$1C39`: in room 13 actor y gets +4.
- `touch_deadly_char` `$304B`: no deadly chars in room 18.
- `handle_touched_char` `$2EFA`: char `$66` is deadly from room 10 on.
- `$2EEA`: chars `$2D`/`$2E` are the bonus-fall object only in room 16.
- `game_frame_update` `$15AD`: the sound effect players get the room in X.
- `animate_scrolling_chars`: patterns at `$42F1` for rooms 0-9 and `$4309` for rooms 10-19.
- The charset choice at `$0A9B`.
- The room 11 redirect at `$09F6` (section 2.2).

### 1.3 The Atari colour set (`$4AA8` / `$4AD0`)

**Observed.**
- The pool `$4AD0-$4B33` holds 20 records of 5 bytes. Room pointers:

  | Rooms | Pointer |
  |---|---|
  | 0-3 | `$4AD0` |
  | 4-6 | `$4AE4` |
  | 7-9 | `$4AE9` |
  | 10, 12, 14, 16 | `$4AEE` |
  | 11 | `$4AFD` |
  | 13 | `$4B02` |
  | 15 | `$4B0C` |
  | 17 | `$4B1B` |
  | 18 | `$4B25` |
  | 19 | `$4B2A` |

  These are exactly the same groups as `room_split_colour_ptrs`.
- Each room reads 20 bytes. For room 19 (`$4B2A`) the 20 bytes run past the pool into `room_map_ptrs_lo` (`$4B34-$4B3D`).
- First records:

  | Address | Bytes |
  |---|---|
  | `$4AD0` | `04 00 06 88 0E` |
  | `$4AD5` | `04 00 0A 0E 34` |
  | `$4AE4` | `84 00 70 0E 60` |
  | `$4B25` | `00 82 82 68 8C` |

- `draw_room` copies the 20 bytes to `$0153-$0166` (`$0A93`). The next `irq_frame_top` overwrites `$0153-$015E` with the C64 triplets. `$015F-$0166` are read only by `save_raster_colours` `$102D`, which the screen saver calls (no run reached it).
- The coverage shows reads of `$015F-$0166`.

**Conclusions.**
- The coverage reads come from the dummy read of `STA abs,Y` at `$0A95`: the 6510 reads the target address before it writes. They are not reads by game code.
- 5 bytes per band is the number of Atari playfield colour registers (COLPF0-COLPF3 and COLBK). Values such as `$88`, `$0E` and `$34` are typical Atari hue and luminance values.
- The table is the colour set of the Atari version, kept and copied, with no effect on the C64 picture.
- The knowledge comment at `$0A83` called this copy "room_params". No table or variable with that name exists. The batch corrects the comment.

---------------------------------------------------------------------------------------------

## 2. `draw_room` (`$09BC`) step by step

### 2.1 Callers and context

| Caller | Address | State before the call |
|---|---|---|
| `start_game` | `$074C` | SEI at `$070E`, display blanked. `init_game_vars` cleared `current_room` (zero page `$03-$F5`), so the room is 0. `init_game_screen` built the IRQ chain and placed Bruce. |
| `start_demo` | `$056D` | SEI at `$0531`, then the same as `start_game`. |
| `enter_room` | `$2FCC` | SEI at `$2FC5`, stack reset to `$FF`, `current_room` = destination. Section 5. |

**Observed:** all three callers disable IRQs before the call. The raster chain stops for the whole draw, and the display is also blanked inside.

### 2.2 Steps in execution order

```
draw_room:                                              ; $09BC
  ; --- blank ---
  D011 &= $EF                       ; $09BC  DEN off: the screen shows only the border colour
  saved_sprite_enable($47) = D015 & $1F   ; $09C4  keep actor sprites 0-4, drop 5-7
  D015 = 0                          ; $09CB  all sprites off
  for x = 39..0: screen_ram[$8C00+x] = $20   ; $09D0/*draw_room_clear_row0* $09D4: clears screen row 0
                                    ;        (the version-line row; the status line is row 1)
  ; --- colour RAM fill ---
  a = room_char_colours[current_room]      ; $09DC
  for x = 0..255: $D878+x = $D900+x = $DA00+x = $DB00+x = a   ; *draw_room_fill_colour* $09E1
                                    ;        => $D878-$DBFF (screen rows 3-24 and the unused $DBE8-$DBFF)
  clear_fireball_shapes()           ; $09F0 -> $423F
  silence_all_sound()               ; $09F3 -> $255E
  ; --- room 11 special path ---
  draw_room_special:                ; $09F6
  if current_room == 11 and (room_lanterns_left[12] | [14] | [16]) == 0:
      D015 = saved_sprite_enable    ; $0A04
      X = 13; JMP respawn_in_room   ; $0A09 -> $3217 -> enter_room -> draw_room(13)
  ; --- entry bonus ---
  draw_room_bonus:                  ; $0A0E
  x = current_room*2 + current_player
  if room_entry_bonus_flags[x] != 0:            ; $0A14
      room_entry_bonus_flags[x] >>= 1           ; $0A19 (1 -> 0)
      add_score(A=$07, X=1); add_score(A=$D0, X=2)   ; $0A1C-$0A27: + $0007D0 = 2000 points
  ; --- room state reset ---
  draw_room_reset:                  ; $0A2A
  for y = $83..0: $4F57[y] = 0      ; *draw_room_clear_moves* $0A2E: actor_move_counters, actor_moved_down/left/right, actor_move_history
  room_timer_lo($87) = room_timer($88) = scroll_direction($65) = 0   ; $0A34
  anim_speed_index($4321) = 7       ; $0A3A
  room_without_enemies($7A) = room_no_combat_flags[room]   ; $0A41
  if != 0: enemy_entry_x[0] = enemy_entry_x[1] = 0  ($8B/$8C)   ; $0A48: no enemy follows into this room
  ; --- enemy timers ---
  *draw_room_spawn_timers*:         ; $0A4E
  ninja_spawn_timer($5D) = ninja_first_spawn_delay[room]
  yamo_spawn_timer($5E)  = yamo_first_spawn_delay[room]
  if game_cycle($40) != 0: both = 3                 ; $0A5C (not run)
  if human_opponent_mode($42CA) != 0: yamo_spawn_timer = 8   ; $0A67
  ; --- Bruce state ---
  *draw_room_reset_bruce*:          ; $0A6B
  actor_contact[0]($B6) = 1; actor_state_timer[0]($CE) = 4
  tile_anim_timer[0..2]($4FDE-$4FE0) = 0             ; free the floor trap slots
  actor_state[0]($BF) = 0; actor_step_delay[0]($0106) = 0
  ; --- Atari colour set ("room_params") ---
  work_ptr_b = room_atari_colour_ptrs[room]          ; $0A83-$0A8F
  for y = 19..0: raster_colours[$0153+y] = (work_ptr_b)[y]   ; *draw_room_copy_atari_set* $0A93
  ; --- charset choice ---
  a = $38; if room >= 10: a = (room == 18) ? $3C : $3A      ; $0A9B-$0AAB
  *draw_room_map_setup*:            ; $0AAD
  room_charset_d018($F2) = a
  work_ptr_b($06) = room_map_ptrs[room]               ; map stream
  work_ptr_a($04) = $8C78  colour_ptr_a($10) = $D878  ; screen row 3: top chars
  work_ptr_c($08) = $8CA0  colour_ptr_b($12) = $D8A0  ; screen row 4: bottom chars
  draw_count($F3) = $27                               ; 39 = columns left - 1
  Y = 0                                               ; $0AD5
  ; --- RLE decoder $0AD7-$0B2D (2.3) ---
  ...
room_decode_done:                   ; $0B30
  redraw_taken_lanterns()           ; $0B30 -> $336E: taken lanterns + room init handler (2.5)
  D011 |= $10                       ; $0B33 display on
  D015 = saved_sprite_enable        ; $0B3B
  JMP run_room_update               ; $0B40 -> $3A6F: room frame handler; its RTS returns to the caller of draw_room
```

**Room 11 special path (`$09F6-$0A0D`).** This answers the coordinator's question.

**Observed in the code:**
- When room 11 is drawn and rooms 12, 14 and 16 have no lanterns left, `draw_room` restores the sprite enable and jumps to `respawn_in_room` with X = 13.
- `respawn_in_room` (`$3217`) sets `current_actor` = 0 and `$4E` = 13, and loads A/Y = `room_spawn_x/y[13]` = `$98/$32`. It then jumps to `enter_room`.
- `enter_room` places Bruce at (`$98`,`$32`) and sets `current_room` = 13. It stores and removes the enemies, as in any transition (section 5). It then calls `draw_room` again, now for room 13.
- The special path uses **no extra map data**. It does not use map pointer entry 20 (`$4B34+20/$4B49+20`): that entry is never read, because `room_map_ptrs` is indexed by `current_room` <= 19.
- What the player sees is **room 13**: map `$79C6`, charset set 1, init handler `room13_init` `$34C3`, frame handler `room13_update` `$3E7C`.
- Room 11 gives no entry bonus on this path, because the bonus code comes after the test. Room 13 gives its own bonus if it is due.

**Observed in the runtime evidence** (`room_special_diffs.json`, key `room11_special`; coverage `runs/room_special/room11_special.bin`):
- After the redirected entry, `$0029` = `$0D` (snapshot `r11_special`, bytes at `$0028`: `04 0d …`). The normal entry has `$0B`.
- `$0A04`, `respawn_in_room` `$3217`, `room13_init` `$34C3` and `room13_update` `$3E7C` executed. `room11_update` `$3CC0` did not execute.
- Of the 678 screen cells that differ from a normal room 11 entry, 662 equal the decoded room 13 map (`assets/rooms/room13.json`, top char = cell & `$7F`, bottom = `|$80`).
- The other 16 cells are at (screen row, col) (9,19), (9,31), (13,17), (13,22), (19,8), (19,31), (23,9), (23,29) and the rows below them. They hold `$66/$64` where the map has `$67/$65`.

**Conclusion:** the 16 cells are objects that `room13_update` animates through `animate_room_objects` (`$3EC0`). They are not a different map.

**Wizard defeat.** Snapshot series `wizard_defeat`:
- **Observed:** `room_charset_d018` goes from `$3C` to `$3E` (charset set 3, `$B800`). It is still `$3E` 400 frames later.
- **Code:**
  - `room18_defeat_effect` (`$3DAF`) writes `$3E` at `$3DFA` on each step.
  - While its counter is still >= `$11`, it writes `$3C` instead at `$3E09` when the random value is < `$10`. This gives the flashing between sets 2 and 3.
  - Nothing restores `$F2` until the next `draw_room`. After the effect, room 18 stays on set 3.
  - The room 18 exits lead to rooms 17 and 19, and `draw_room` then selects `$3A`.

### 2.3 The RLE decoder `$0AD5-$0B2D`

**Registers and variables:**

| Register or variable | Role |
|---|---|
| Y | Always 0. Every access is `(zp),Y` with Y = 0. |
| X | Run or literal counter. |
| A | The cell value. |
| `work_ptr_b` `$06/$07` | Stream pointer. |
| `work_ptr_a` `$04/$05` | Top-char pointer. |
| `work_ptr_c` `$08/$09` | Bottom-char pointer. |
| `colour_ptr_a` `$10/$11` | Colour RAM pointer, top. |
| `colour_ptr_b` `$12/$13` | Colour RAM pointer, bottom. |
| `draw_count` `$F3` | Columns left in the current map row, minus 1. |

**Helpers:**

| Helper | Address | Action |
|---|---|---|
| `inc_ptr_04` | `$4786` | `$04/$05` += 1 |
| `inc_ptr_06` | `$478D` | `$06/$07` += 1 |
| `inc_ptr_08` | `$4794` | `$08/$09` += 1 |
| `inc_colour_ptr_a` | `$0B51` | `$10/$11` += 1 |
| `inc_colour_ptr_b` | `$0B58` | `$12/$13` += 1 |
| `set_tile_colour_f8` | `$0B5F` | Writes `$F8` through `$10` and `$12`, returns A & `$7F`. |
| `room_draw_next_cell` | `$485B` | Row advance (below). |

The bytes at `$0B4A` (`E6 06 D0 02 E6 07 60`) are an unused copy of `inc_ptr_06`. Coverage 0.

```
room_decode_next:                          ; $0AD7
  b = (work_ptr_b)[0]
  if b < $80: goto room_run                ; $0AD9 BPL
  n = b & $7F                              ; $0ADB
  if n == 0: goto room_decode_done         ; $0ADD  ($80 = end of map)
  X = n; inc_ptr_06()                      ; $0ADF/$0AE0  skip the control byte
room_literal_loop:                         ; $0AE3   literal run: n distinct cells follow
  v = (work_ptr_b)[0]
  if v & $80: v = set_tile_colour_f8(v)    ; $0AE7  colour RAM top+bottom = $F8, v &= $7F
*room_literal_store*:                      ; $0AEA
  (work_ptr_a)[0] = v                      ; top char = tile
  (work_ptr_c)[0] = v | $80                ; bottom char = tile + 128
  inc_ptr_04(); inc_ptr_06(); inc_ptr_08(); inc_colour_ptr_a(); inc_colour_ptr_b()
  room_draw_next_cell()                    ; $0AFF
  X -= 1; if X != 0: goto room_literal_loop
  goto room_decode_next                    ; $0B05
room_run:                                  ; $0B07   repeat run: next byte repeated b times
  X = b; inc_ptr_06()                      ; point at the cell value (b = $00 would give 256 cells)
room_run_loop:                             ; $0B0B
  v = (work_ptr_b)[0]                      ; the same byte each time
  if v & $80: v = set_tile_colour_f8(v)    ; $0B0F
*room_run_store*:                          ; $0B12
  (work_ptr_a)[0] = v; (work_ptr_c)[0] = v | $80
  inc_ptr_04(); inc_ptr_08(); inc_colour_ptr_a(); inc_colour_ptr_b()   ; no inc_ptr_06 here
  room_draw_next_cell()                    ; $0B24
  X -= 1; if X != 0: goto room_run_loop
  inc_ptr_06()                             ; $0B2A skip the value byte
  goto room_decode_next                    ; $0B2D
```

**Colour rule.** Only cells with bit 7 write colour RAM (`$F8`: multicolour, `%11` pixels black). Cells without bit 7 keep the room colour from the fill at `$09E1`. The decoder never writes a non-`$F8` colour.

**`room_draw_next_cell` `$485B`:**
```
push A
draw_count -= 1
if draw_count < 0:                         ; after the 40th cell of a row
    draw_count = $27
    work_ptr_a += 40; work_ptr_c += 40; colour_ptr_a += 40; colour_ptr_b += 40
pop A; return
```
After 40 cells the four pointers have each moved 40 bytes, so they already point one screen row lower. The extra 40 skips the row that the other half of the cell used:
- the top pointer goes from screen row 3+2R to 3+2R+2;
- the bottom pointer goes from row 4+2R to 4+2R+2.

**Size and overrun (observed):**
- The streams of rooms 0-3, 5, 6, 8, 9, 11, 12, 14-16 and 19 hold 440 cells (11 rows x 40).
- Rooms 4, 7, 10, 13, 17 and 18 hold 442 cells. The two extra cells are tile 0 without bit 7. They are written to `$8FE8/$8FE9`, inside the screen RAM after the 1000 visible bytes, and as `$80` to `$9010/$9011`, inside collision mask 0 at `$9000`.
- They do not write colour RAM, because bit 7 is clear.
- `$9010/$9011` is text row 13 of the row tables (section 3.3).
- The streams have no row structure. Runs cross row ends freely, because only `draw_count` tracks the columns.

### 2.4 Cost

**Observed:**
- Per literal cell: 6 JSRs, plus `set_tile_colour_f8` for bit-7 cells.
- Per run cell: 5 JSRs.
- Room 0 decodes 272 stream bytes into 440 cells.

### 2.5 The tail: `redraw_taken_lanterns` and the init handler

```
redraw_taken_lanterns:                     ; $336E
  lantern_ptr($14) = lantern_list_ptrs[room]
  y = 0
*redraw_lantern_loop*:                     ; $337E
  s = (lantern_ptr)[y]
  if s & $80: goto dispatch_room_init      ; end of list
  if s != 0: goto *redraw_lantern_skip*    ; $33AC: present -> y += 4
  ; taken lantern ($3384-$33AB, not run in any recorded run)
  cell = (lantern_ptr)[y+1]; col = (lantern_ptr)[y+2]; row = (lantern_ptr)[y+3]; temp_y = y+3
  set_text_line_ptrs(row)                  ; $1A67: work_ptr_a = top-row address of text row `row`
  (work_ptr_a)[col]    = cell & $7F
  (work_ptr_a)[col+40] = (cell & $7F) | $80
  y = temp_y + 1; goto redraw_lantern_loop
*dispatch_room_init*:                      ; $33B3
  room_script_vars[0..4] = 0               ; $4E97-$4E9B
  push hi, lo of room_setup_handlers[room] ; $33C1/$33C5
  RTS                                      ; -> handler; its RTS returns to $0B33 in draw_room
```

**Observed:**
- The lantern redraw does not touch colour RAM. The cell keeps the colour that the map gave to the lantern cell.
- The text row is the `print_message` row: screen rows 2*row-1 and 2*row, map row = row - 2 (section 7).

**Init handlers** (`room_setup_handlers` `$4E9C`). They run with the display still blanked and IRQs off:

| Handler | Rooms | Action |
|---|---|---|
| `room_init_none` `$33F5` | 0, 2, 6, 10, 11 | RTS only. |
| `room01_init` `$33F6`, `room03_init` `$33FC` | 1, 3 | `room_script_vars` = 3. |
| `room04_init` `$3402` | 4 | Hazards. |
| `room05_init` `$3428` | 5 | Hangs unless `$02` = `$32` (protection remnant); colour cells `$FC`; hazards. |
| `room07_init` `$3461` | 7 | Slider and hazard. |
| `room08_init` `$3478` | 8 | Hazards. |
| `room09_init` `$348F` | 9 | Colour cells, slider, hazards. |
| `room12_init` `$34BD`, `room14_init` `$358D` | 12, 14 | `room_script_vars` = 1. |
| `room13_init` `$34C3` | 13 | 8 moving objects; the limits depend on `game_cycle`. |
| `room15_init` `$3593` | 15 | `room_script_vars` 0-2 = 1. |
| `room16_init` `$359F` | 16 | Colour cells; erases the bonus-fall object when it is used up. |
| `room17_init` `$35C4` | 17 | Colour cell, slider, hazards. |
| `room18_init` `$35FA` | 18 | Refills colour RAM with `$FE`, sprite set-up, `$432E-$4337`. |
| `room19_init` `$425F` | 19 | Countdown `$49/$4A` = `$0458`, clears row 0. |

The colour RAM changes of these handlers are included in `assets/rooms/roomNN.png` (`setup_changes`).

**Last step: `run_room_update` `$3A6F`.**
- `draw_room` jumps here (`$0B40`) after it sets `D011 |= $10` (display on) and restores `D015`.
- `run_room_update` pushes `room_frame_handlers[room]` (`$3A73`/`$3A77`) and executes RTS.
- The frame handler runs once, and its RTS returns to the instruction after the caller's `JSR draw_room`.
- **Observed:** the frame handler therefore runs once per room draw before the main loop, still with IRQs off. After that, `main_loop` calls `run_room_update` on every pass (`$1C0A`).

### 2.6 After `draw_room`: actor placement, display and IRQs

**Bruce is placed before the draw:**
- `enter_room` stores `actor_x`/`actor_y` at `$2F9A-$2F9D`.
- At game start, `init_game_screen` jumps to `init_actor` (`$082A`), which reads `room_spawn_x/y[current_room]` and writes the sprite registers (`actor_place_sprites` `$0C4D`).

**Enemies are not placed at room draw.** Their spawn timers run in `main_loop`, and `init_actor` places each enemy when it spawns (`actor_pick_spawn` `$0BFA`):
- the follow entry point (`enemy_entry_x/y`), or
- spawn point A or B (section 5.3).

**Per caller after the draw:**
- **`enter_room`:** `draw_object_sprites` (`$2FCF` -> `$2584`) builds the sprite data of the active actors. Then CLI (`$2FD2`) and `JMP main_loop` (`$2FD3`).
- **`start_game` / `start_demo`:** they set `demo_input_ptr` = `$F300` (`demo_input_data`), set `D011 |= $10` (already set by `draw_room`), CLI and `JMP main_loop`.

**Observed:**
- Sprite X/Y registers are written by `actor_place_sprites` (in `init_actor`) and every frame by `update_sprite_registers` (called from `game_frame_update`).
- After CLI, the raster IRQ continues with the handler that `irq_chain_vector` (`$0408`) holds and the compare line set before the SEI.

---------------------------------------------------------------------------------------------

## 3. One-time preparation that the rooms depend on

### 3.1 Charset expansion `expand_charset` `$4892`

**Calls (observed):**

| Call | Source | Destination | Note |
|---|---|---|---|
| `$0494` | `$9000` (`charset_src_0`) | `$A000`/`$A400` (`room_charset_0`) | |
| `$04B1` | `$9400` | `$A800`/`$AC00` | |
| `$04CE` | `$9800` | `$B000`/`$B400` | |
| `$04ED` | `$9C00` | `$B800`/`$BC00` | Also the warm-start path `boot_warm_start`. |

`draw_count` (`$F3`) = `$7F` for every call. Input pointers: `work_ptr_a` = source, `work_ptr_b` = top-half destination, `work_ptr_c` = bottom-half destination.

```
expand_charset:                            ; $4892
  Y = 0
  repeat:                                  ; once per source char, draw_count+1 = 128 times
    for k = 0..3:                          ; $4896  source rows 0-3
        A = (work_ptr_a); (work_ptr_b) = A; work_ptr_b++; (work_ptr_b) = A; work_ptr_b++; work_ptr_a++
    for k = 0..3:                          ; expand_charset_bottom $48AA  source rows 4-7
        A = (work_ptr_a); (work_ptr_c) = A; work_ptr_c++; (work_ptr_c) = A; work_ptr_c++; work_ptr_a++
    draw_count -= 1
  until draw_count < 0
```

**Result:**
- Char `c` (0-127) of the VIC charset = source rows 0,0,1,1,2,2,3,3 of tile `c`.
- Char `c+128` = source rows 4,4,5,5,6,6,7,7.
- A map cell with tile `t` shows char `t` above char `t|$80`: one 8x16 multicolour tile, each source row two pixel rows high.

**Verified:** the expansion of the image source equals `$A000-$BFFF` in the snapshots, except the bytes that the light flicker changes at run time (`formats.md` 1.2). Example: tile `$0A` source `AA AA AA AA AA A8 80 00` gives char `$0A` = `AA x8` at `$A050` and char `$8A` = `AA AA A8 A8 80 80 00 00` at `$A450`. These are the snapshot bytes of room 0.

**Why `$9000` is not used directly.** In VIC bank 2 (`$8000-$BFFF`), the VIC sees the character ROM at `$9000-$9FFF`, so RAM there cannot hold a charset or a screen. **Observed:** the game keeps the packed sources there and later overwrites them with collision masks (`build_collision_masks` `$512F`).

### 3.2 Collision mask build `build_collision_masks` `$512F`

The mask build runs once, called at `$04F0`, right after the four expansions.

```
build_collision_masks:                     ; $512F
  loop until protection_sig_a+$16 ($CF8F) == $B9 and == protection_sig_b+$16 ($CFAF)   ; protection remnant
  for X = $D1 (209) down to 1 step 2:      ; X = odd frame f+1, current_actor($51) used as the counter
      if actor_frame_addr_hi[X] != 0:      ; $1239+X: odd frames point at mask_buffer $CAE0, or hi = 0
          build_frame_mask(X)              ; overlay layer mask into $CAE0
      else:
          mask_buffer[$00..$5F] = 0        ; $514A
      X -= 1                               ; even frame f
      build_frame_mask(X)                  ; body layer mask into its own destination
      dest = actor_frame_addr[X]           ; $1167+X / $1239+X: $9000-$9FBF or $C000-$CADF
      for y = $5F..0: dest[y] |= mask_buffer[y]
  JMP $0080                                ; colour_cycle_counter: holds RTS (crack patch)

build_frame_mask(X):                       ; $517E
  src = frame_src_lo/hi[X]; n = frame_height[X] + 1
  col0 = dest, col1 = dest+$20, col2 = dest+$40
  narrow frame (frame_wide_flag[X] == 0):
     for r in 0..n-1: nibble_bits($1F) = src[r]
        col1[r] = double_nibble_bits()     ; low nibble, each bit -> %11
        col0[r] = double_nibble_bits()     ; high nibble
        col2[r] = 0
  wide frame:
     for r in 0..n-1: nibble_bits = src[2r] (via the moving pointer); col1[r], col0[r] as above
        col2[r] = double_nibble_bits()     ; nibble_bits is empty by now -> always 0
  rows r = n..31 of all three columns = 0
```

`double_nibble_bits` (`$51FF`) shifts 4 bits out of `$1F`, bit 0 first. Each set bit becomes a `%11` pair, so a sprite pixel pair matches one multicolour char pixel.

**Observed:**
- 71 distinct even-frame destinations exist, in `$9000-$9FBF` and `$C000-$CA80`.
- The odd frames use `$CAE0` or none (hi byte 0).
- The masks need the expanded charsets to be done first, because they overwrite the charset sources.

**Link to the room** (per frame):
- `actor_background_collision` (`$5212`) ANDs the shifted mask with the bitmaps of the chars under the actor. It reads the char bitmaps at `charset_hi * 256 + 8 * char` (`$5330`, `$5350`, `$5378`), which is the room charset that `$F2` selects.
- It reads the colour RAM through `colour_row_hi` (`$5117`).
- The resulting contact bits in `actor_contact` (`$B6`) and `$A7` depend on the room's pixel colours: `%01`, `%10`, and `%11` with the room colour or with `$F8`.

### 3.3 Text row tables `build_text_row_tables` `$0869`

**When it runs (observed):** the tables are not built in `cold_start`. `init_game_screen` builds them (`$0773-$078F`) each time it runs:
- before the title (`$052B`);
- at game start (`$0749`) and demo start (`$0553`);
- after each lost fall (`$1886`).

The content is always the same.

```
build_text_row_tables(A=$D8, Y=$8B):       ; $0869
  top[0] = $8BD8
  for k = 1..13: top[k] = top[k-1] + $50                 ; text_row_top_lo/hi $4338/$434C
  bottom[0] = top[0] + $28 = $8C00
  for k = 1..13: bottom[k] = bottom[k-1] + $50           ; text_row_bottom_lo/hi $4360/$4374
init_game_screen then patches ($077A-$078F):
  top[0] = $8C00; bottom[0] = bottom[1] = $DE00          ; I/O area, a write there has no effect
```

Snapshot `room00.vsf`:

| Text row k | Top | Bottom | Screen rows | Map row |
|---|---|---|---|---|
| 0 | `$8C00` | `$DE00` | 0 (version line) | - |
| 1 | `$8C28` | `$DE00` | 1 (status line) | - |
| 2 | `$8C78` | `$8CA0` | 3, 4 | 0 |
| k (2-12) | `$8BD8+$50k` | top+`$28` | 2k-1, 2k | k-2 |
| 12 | `$8F98` | `$8FC0` | 23, 24 | 10 |
| 13 | `$8FE8` | `$9010` | (25, 26: outside the screen) | 11 |

**Users:**
- `set_text_line_ptrs` `$1A67` sets `work_ptr_a` and `work_ptr_c` from these tables. With `text_single_height` it sends the bottom half to `$DE00`.
- `print_message` `$17E2` uses it: room tile strings drawn by the room handlers, the lantern redraw, and the status texts.
- `check_three_cells` `$2E6E` uses it for background touches. The actor's `actor_char_row` = (y-12)/16 from `actor_char_coords` `$1C39` is a text row.

---------------------------------------------------------------------------------------------

## 4. The per-frame display: raster IRQ chain

### 4.1 Entry and installation

- **Entry.** The IRQ vector `$FFFE` = `$1103`, because `$01` = `$35` and the KERNAL is banked out. `irq_handler` (`$1103`) pushes A, X and Y and jumps through `irq_chain_vector` (`$0408/$0409`). A dead BRK test is disabled by `AND #$00` at `$110C`.
- **Installation.** `init_game_irq` (`$082D`, from `init_game_screen`) does this:
  - disables the CIA interrupts;
  - sets `irq_chain_vector` = `irq_frame_top`;
  - writes 1 to `$D01A` (raster IRQ only) and acknowledges `$D019`;
  - clears bit 7 of `$D011` (raster bit 8);
  - sets `$D012` = `$FB`;
  - starts SID voice 3 noise.
- **VIC set-up** by `init_game_screen`:
  - `$DD00` = `$01` (`$07DB`: VIC bank 2, `$8000-$BFFF`);
  - `$D018` = `$38`;
  - `$D016` = `$18` (multicolour on, 40 columns);
  - `$D020-$D023` = `initial_vic_colours` (`$479B`: `$F0 $FB $F1 $FE`).
  - The border is black (`$F0`). Nothing in the room pipeline writes `$D020`.

### 4.2 The chain (one PAL frame)

Visible text area: screen row n covers raster lines `$33+8n` to `$3A+8n`. The playfield (screen rows 3-24) covers lines `$4B-$FA`.

**1. `irq_frame_top` `$48C1`**, raster line `$FD` (`$FB` on the first frame after `init_game_irq`). This is in the lower border, before the next frame's status rows.
```
$48C1  D018 = $32                     ; screen $8C00, charset $8800 (ROM font copy) for rows 0-1
$48C6  D021 = $FC                     ; status background: grey (12)
$48CB  irq_chain_vector = irq_playfield_top ($491E)
$48D5  D01A = 1; D019 = 1             ; raster IRQ enabled and acknowledged
$48DD  D011 &= $7F                    ; compare line bit 8 = 0
$48E5  D012 = $40
$48EA  $0A/$0B = room_split_colour_ptrs[room]; $0C/$0D = room_raster_line_ptrs[room]
$4902  for Y = 11..0:                 ; *irq_copy_room_colours* $4904
           raster_colours[$0153+Y] = ($0A)[Y]
           if Y < 4: current_raster_splits[$47F5+Y] = ($0C)[Y]
$4915  JSR game_frame_update ($15A8)  ; sound, split_index($44)=0, charset_hi, timers, joysticks, sprites ...
$4918  PLA/TAY/PLA/TAX/PLA/RTI
```
The status rows 0-1 use `$D018` = `$32` and `$D021` = `$FC`. Their colour RAM (`$D800-$D84F`) is 0 (hi-res black), written by `init_game_screen` (loop at `$079C`).

**2. `irq_playfield_top` `$491E`**, raster line `$40`.
```
*irq_wait_line_42* $4920: wait while RASTER <= $41
$4925  ~50-cycle delay loop (X = 10)  ; the switch lands late in line $42 = last line of screen row 1
$492A  D018 = room_charset_d018 ($F2) ; room charset from screen row 2 on
$492F  D021 = $0153; D022 = $0154; D023 = $0155   ; triplet 0
$4941  split_index($44) = 0; split_colour_offset($F4) = 3
$4949  irq_chain_vector = irq_colour_split ($4982)
irq_schedule_split $4953:
       D01A = 1; D019 = 1; D011 &= $7F
       D012 = current_raster_splits[split_index]
       if that line == $FD: irq_chain_vector = irq_frame_top     ; *irq_schedule_frame_top* $4975
irq_return $496F: PLA/TAY/PLA/TAX/PLA/RTI
```

**3. `irq_colour_split` `$4982`**, once per listed line L.
```
Y = raster_colours[$0153 + F4]                 ; new $D021, loaded before the wait
X = L+3, A = L+2
*irq_split_wait_line* $4991:
   if RASTER == L+3: goto set (no delay)
   if RASTER != L+2: loop
   ~50-cycle delay
*irq_split_set_colours* $49A0:
   D021 = Y; D022 = raster_colours[$0154+F4]; D023 = raster_colours[$0155+F4]
F4 += 3; split_index += 1
JMP irq_schedule_split                          ; next line, or $FD -> irq_frame_top
```

**Band boundaries per room.** The new `$D021` comes at about line L+2 (late) or L+3. `assets/rooms` measures the band from L+3.

| Rooms | Lines L | Triplets shown | Band starts (raster, playfield pixel row y = raster - `$4B`) |
|---|---|---|---|
| 0, 1, 2 | `$78`, `$97` | 0, 1, 2 | `$7B` (y 48 = start of map row 3), `$9A` (y 79 = last line of map row 4) |
| 3 | `$62`, `$97` | 0, 1, 2 | `$65` (y 26, inside map row 1), `$9A` |
| 10, 12, 14, 16 | `$56` | 0, 1 | `$59` (y 14, inside map row 0) |
| 15 | `$B6`, `$C7` | 0, 1, 2 | `$B9` (y 110), `$CA` (y 127) |
| others | - | 0 only | - |

**Observed:**
- Triplets beyond the list length are copied every frame and never shown. For example, rooms 4-6 copy 4 triplets from `$47D1` and show only `F6 FE F1`.
- Only rooms 0-3 and 15 show three bands; rooms 10, 12, 14 and 16 show two; all other rooms show one.

**Effect of the triplets.** `%00` pixels use `$D021`, `%01` pixels `$D022`, `%10` pixels `$D023`, and `%11` pixels the colour RAM (the room colour or `$F8` = black). Row 2 (`$8C50-$8C77`, char `$06`, colour RAM `$F8`) is drawn with the room charset and triplet 0.

### 4.3 Other per-frame changes to the room picture

None of these are part of `draw_room`:
- `flicker_lights` (`$40BC`, from `main_loop`) writes random pixels into the light chars of charsets 0 and 1.
- `animate_scrolling_chars` (`$2C70`) rewrites three chars of the active charset through `charset_hi`.
- The room frame handlers draw tile strings with `print_message` and change colour RAM. Examples: room 17's colour flip and room 19's random colours.
- The screen saver in `game_frame_update` (`$1645`) XORs `raster_colours` after `irq_frame_top` copied them.

---------------------------------------------------------------------------------------------

## 5. The room transition

### 5.1 From touch to exit

**1. `check_actors_background` `$2E39`.** It runs from `main_loop` on every pass (`$1C10`). For each actor X = 2, 1, 0 that is active and not dying (state `$19`):
- `actor_char_coords` gives `actor_char_col` = (x-12)/4 and `actor_char_row` = (y-12)/16, with y+4 in room 13.
- `check_three_cells` reads the three top-row chars at columns col..col+2 of text row `row`, then of `row+1`, through `set_text_line_ptrs`. Each char goes to `handle_touched_char` with bit 7 cleared.

**2. `handle_touched_char` `$2E89`.** Chars `$05`, `$02`, `$03` and `$04` jump to `take_exit_char05/02/03/04` (`$2E89-$2EA2`). The exit chars are tested first, for every actor.

**3. `take_exit_char02` `$2F3C`** (03 `$2F51`, 04 `$2F66` and 05 `$2F7B` are the same):
```
if check_exit_direction() == C=1: return
$4E = exitN_room[room]; Y = exitN_y[room]; A = exitN_x[room]
if A != 0: goto enter_room
else fall into take_exit_char(N+1)          ; N=5 enters with A = x even if 0
```

**4. `check_exit_direction` `$30D4`.** It returns C = 0 (exit allowed) when any of these holds:
- room 11;
- `actor_x < $10` and `actor_moved_left,X` (`$4F5D`) != 0;
- `actor_x > $A1` and `actor_moved_right,X` (`$4F60`) != 0;
- `actor_y > $C5` and `actor_state,X` == `$0E` (*not run*);
- `actor_y < $31` and `actor_move_counters,X` (`$4F57`) != 0 (*not run*).

Otherwise C = 1.

**Conclusion:** an exit tile only works when the actor moves out across the matching screen edge.

### 5.2 `enter_room` `$2F8E`

Inputs: A = entry x, Y = entry y, `$4E` = destination, `current_actor` = actor.

```
if current_actor != 0:                     ; an enemy walked out
    remove_actor(X)                        ; $2F92
    PLA; PLA                               ; drop the return into check_three_cells
    JMP next_actor_background              ; $2E68: continue with the next actor
enter_room_bruce:                          ; $2F9A
    actor_x[0] = A; actor_y[0] = Y
    current_room = $4E                     ; $2FA1
    for X = 2, 1:                          ; *enter_room_enemy_loop* $2FA5
        if actor_flags[X] & 1:             ; active enemy
            enemy_saved_energy[X-1] = actor_energy[X]   ; $8F/$90
            enemy_entry_x[X-1] = actor_x[0]             ; $8B/$8C: Bruce's NEW position
            enemy_entry_y[X-1] = actor_y[0]             ; $8D/$8E
        else:                              ; *enter_room_no_follow* $2FB9
            enemy_entry_x[X-1] = enemy_entry_y[X-1] = 0
        remove_actor(X)                    ; *enter_room_remove_enemy* $2FBF ($3001): flags, D015 bits, sprite data, timer
    SEI                                    ; $2FC5
    reset_enemy_timer(X=0)                 ; $0D42 -> reset_both_timers (overwritten by draw_room, see below)
    S = $FF                                ; $2FC9: discards the main-loop call chain
    draw_room()                            ; $2FCC
    draw_object_sprites()                  ; $2FCF
    CLI; JMP main_loop                     ; $2FD2/$2FD3
```

**What is saved:**
- `current_room`;
- Bruce's position;
- for each active enemy: its energy and the follow entry point.

**What is kept across the transition:** the score, falls, the lantern states (`lantern_list_*`, `room_lanterns_left`), `room_entry_bonus_flags`, `game_cycle` and Bruce's energy.

**What is reset:**
- the enemy actors are removed;
- `draw_room` resets the timers, movement history, Bruce's state, room script variables, charset and colour sets (section 2.2).

**Observed:** the timer reload in `enter_room` (`reset_enemy_timer` from the respawn delays) is always overwritten by `draw_room` `$0A4E` with the first-spawn delays.

**Other entries into `enter_room`:**
- `respawn_in_room` `$3217`: after a lost fall (`next_player_turn`, `$188B`), after the ending (`$4295`, *not run*) and the room 11 redirect. It uses `room_spawn_x/y[X]`.
- `action_blocked_step` `$24DB`: Bruce stuck with an empty move history re-enters the current room at its spawn point. This redraws the room.

### 5.3 How enemies follow

1. When Bruce leaves, each active enemy gets `enemy_entry_x/y` = Bruce's entry point and `enemy_saved_energy` = its energy (`$2FAD-$2FB5`).
2. `draw_room` clears `enemy_entry_x` when the new room has `room_no_combat_flags` != 0 (`$0A48`). `init_game_screen` (`$0763`) and `next_player_turn` (`$1834`) also clear it.
3. In `main_loop`, `tick_enemy_timers`/`try_spawn_yamo`/`try_spawn_ninja` (`$1BF5-$1BFB`) spawn an enemy when its timer is 0. The timer starts at `*_first_spawn_delay[room]`, or 3 / 8 in the cases of section 2.2.
4. `spawn_yamo`/`spawn_ninja` call `init_actor` (X = 1/2):
   - In demo mode, the enemy always goes to spawn point A.
   - If `enemy_entry_x[X-1]` != 0 (`$0BFA`), `actor_use_entry_pos` (`$0C3F`) sets `actor_x`/`actor_y`/`actor_energy` from `$8A+X`/`$8C+X`/`$8E+X` and clears `enemy_entry_x[X-1]`. The source writes these operands as `yamo_idle_timer+1,x`, `enemy_entry_x+1,x` and `enemy_entry_y+1,x`.
   - Otherwise the entry preference and `random_byte` choose spawn point A or B (`$0C04-$0C3C`, *`actor_random_spawn`* `$0C17`).
5. `spawn_yamo` then caps the energy at `$14`, and `spawn_ninja` at `$07`.

**Conclusion:** a following enemy appears at the point where Bruce entered, with its old energy (capped), after the destination room's first-spawn delay.

### 5.4 How the main loop restarts

- `enter_room` resets the stack to `$FF` and jumps to `main_loop` (`$1BC2`). The pass that detected the exit is abandoned, from `check_actors_background` on.
- `main_loop` sets `frame_countdown` = 3 and runs a full pass. The new room's frame handler has already run once inside `draw_room`.
- The raster chain resumes at the CLI.
- The first `irq_frame_top` after the draw copies the new room's triplets and raster list.
- Until then, the handler that was pending before the SEI runs with the triplet values that `draw_room` left in `$0153-$015E`: the Atari set.

**Conclusion:** at most one partial frame can show odd band colours. The display is already on at that time. This was not observed; see experiment E4.

**Enemy exit and the stack (observed in the code).** When an enemy takes an exit, `enter_room` drops only the return address into `check_three_cells`. The return address into `check_actors_background` stays on the stack, and the final RTS of `check_actors_background` uses it:
- If the exit was found in the first `check_three_cells` call (`$2E5E`), the RTS returns to `$2E61`. The code there checks Bruce's cells again one more row down, then returns to `main_loop`.
- If the exit was found in the second call (`$2E65`), the RTS returns to `$2E68`, which returns at once.

The enemy exit path ran (coverage `$2F92`). See experiment E3.

---------------------------------------------------------------------------------------------

## 6. Worked example: the start of room 0

`room_map_ptrs[0]` = `$68F9`. Stream bytes:

```
$68F9: 16 89 8D 8A A3 B5 B3 B5 B6 8A A3 B3 B5 A3 B5 B6 05 89 84 A3 B3 B4 B3 02 B4 86 B3 B4 B5 B6 A3 8C 02 B4 88 B5 B6 8A A3 B5 B6 8A 8E 03 00 …
```

Start state: `work_ptr_a` = `$8C78`, `work_ptr_c` = `$8CA0`, `colour_ptr_a` = `$D878`, `colour_ptr_b` = `$D8A0`, `draw_count` = `$27`. Colour RAM is already `$FE` (`room_char_colours[0]`) everywhere from `$D878`.

| Stream | Bytes | Meaning | Cells (map row, cols) | Screen (top / bottom) |
|---|---|---|---|---|
| `$68F9` | `16 89` | run of `$16` = 22 cells of `$89` | row 0, cols 0-21 | `$8C78-$8C8D` = `$09`; `$8CA0-$8CB5` = `$89`; colour `$D878-$D88D` and `$D8A0-$D8B5` = `$F8` (bit 7) |
| `$68FB` | `8D` + 13 bytes | literal of 13: `8A A3 B5 B3 B5 B6 8A A3 B3 B5 A3 B5 B6` | row 0, cols 22-34 | top `$8C8E-$8C9A` = `0A 23 35 33 35 36 0A 23 33 35 23 35 36`; bottom `$8CB6-$8CC2` = `8A A3 B5 B3 B5 B6 8A A3 B3 B5 A3 B5 B6`; all colour `$F8` |
| `$6909` | `05 89` | run of 5 x `$89` | row 0, cols 35-39 | top `$8C9B-$8C9F` = `$09`, bottom `$8CC3-$8CC7` = `$89` |
| (after cell 40) | - | `room_draw_next_cell`: `draw_count` -1 -> reload `$27`; pointers `$8CA0`/`$8CC8`/`$D8A0`/`$D8C8` + 40 | - | `work_ptr_a` = `$8CC8` (screen row 5), `work_ptr_c` = `$8CF0` (row 6), colour `$D8C8`/`$D8F0` |
| `$690B` | `84` + 4 | literal: `A3 B3 B4 B3` | row 1, cols 0-3 | top `$8CC8-$8CCB` = `23 33 34 33`, bottom `$8CF0-$8CF3` = `A3 B3 B4 B3` |
| `$6910` | `02 B4` | run of 2 x `$B4` | row 1, cols 4-5 | `34 34` / `B4 B4` |
| `$6912` | `86` + 6 | literal: `B3 B4 B5 B6 A3 8C` | row 1, cols 6-11 | `33 34 35 36 23 0C` / `B3 B4 B5 B6 A3 8C` |
| `$6919` | `02 B4` | run of 2 x `$B4` | row 1, cols 12-13 | `34 34` / `B4 B4` |
| `$691B` | `88` + 8 | literal: `B5 B6 8A A3 B5 B6 8A 8E` | row 1, cols 14-21 | `35 36 0A 23 35 36 0A 0E` / `B5 B6 8A A3 B5 B6 8A 8E` |
| `$6924` | `03 00` | run of 3 x `$00` | row 1, cols 22-24 | `00` / `80`, colour stays `$FE` (bit 7 clear) |

**Check against the snapshot (observed).** `runs/rooms/room00.vsf`, screen row 3 (`$8C78`):
```
09 09 09 09 09 09 09 09 09 09 09 09 09 09 09 09 09 09 09 09 09 09 0A 23 35 33 35 36 0A 23 33 35 23 35 36 09 09 09 09 09
```
Row 4 (`$8CA0`) holds the same values with bit 7 set. The colour RAM of rows 3 and 4 holds `$8` (low nibble of `$F8`) in every column.

**Pixels.**
- Tile `$09` (source `$9048` = `AA` x 8) is all `%10` pixels. It shows `$D023` of triplet 0 = `$FE` (light blue) in band 0.
- Tile `$23` (source `$9118` = `AA AA AA A5 95 51 01 05`) gives:
  - char `$23` = `AA AA AA AA AA AA A5 A5`;
  - char `$A3` = `95 95 51 51 01 01 05 05`: `%01` (`$D022`), `%00` (`$D021`) and `%11` (colour RAM `$F8` -> black).

---------------------------------------------------------------------------------------------

## 7. Screen memory layout

**VIC bank 2.** `$DD00` = `%xx01`, which selects `$8000-$BFFF`.

| VIC address | Content | Notes |
|---|---|---|
| `$8000-$83FF` | `$8180-$83FF` = 10 sprite blocks (blocks 6-15) | Built by `draw_object_sprites`. |
| `$8400-$87FF` | Title big font (chars `$80-$FF` of the charset at `$8000`) | Title only. |
| `$8800-$8BFF` | ROM font copy and its inverse | Status line, title texts. `$D018` = `$32`/`$33`. |
| `$8C00-$8FE7` | Screen (1000 bytes) | `$D018` high nibble 3. |
| `$8FE8-$8FF7` | Unused screen RAM | The 2 overrun cells of rooms 4, 7, 10, 13, 17 and 18 land at `$8FE8/$8FE9`. |
| `$8FF8-$8FFF` | Sprite pointers | |
| `$9000-$9FFF` | VIC sees the char ROM; the CPU sees the charset sources, then collision masks | Not usable by the VIC. |
| `$A000-$A7FF` | Room charset set 0 | `$D018` = `$38`, rooms 0-9 |
| `$A800-$AFFF` | Set 1 | `$3A`, rooms 10-17 and 19 |
| `$B000-$B7FF` | Set 2 | `$3C`, room 18 |
| `$B800-$BFFF` | Set 3 | `$3E`, room 18 defeat effect |

Each 2 KB set holds the top halves in chars 0-127 and the bottom halves in chars 128-255.

**Screen rows:**

| Screen rows | Address | Content | Charset | Colour RAM |
|---|---|---|---|---|
| 0 | `$8C00` | Version line (V key) or blank. `draw_room` clears it to `$20`. Room 19 prints CONGRATULATIONS here. | `$8800` (`$D018` = `$32`) | `$D800`: 0 (hi-res black) |
| 1 | `$8C28` | Status line: score, TOP, FALLS (text row 1, single height). | `$8800` | `$D828`: 0 |
| 2 | `$8C50` | Char `$06` x 40, written by `init_game_screen` `$07AB`. A border strip drawn with the room charset. | Room (`$F2`) | `$D850`: `$F8` |
| 3-24 | `$8C78-$8FE7` | Playfield: 11 map rows x 40 cells, each cell 2 chars high. Map row R = screen rows 3+2R (top char `t`) and 4+2R (bottom char `t|$80`) = text row R+2. | Room | `$D878-$DBE7`: room colour, or `$F8` for bit-7 cells |

**Colour RAM rules:**
- Colour RAM address = screen address + `$4C00`. `trigger_floor_trap` (`$306B`) uses exactly this: it adds `$4C` to the high byte.
- `draw_room` fills `$D878-$DBFF` with one value. The decoder then writes `$F8` for bit-7 cells. The init handlers and frame handlers patch single cells.
- A colour RAM value is always `$F8-$FF`: multicolour on for every playfield char.

**Double-height cells:** a cell is one 8x16 tile. The top char is tile `t` (rows 0-3 of the source, doubled) and the bottom char is `t+128` (rows 4-7, doubled). Both chars have the same colour RAM value. Everything that writes room cells writes both halves: the decoder, `print_message` and the lantern code.

**Coordinates:**
- Sprite X = 2 * `actor_x`. Sprite Y = `actor_y` + `$1D`.
- Cell column = (`actor_x` - 12) / 4. Text row = (`actor_y` - 12) / 16.

---------------------------------------------------------------------------------------------

## 8. Open questions and experiments

These need runtime proof. The emulator belongs to another agent, so they are not done here.

| # | Question | Experiment |
|---|---|---|
| E1 | `redraw_taken_lanterns` path `$3384-$33AB` never ran. | Take a lantern in room 0, leave, re-enter. Check that the lantern cell shows tile `$1F`/`$9F` (record byte 1 = `$9F`) and that colour RAM is unchanged. Watch `$3384`. |
| E2 | Do enemies that are active when Bruce loses a fall follow him into the respawned room? `next_player_turn` clears `$8B/$8C`, but `enter_room` then recomputes them for active enemies. | Lose a fall with Yamo active. Read `$8B/$8C`, `$8F/$90` after `$2FC5` and check where Yamo spawns. |
| E3 | Enemy exit leaves one return address on the stack (section 5.4). | Breakpoint at `$2F92`. Note S and which `check_three_cells` call was active, then step to the RTS at `$2E6D` and see whether it returns to `$2E61`. |
| E4 | The first frame after `enter_room`'s CLI may show the Atari bytes from `$0153` before `irq_frame_top` copies the triplets. | Break at `$2FD2`, read `$0408` and `$D012`, step one frame and watch `$D021` writes. |
| E5 | The meaning of the 20 unreferenced bytes `$4CBA-$4CCD`. | No code reads them. It may be an Atari leftover. Compare with the Atari version if one is available. |
| E6 | Exit conditions with state `$0E` (y > `$C5`) and moving up (y < `$31`) never ran. | Find a room with an exit tile at the bottom or top edge (for example room 4 exit 3, y = `$32`) and record `$30F7`/`$3103`. |
| E7 | The game meaning of `game_cycle` != 0 (timers 3 at `$0A5C`) was not seen. | Finish room 19 once (`$4278`). |

**Not open, settled here:**
- **Room 11 special path:** it is a redirect to room 13 (section 2.2), not a separate map.
- **`room_params`:** it is the Atari colour set copy (section 1.3).
- **Map pointer entry 20** and **lantern list entry 20** are never read.
