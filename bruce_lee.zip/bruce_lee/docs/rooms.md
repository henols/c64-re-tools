# Bruce Lee: rooms

This document explains how the 20 rooms of *Bruce Lee* (Datasoft 1984, REV.2) are stored, built and run. It is the entry point. The details are in four parts:

| Part | Content |
|---|---|
| [parts/room_pipeline.md](parts/room_pipeline.md) | **Room data and how a room is generated.** It has every per-room table (address, layout, readers), `draw_room` step by step with pseudo-code, the RLE map decoder, charset expansion, the raster IRQ colour bands, the room transition, and a hand-decoded example. |
| [parts/room_flow.md](parts/room_flow.md) | **The room-level state machine of the game.** It covers game start, the main loop pass, exits and `enter_room`, lanterns, death and respawn, the two-player swap, floor traps, enemy spawning, score and extra falls, the end of the game, the exit graph, and a table of every per-room variable. |
| [parts/rooms_00_09.md](parts/rooms_00_09.md) | **Rooms 0-9, one by one:** layout, exits, init handler, frame handler as a state diagram and transition table, and the shared mechanisms (cycling objects, hazards, slider, floor traps, climbing texture, light flicker, passage helpers). It also has the cross-room dependency table. |
| [parts/rooms_10_19.md](parts/rooms_10_19.md) | **Rooms 10-19, one by one:** the room 11 diversion, the room 13 sliders, the room 16 bonus fall, the room 18 wizard (face, fireballs, defeat), the room 19 ending, and what `game_cycle` changes. |

Names and addresses are those of the project knowledge (`.c64-re-tools/knowledge/`) and of the generated source in `src/`. Each claim is marked with its evidence:
- **run**: seen in an emulator run (the files are listed below);
- **code**: read from the code only.

## 1. The three layers of a room

```mermaid
flowchart TB
  subgraph DATA["Per-room data (indexed by current_room $29)"]
    M["room map RLE stream<br/>room_map_ptrs $4B34/$4B49 → $68F9-$817F"]
    C["charset set<br/>(room <10: set 0, 18: set 2, else set 1)"]
    K["colours: room_char_colours $47A0,<br/>band colours $480B, raster lines $4833"]
    X["exits: exit2..5_room/x/y $4B5E-$4C8A"]
    L["lanterns: counts $4CCE, lists $4CE2"]
    E["enemy delays/preferences $130B-$1382"]
    H["handlers: room_setup_handlers $4E9C,<br/>room_frame_handlers $4EC4"]
  end
  subgraph BUILD["Room generation (once per entry)"]
    D["draw_room $09BC:<br/>blank, colour RAM, entry bonus,<br/>enemy timers, charset, RLE decode"]
    R["redraw_taken_lanterns $336E"]
    I["room init handler (RTS dispatch)"]
  end
  subgraph RUN["Every main-loop pass (3 frames)"]
    U["run_room_update $3A6F → room frame handler"]
    S["shared mechanisms: sliders, hazards,<br/>floor traps, texture, light flicker"]
    T["check_actors_background $2E39:<br/>exits, lanterns, deadly tiles, traps"]
  end
  subgraph IRQ["Every frame (raster IRQ)"]
    Q["irq_frame_top $48C1 → irq_playfield_top $491E → irq_colour_split $4982:<br/>status line, room charset, colour bands"]
  end
  DATA --> BUILD --> RUN
  RUN -- "exit tile touched / death" --> BUILD
  DATA --> IRQ
```

**How the layers work** (run and code):
1. **The map draws the static picture.** It is a 40×11 grid of double-height tiles (8×16 pixels, multicolour), RLE-coded.
2. **Everything that changes is drawn by code on top of the map.** This covers opened passages, exit tiles, hazards, sliders and the wizard face, done by the room's two handlers and the shared mechanisms. They print "messages": tile strings drawn by the same routine `print_message` `$17E2` that prints text.
3. **Exits are tiles 2-5 in the grid.** Touching one looks up that room's row in the exit tables. Many exits do not exist in the map; a handler draws their tile when a condition becomes true.
4. **Room state does not persist between visits.** `room_script_vars` `$4E97-$4E9B` is cleared and the map is redrawn on every entry. Only the lantern counters and records persist, per player. So every event fires again on re-entry while its lantern condition holds (run).

## 2. Progression: what a player must do

The events form a dependency chain from room 0 to room 19 (details in the two room parts):

```mermaid
flowchart LR
  A["clear rooms 0, 1, 2<br/>(room 6 still full)"] -->|"room 1 floor hatch"| R5["room 5"]
  R5 --> R6["clear room 6"]
  R6 -->|"room 2 right exit opens<br/>(needs room 6 empty)"| R3["room 3: clear it"]
  R3 -->|"floor hatch"| R10["room 10"] --> R11["room 11"]
  R11 --> B["clear rooms 12, 14, 16"]
  B -->|"enter room 11 again:<br/>diverted to room 13"| R13["room 13"] --> R15["clear room 15"]
  R15 -->|"exit to 17 drawn"| R17["room 17"] --> R18["room 18: take the<br/>wizard's lantern"]
  R18 -->|"defeat, exit drawn"| R19["room 19"] -->|"game_cycle + 1"| R0["room 0, harder"]
```

- Rooms 4, 7, 8 and 9 hold bonus lanterns and side routes. They lie off this chain.
- **Room 6 is the key room of the first half.** Rooms 0, 1, 2 and 5 test its counter. The room 1 hatch opens only while room 6 still has lanterns.
- **Room 13 has no normal entrance.** `draw_room` diverts an entry to room 11 into room 13 once rooms 12, 14 and 16 are empty (`ldx #$0D` / `jmp respawn_in_room` at `$0A04`; seen in a run).
- **Reordering rooms** means changing:
  - the exit tables;
  - the hard-coded `room_lanterns_left+N` and lantern record addresses in the handlers;
  - the room-number tests in `draw_room` (charset, room 11), `animate_scrolling_chars` and `handle_touched_char`.

  See [rooms_00_09.md](parts/rooms_00_09.md) section 5.

## 3. Findings beyond the earlier report

| Finding | Evidence |
|---|---|
| **PAL freeze bug in the original game.** `draw_room` changes `$D011` with read-modify-writes at `$09BC` and `$0B33`. Reading `$D011` gives bit 8 of the current raster line in bit 7, so a redraw that runs on lines 256-311 sets bit 8 of the raster compare. The pending game IRQ line `$40` becomes `$140` (320), which a PAL frame (312 lines) never reaches. `main_loop` then waits forever on `frame_countdown`. On NTSC the window is only lines 256-262. | run: `runs/r17_freeze`. In room 17 the redraw read `$9B` on line 279 and the closing RMW ran on line 287, then no IRQ came. |
| Entering room 11 with rooms 12, 14 and 16 empty diverts to room 13. It is the only entrance to room 13. | run: `runs/room_special` (`r11_special`), `current_room` = 13 |
| Wizard defeat: taking the lantern at `$4E86` gives +3000, closes the exit to room 17, flashes with charset set 3 (`$D018`=`$3E`) for 80 passes, then draws exit tile `$03` to room 19. | run: `runs/room_special` (`w_*`) |
| Room 19: after `$0458` frames, `game_cycle` +1, the lanterns and flags are reset, and the game restarts in room 0. Any non-zero `game_cycle` makes the enemies spawn faster. | run (`e_*`); the `game_cycle` effects are code |
| Events in rooms 12, 14 and 15 fire twice per visit. The init presets the one-shot flags to 1, and the handlers test them with `bmi`. | run (room 15: `01`→`FF`) |
| `room_params` is not a C64 table. It is the Atari version's colour set (`$4AA8`), copied to `$0153` and then overwritten every frame by the IRQ. | code |
| The room 7 slider overruns its strip by one cell when moving left and overwrites map tile `$2A` with `$65`. | run: `runs/room_events2` |

## 4. Evidence and how to reproduce it

All runs are `run.ts` files in `.c64-re-tools/local/`, run with `node ../.claude/skills/c64-testing/scripts/run.ts <file> --out runs/<name>`. Their coverage maps are copied into `coverage/`.

| Run | What it does |
|---|---|
| `room_events.json` → `runs/room_events` | In each room snapshot: zero all lantern counters, run 400 frames, record screen cells. |
| `room_events2.json` → `runs/room_events2` | Enter each room through `enter_room` twice, normally and with every lantern record and counter at 0. Also logs the room 4 texture every 100 frames. |
| `room_events3.json` → `runs/room_events3` | The room 1 hatch (rooms 0-2 empty, room 6 full), room 8 with lanterns 0 and 1 taken, and a 3000-frame texture log in room 9. |
| `room_special.json` → `runs/room_special` | Wizard defeat, the room 11 diversion, the room 19 ending. |
| `r17_freeze.json` → `runs/r17_freeze` | The room 17 freeze, frame by frame. |

The summaries of the cell differences are `.c64-re-tools/local/room_events_diffs.json`, `room_events2_diffs.json` and `room_special_diffs.json`.

## 5. Still open

- **Confirmed since the first draft:** the room 1 hatch, room 8's texture-down branch, and the climbing texture's full cycle (ramp, pause, wrap, direction flip) are confirmed by `runs/room_events3`.
- **Not yet run:**
  - the room 16 bonus fall;
  - floor-trap slot 2;
  - the exit checks at the top and bottom screen edges (`$30F7`, `$3103`);
  - room 17's later events, because the PAL freeze stopped those runs;
  - a fireball hitting Bruce in room 18.
- **Experiments still requested:** the remaining ones are listed at the end of each part.
- **The full list of code that no run executed** is `src/not_executed.json` (601 instructions); [report.md](../report.md) section 4 lists it with reasons.
