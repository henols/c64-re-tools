| init.asm | $0412-$0414 (cold_start) |
| title.asm | $06b2-$06b4, $06ba-$06bc, $06f3-$06f9 (title_screen) |
| room_draw.asm | $0b47-$0b48 (inc_work_ptr_a) |
| actors.asm | $0d3a-$0d3b (try_spawn_yamo); $0d6f-$0d71, $0d96-$0d98 (reset_yamo_timer); $0df5-$0df6 (try_spawn_ninja) |
| title_options.asm | $0e7d-$0e91 (toggle_players_highlight) |
| room_state.asm | $102b-$104a (save_raster_colours) |
| interrupts.asm | $1110-$1112 (irq_handler); $1116 (nmi_reset_handler); $111d-$1130 (clear_sprite_blocks_6_7_11_12) |
| keyboard.asm | $13ae-$1487 (keyboard_scan) |
| frame_update.asm | $15f7-$15f8, $160f-$1610, $1634-$163e, $1643-$1644, $164d-$1652, $165b-$1669, $16b3-$16bc, $16ea-$16f3, $1709-$1716, $177f-$1780, $178f-$1790 (game_frame_update) |
| text.asm | $180e-$1816 (print_message) |
| game_over.asm | $1971-$1978 (game_over) |
| status.asm | $19d1-$19ea (check_demo_exit); $1a35-$1a37 (toggle_pause); $1a52-$1a55 (clear_text_lines_from_2); $1ad1-$1aec (debug_print_values); $1afc-$1b01 (print_falls_count); $1b64 (handle_game_keys); $1b8e-$1b90, $1b9d-$1b9f (print_hex_byte) |
| actor_movement.asm | $1d63-$1d65, $1dad-$1db2 (actor_undo_moves); $1e17-$1e38 (actor_move_up); $1e49-$1e58 (actor_move_down); $1e80-$1e82 (actor_left_or_fire_move); $1ec1-$1ec3 (actor_right_or_fire_move); $1efa-$1f09, $1f33-$1f36, $1f64-$1f75 (actor_move_right); $1fd3-$1fe4, $1fea-$1ffe (play_sound_80_checked) |
| object_actions.asm | $207c-$207f, $2082-$208c, $217d-$217f, $2194-$21a8, $21c5-$21cd, $21df-$21e4, $21f8-$2200, $221a-$2227, $2278-$2282 (continue_object_action); $22b2-$22b7, $22c7-$22c9, $2399-$239b (start_attack_recovery) |
| sound_effects.asm | $255d (play_sound_effect) |
| object_pose.asm | $279c-$27a0, $27e4-$27f1, $28ef-$28f1 (select_object_pose) |
| combat_hits.asm | $2ace-$2acf, $2af4-$2af5, $2b37-$2b38 (check_sprite_collisions); $2b79-$2b7e, $2b90-$2b95, $2bbb-$2bc3, $2bdf-$2be7, $2c03-$2c0b, $2c2a-$2c46 (mark_hit_landed) |
| actor_checks.asm | $2dd3-$2ddc (ai_wake_idle_enemies) |
| background_touch.asm | $2ef1-$2ef3, $2f00 (handle_touched_char); $2fd6-$3000 (room16_bonus_fall); $3051 (touch_deadly_char); $30b0-$30c7 (trigger_floor_trap); $30f7-$30fc, $3103-$3107 (check_exit_direction) |
| score.asm | $3146-$3159 (add_score_and_check_bonus); $3191-$31a3 (update_high_score) |
| lanterns.asm | $333e-$333f, $335a-$335b (collect_lantern_at) |
| room_init.asm | $3553-$3554 (room13_init); $35c0-$35c2 (room16_init) |
| room_update.asm | $3caf-$3cbc (room10_update); $3cca-$3cd5 (room11_update); $3d28-$3d37 (room18_wizard_update); $3e87-$3ebb (room13_update); $3fa2-$3fa5, $3ff6-$4005, $4012-$4015, $4022-$402e, $4039-$4048 (room17_update) |
| fireballs.asm | $41b8-$41bc, $41cf-$41d3 (update_fireballs) |
| collision.asm | $535a-$535d (setup_char_row_test) |
| music_player.asm | $e368-$e36a (music_set_voice_ptrs); $e3fb-$e3fd (music_read_byte); $e43b-$e440, $e445-$e454, $e466-$e46f (music_end_of_tune); $e486-$e488 (music_start_song_list); $e4bb-$e4bd, $e4e9-$e4eb, $e523-$e525 (music_update); $e5f7-$e5f9 (music_read_command); $e677-$e680, $e69d-$e6b4 (music_cmd_misc); $e6e9-$e6f8 (music_calc_note_ticks); $e779-$e7b1 (music_cmd_filter) |
| sfx_voice1.asm | $eb49-$eb4b, $eb4f-$eb51 (sfx_v1_update); $ebdd-$ebe4 (sfx_v1_op_ctrl) |
| sfx_voice2.asm | $efb9-$efbb, $efbf-$efc1 (sfx_v2_update); $f04d-$f054 (sfx_v2_op_ctrl) |
| sfx_voice3.asm | $f0b9-$f0bb, $f0bf-$f0c1 (sfx_v3_update); $f14d-$f154 (sfx_v3_op_ctrl) |