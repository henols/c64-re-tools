import json, re, subprocess, collections
L = '/workspaces/c64_games/bruce_lee/.c64-re-tools/local/'
B = {k: json.load(open(L + f'batch_{k}.json')) for k in 'abcdefg'}
RANGES = {'a': (0x0200, 0x0FFF), 'b': (0x1000, 0x1FFF), 'c': (0x2000, 0x2CFF), 'd': (0x2D00, 0x3AFF),
          'e': (0x3B00, 0x47FF), 'f': (0x4800, 0xCEFF), 'g': (0xCF00, 0xFFFF)}
def A(s): return int(s[1:], 16)
def owner(a):
    for k, (s, e) in RANGES.items():
        if s <= a <= e: return k
    return None
# manual names for shared pages and overrides
MANUAL = {
 0x28:'falls_left',0x2a:'room_lanterns_left',0x48:'frame_countdown',0x49:'attract_countdown',
 0x51:'current_actor',0x52:'temp_y',0x62:'delta_y_to_bruce',0x63:'delta_x_to_bruce',0x7b:'frame_parity',
 0x7c:'charset_hi',0x95:'actor_flags',0x98:'actor_joy_dir',0x9b:'actor_joy_fire',0x9e:'actor_x',0xa1:'actor_y',
 0xa4:'actor_facing',0xb6:'actor_contact',0xbf:'actor_state',0xc2:'actor_prev_state',0xce:'actor_state_timer',
 0xd1:'actor_energy',0xe6:'actor_char_col',0xe9:'actor_char_row',0xf2:'room_charset_d018',0xf3:'draw_count',
 0x104:'game_playing',0x106:'actor_step_delay',0x10f:'sliders_dir',0x119:'sliders_col',0x123:'sliders_row',
 0x12d:'sliders_prev_col',0x137:'sliders_min_col',0x141:'sliders_max_col',0x153:'raster_colours',
 0x408:'irq_chain_vector',0x2007:'protection_key2',0x4e95:'bonus_falls_left',0x4eec:'hit_budget_countdown',
 0x4f5a:'actor_moved_down',0x4f5d:'actor_moved_left',0x4f60:'actor_moved_right',0x4f63:'actor_move_history',
}
MODULE_FIX = {0x1007: 0x102B}
FILE_FIX = {(0x14a4,'raster_irq.asm'):'raster_irq_screens.asm',(0x48c1,'raster_irq.asm'):'raster_irq_game.asm',
            (0x1166,'game_tables.asm'):'actor_room_tables.asm',(0x49bd,'game_tables.asm'):'room_tables.asm'}
# name per (batch,name) -> address
bname = {}
for k, ops in B.items():
    for o in ops:
        if o['op'] == 'rename': bname[(k, o['name'])] = A(o['address'])
# candidate names per address
cands = collections.defaultdict(list)
for k, ops in B.items():
    for o in ops:
        if o['op'] == 'rename': cands[A(o['address'])].append((k, o))
final = {}; kinds = {}
for a, lst in cands.items():
    if a in MANUAL: name = MANUAL[a]
    else:
        own = [o for k, o in lst if k == owner(a)]
        name = (own or [lst[0][1]])[-1]['name']
        if name.startswith('obj_'): name = 'actor_' + name[4:]
    final[a] = name
    kinds[a] = next((o.get('kind') for k, o in lst if o.get('kind')), None)
# name uniqueness
cnt = collections.Counter(final.values())
dups = {n for n, c in cnt.items() if c > 1}
assert not dups, [(hex(a), n) for a, n in final.items() if n in dups]
def resolve(k, sym):
    a = bname.get((k, sym))
    return final[a] if a is not None else sym
out_rename = [dict(op='rename', address='$%04x' % a, name=n, **({'kind': kinds[a]} if kinds[a] else {})) for a, n in sorted(final.items())]
# removes
removes = {}
for k, ops in B.items():
    for o in ops:
        if o['op'] == 'remove-symbol' and A(o['address']) not in final: removes[A(o['address'])] = o
# comments: owner first preference
com = {}
for k, ops in B.items():
    for o in ops:
        if o['op'] == 'comment':
            key = (A(o['address']), o['placement'])
            prev = com.get(key)
            if prev is None or (k == owner(key[0])) or prev[0] != owner(key[0]):
                if prev is None or k == owner(key[0]) or prev[0] != owner(key[0]):
                    com[key] = (k, o)
out_comment = [o for _, (k, o) in sorted(com.items())]
# classify: foreign first, owner after, preserve order
cl_foreign, cl_own = [], []
for k, ops in B.items():
    for o in ops:
        if o['op'] in ('classify', 'unclassify'):
            (cl_own if owner(A(o['start'])) == k else cl_foreign).append(o)
# modules
mods = {}
for k, ops in B.items():
    for o in ops:
        if o['op'] == 'module':
            s = A(o['start']); s = MODULE_FIX.get(s, s)
            f = FILE_FIX.get((A(o['start']), o['file']), o['file'])
            mods[s] = dict(op='module', start='$%04x' % s, file=f, title=o.get('title', ''))
fc = collections.Counter(m['file'] for m in mods.values()); assert all(v == 1 for v in fc.values()), fc
# operands: translate symbols, one per address (owner preferred)
opd = {}
for k, ops in B.items():
    for o in ops:
        if o['op'] == 'operand':
            o = dict(o)
            if 'symbol' in o: o['symbol'] = resolve(k, o['symbol'])
            if 'expression' in o:
                o['expression'] = re.sub(r'[A-Za-z_][A-Za-z0-9_]*', lambda m: resolve(k, m.group(0)), o['expression'])
            a = A(o['address'])
            if a not in opd or owner(a) == k: opd[a] = o
refs = []
seen = set()
for k, ops in B.items():
    for o in ops:
        if o['op'] in ('reference', 'unreference'):
            key = (o['op'], o['from'].lower(), o['to'].lower(), o['kind'])
            if key not in seen: seen.add(key); refs.append(o)
merged = list(removes.values()) + cl_foreign + cl_own + out_rename + out_comment + list(mods.values()) + refs
json.dump(merged, open(L + 'merged_names.json', 'w'), indent=0)
json.dump(list(opd.values()), open(L + 'merged_operands.json', 'w'), indent=0)
print(len(merged), 'ops +', len(opd), 'operands;', len(final), 'names,', len(mods), 'modules,', len(removes), 'removes')
