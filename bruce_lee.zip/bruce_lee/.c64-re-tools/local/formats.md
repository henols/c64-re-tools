# Bruce Lee (C64) — asset formats

All addresses are in `unpacked/image.bin` (64 KiB RAM image at the game entry `$0400`).
Every format below was checked against the RAM of the VICE snapshots `runs/rooms/roomNN.vsf`
(module `C64MEM`: RAM starts 26 bytes after the module name) and against the screenshots.
Little-endian words unless stated.

Colour palette indices are standard C64 colour numbers 0-15.

---------------------------------------------------------------------------------------------

## 1. Room charsets (tiles)

### 1.1 Source: `$9000-$9FFF` (4 sets x 128 chars x 8 bytes)

| Set | Source        | Expanded by `$4892` to      | `$D018` | Used by                       |
|-----|---------------|-----------------------------|---------|-------------------------------|
| 0   | `$9000-$93FF` | `$A000-$A3FF` + `$A400-$A7FF` | `$38` | rooms 0-9                     |
| 1   | `$9400-$97FF` | `$A800-$ABFF` + `$AC00-$AFFF` | `$3A` | rooms 10-17 and 19            |
| 2   | `$9800-$9BFF` | `$B000-$B3FF` + `$B400-$B7FF` | `$3C` | room 18                       |
| 3   | `$9C00-$9FFF` | `$B800-$BBFF` + `$BC00-$BFFF` | `$3E` | room 18 flash effect (`$3DF8`, not reached in the recorded runs) |

The room's `$D018` value is kept in zp `$F2` (chosen at `$0A9B`: room < 10 -> `$38`, room 18 -> `$3C`, else `$3A`).

Source char `c` (0-127) of set `s` = 8 bytes at `src_s + 8*c`. Each byte is one row of 4
**multicolour** pixels (bits 7-6 = left pixel ... bits 1-0 = right pixel), every pixel 2 screen pixels wide.

### 1.2 Expansion (`$4892`, called 4 times at init `$047A-$04ED` with `$F3=$7F`)
For each of the 128 chars: rows 0-3 of the source, **each row written twice**, become the 8 bytes of
char `c` in the first 1 KB (`$A000+8c`); rows 4-7, each written twice, become char `c+128` (`$A400+8c`).
So a 2 KB VIC charset holds the top halves in chars 0-127 and the bottom halves in chars 128-255.

Decoder: a **tile** is 4 MC pixels x 16 pixel rows (8x16 screen pixels):
`tile_row(r) = src[8c + r//2]` for r = 0..15.

Verified: expansion of the image source equals `$A000-$BFFF` in the snapshots, except 8 byte pairs
the lamp-flicker code `$40D0-$412F` changes at run time (`$A432`, `$A49A`, `$A4A2`, `$A58A`, `$AC9A`, `$ACA2`, `$AD8A`, `$A73A`).

Note: after expansion `$512F` overwrites `$9000-$9FBF` with collision masks (section 4). Extract the
charset source from the image, not from a snapshot. (The warm restart path `$04D1` re-expands only set 3
from `$9C00`, which by then holds masks.)

### 1.3 Pixel colours in the playfield
- `%00` = `$D021`, `%01` = `$D022`, `%10` = `$D023`: from the room's split-colour table (section 2.3).
- `%11` = colour RAM low 3 bits: the room colour `$47A0+room` (`$Fx`, multicolour bit set), or colour 0 for cells
  whose map byte has bit 7 set (colour RAM `$F8`).

---------------------------------------------------------------------------------------------

## 2. Rooms

20 rooms (0-19), current room in zp `$29`.

### 2.1 Map pointer table `$4B34` (lo, 21 bytes) / `$4B49` (hi, 21 bytes)
`map = $4B34[r] | $4B49[r]<<8`. Entry 20 duplicates entry 19 (`$7FE0`).

| room | map stream        | room | map stream        |
|------|-------------------|------|-------------------|
| 0  | `$68F9-$6A08` | 10 | `$75D8-$774B` |
| 1  | `$6A09-$6B3D` | 11 | `$774C-$7842` |
| 2  | `$6B3E-$6C9C` | 12 | `$7843-$79C5` |
| 3  | `$6C9D-$6E1A` | 13 | `$79C6-$7A45` |
| 4  | `$6E1B-$6F81` | 14 | `$7A46-$7BB3` |
| 5  | `$6F82-$70DC` | 15 | `$7BB4-$7C5B` |
| 6  | `$70DD-$7226` | 16 | `$7C5C-$7D8C` |
| 7  | `$7227-$7310` | 17 | `$7D8D-$7E8F` |
| 8  | `$7311-$7490` | 18 | `$7E90-$7FDF` |
| 9  | `$7491-$75D7` | 19 | `$7FE0-$817F` |

The streams are contiguous; `$68F9-$817F` holds nothing else.

### 2.2 Map stream (decoded by `$0AD5-$0B2D`)
Byte-oriented RLE, read sequentially:

| byte `b`          | meaning |
|-------------------|---------|
| `$80`             | end of map |
| `$81-$FF`         | literal run: the next `b & $7F` bytes are cells |
| `$01-$7F`         | repeat run: the next byte is one cell, repeated `b` times |

(`$00` would repeat 256 times; it does not occur.)

Cells fill a 40-column grid row by row starting at screen row 3 (`$8C78`). Each **cell** is one tile of
8x16 pixels: screen row `3+2*R`, column `C` gets char `v & $7F`, screen row `4+2*R` gets `(v & $7F) | $80`.
Bit 7 of `v` sets colour RAM of both chars to `$F8` (colour-3 pixels black, multicolour); otherwise colour RAM
keeps the room colour `$47A0+room` filled from `$D878` by `$09DC`.
11 cell rows x 40 = 440 cells (screen rows 3-24). Rooms 4, 7, 10, 13, 17, 18 encode 442 cells: the last two
cells land at `$8FE8/$8FE9` and `$9010/$9011` (the latter inside collision mask 0, a bug of the original).

Row advance helper `$485B` decrements the column counter `$F3`; after 40 cells it adds 40 to all four
destination pointers (`$04` screen top, `$08` screen bottom, `$10`/`$12` colour RAM) to skip the second row.

Cell codes with game meaning (from `$2E89`, `$30D4`): `& $7F` = 2, 3, 4, 5 are exit triggers (section 2.5);
`$62`, `$2D`, `$2E`, `$13`, `$14`, `$31`, `$64`, `$66`, `$0F`, `$40`, `$54-$5A`, `$57`, `$71-$7C`, `$60` are tested by the
actor/background logic at `$2EA5-$2EE7` (outside this area).

### 2.3 Background colour splits
- `$480B` (20 words): per room pointer to 12 bytes = 4 triplets (`$D021`, `$D022`, `$D023`), low nibble = colour.
  Copied every frame by `$48C1` to `$0153-$015E`.
- `$4833` (20 words): per room pointer to a raster-line list terminated by `$FD`, up to 3 lines
  (lists at `$47F9-$480A`). Copied every frame to `$47F5-$47F8`.
- IRQ chain: `$48C1` (raster `$FD`: status line, `$D018=$32`, `$D021=$FC`) -> `$491E` (raster `$40`,
  sets `$D018=$F2` and triplet 0 at raster ~`$42`) -> `$4982` once per list entry L (triplet k+1 from raster
  L+2/L+3) -> `$48C1` again.
- Decoder: playfield pixel row y (0-199) uses triplet `k` = number of list entries L with `y+51 >= L+3`.

Per room (pointer -> colours / raster list):

| rooms | colours | raster lines |
|---|---|---|
| 0-3 | `$47C8`: FB F1 FE / FB F2 F1 / FC F2 F1 / F6 FE F1 | 0-2: `$78,$97`; 3: `$62,$97` |
| 4-6 | `$47D1` | none |
| 7-9 | `$47D4` | none |
| 10,12,14,16 | `$47D7` | `$56` |
| 11 | `$47DD` | none |
| 13 | `$47E0` | none |
| 15 | `$47E3` | `$B6,$C7` |
| 17 | `$47EC` | none |
| 18 | `$47EF` | none |
| 19 | `$47F2` | none |

Room colour (colour RAM) `$47A0` (20 bytes, low 3 bits): FE FE FE FE FC FC FC FF FA FA F9 FB F9 FA F9 FC F9 FF FE FF.

`$4AA8` (20 words) -> `$4AD0-$4B33` (records of 5 bytes, 4 per room) is a second per-room colour set copied to
`$0153-$0166` at `$0A87`; the C64 IRQ overwrites `$0153-$015E` every frame and nothing reads the rest. Its values
($0E, $34, $88, $96 ...) look like Atari 8-bit colour registers: a leftover of the Atari version.

### 2.4 Renderer recipe
```
cells = decode(map_ptr(room))[:440]
for i, v in enumerate(cells):
    R, C = divmod(i, 40); c = v & 0x7F
    col3 = 0 if v & 0x80 else IMG[0x47A0+room] & 7
    for r in range(16):                      # tile rows
        y = 24 + 16*R + r
        byte = IMG[charset_src(room) + 8*c + r//2]
        bg, m1, m2 = triplet(room, y)        # 2.3
        for p in range(4):
            px = (byte >> (6-2*p)) & 3       # -> [bg, m1, m2, col3][px], 2 pixels wide at x = 8*C + 2*p
```
Screen rows 0-2 are the status line and two rows filled outside the map.

### 2.5 Exits and start positions (20-byte tables indexed by room)
Touching a cell whose code is 2/3/4/5 (`$2E89`) uses the exit group of that code. If the group's X is 0 the
next group is tried. The actor is placed at (X, Y) = (`$9E,x`, `$A1,x`) in the destination room.

| code | dest room | X      | Y      |
|------|-----------|--------|--------|
| 2    | `$4B5E`   | `$4BFE`| `$4C12`|
| 3    | `$4B72`   | `$4C26`| `$4C3A`|
| 4    | `$4B86`   | `$4C4E`| `$4C62`|
| 5    | `$4B9A`   | `$4C76`| `$4C8A`|

- `$4BAE`/`$4BC2`: room spawn X/Y (game start `$0BE7`, respawn `$24E3`, `$321E`).
- `$4BD6`/`$4BEA`: alternative enemy spawn X/Y (`$0C1E`, chosen at random).
- `$4C9E`: per room flag; non-zero skips the sprite-sprite collision `$29C3` (`$1C1E`) and clears `$8B/$8C` at setup.
- `$4CCE`: lanterns per room (copied to `$2A-$3D` at `$10C5`).
Coordinates: X in multicolour pixels (sprite X register = 2*X), Y in raster lines minus `$1D`.

### 2.6 Lantern lists
`$4CE2` (21 words, entry 20 unused) -> list per room at `$4D0C-$4E94`. Records of 4 bytes, list ends with a
byte with bit 7 set (`$FF`):

| offset | meaning |
|--------|---------|
| 0 | state: non-zero = lantern present, 0 = collected (swapped with the per-player copy at `$0340` by `$0FED`) |
| 1 | cell drawn when collected (`& $7F`; top char, bottom char `|$80`), e.g. `$9E`/`$9F` |
| 2 | column 0-39 |
| 3 | char row (map row R = row value; drawn through `$1A67`) |

`$331C` finds the record by column/row and clears it; `$336E` redraws collected ones after the room is drawn.

### 2.7 Room handlers
`$4E9C` (20 words, RTS addresses = target-1): room setup handler, run by `$33BD`.
`$4EC4` (20 words, RTS addresses): per-frame room handler, run by `$3A6F`.

| room | setup | frame | room | setup | frame |
|---|---|---|---|---|---|
| 0 | `$33F5` | `$3642` | 10 | `$33F5` | `$3C90` |
| 1 | `$33F6` | `$3679` | 11 | `$33F5` | `$3CC0` |
| 2 | `$33F5` | `$36A6` | 12 | `$34BD` | `$3E4C` |
| 3 | `$33FC` | `$3702` | 13 | `$34C3` | `$3E7C` |
| 4 | `$3402` | `$3760` | 14 | `$358D` | `$3ECC` |
| 5 | `$3428` | `$38AB` | 15 | `$3593` | `$3EE6` |
| 6 | `$33F5` | `$39AA` | 16 | `$359F` | `$3F5B` |
| 7 | `$3461` | `$39C3` | 17 | `$35C4` | `$3F71` |
| 8 | `$3478` | `$3AD4` | 18 | `$35FA` | `$3CDC` |
| 9 | `$348F` | `$3BB2` | 19 | `$425F` | `$4272` |

---------------------------------------------------------------------------------------------

## 3. Actor sprites (Bruce Lee, Yamo, Ninja)

Hardware sprites, **hi-res (1 bit per pixel), X-expanded, not multicolour, not Y-expanded**
(`$D01D=$FF`, `$D01C=0` at `$07EF-$07FA`). Built every frame by `$2584` into the 10 VIC blocks
`$8180-$83FF` (block addresses at `$274F`, pointers at `$8FF8`).

### 3.1 Frame tables (210 frames, index f = 0..209)
| table | address | size | meaning |
|---|---|---|---|
| source lo | `$59BD` | 210 | |
| source hi | `$5A8F` | 210 | `src = lo | hi<<8`; 0 = no graphics |
| height    | `$5B61` | 210 | `h` |
| colour    | `$5C33` | 140 | `$D027` value (low nibble) for f < 140; f >= 140 read on into the next table |
| wide flag | `$5CBF` | 210 | 0 = 8 pixels wide, non-zero (`1` or `$55`) = 16 pixels wide |

Graphics `$5D91-$68F8`. Frames overlap (shared rows). `$63C1-$63EA` is graphics no frame references.

Layout of one frame:
- narrow (flag 0): `h+1` rows of 1 byte; row r = `src[r]`.
- wide (flag != 0): `h` rows of 2 bytes; row r = `src[2r]`, `src[2r+1]` (left, right).
Bit 7 = leftmost pixel, set bit = sprite colour, clear = transparent. Rows start at the sprite's top
(VIC sprite row 0); unused rows are cleared. Each pixel is 2 screen pixels wide.

### 3.2 Frames are pairs of layers
An actor's displayed frame is the pair (f, f+1), f even, drawn as two sprites at the same position
(`$2584`): layer A = frame f, layer B = frame f+1 (skipped for actor slot 2 and when f+1 has source 0).
Example Bruce: layer A yellow (colour 7) body, layer B black (0) details.
Position rules (`$25F5`, `$2636`): Y = `$A1,x`+`$1D`; X = 2*`$9E,x`; layer A moves 16 pixels left when it is
wide and the facing `$A4,x` != 1; layer B moves 16 pixels left when its relative frame `$4F4B,x` is
5, $19, $3F or $43.

| frames | actor type (`$95,x` bits 6-7) | base `$59A5` | VIC sprites (`$59A8`/`$59AB`) | colours |
|---|---|---|---|---|
| 0-69    | 0 Bruce Lee | 0   | 4, 5 | A=yellow, B=black |
| 70-139  | 2 Yamo      | 70  | 6, 7 | A=green ($F5), B=black |
| 140-209 | 1 Ninja     | 140 | 3, none | black ($F0 forced for actor slot 2 at `$2734`); odd frames are empty |

Actor frame = base[type] + relative frame (`$4F48,x`), stored in `$4F4E,x` (A) and `$4F51,x` (B) by `$29A1`.
Both facing directions are stored as separate frames; nothing is mirrored at run time.

Decoder:
```
def frame(f):
    src = IMG[0x59BD+f] | IMG[0x5A8F+f]<<8; h = IMG[0x5B61+f]
    if src == 0: return []
    if IMG[0x5CBF+f] == 0: return [[IMG[src+r]] for r in range(h+1)]
    return [[IMG[src+2*r], IMG[src+2*r+1]] for r in range(h)]
colour(f) = IMG[0x5C33+f] & 15   (f < 140)
```

---------------------------------------------------------------------------------------------

## 4. Collision masks (run time, derived from the frames)

`$512F` (init) builds one 96-byte mask per even frame: destination `$1167+f` (lo) / `$1239+f` (hi),
inside `$9000-$9FBF` and `$C000-$CADF` (42 + 29 masks, `$60` apart; several frames share a mask).
Mask = 3 columns x 32 bytes (column k at dest+32k), row r of the frame in byte r:
column 0 = high nibble of the first row byte, column 1 = low nibble, each bit doubled to `%11`
(char multicolour pixel pairs); column 2 is always 0 (the routine expands the already emptied `$1F`
for the second byte of wide frames). Rows `0..h` are used (wide frames read 2 bytes per row).
Mask(f) = mask_bits(f) OR mask_bits(f+1) (f+1 built in `$CAE0` first, skipped when its dest hi byte is 0).

`$5212` per frame: shifts the actor's mask into `$CAE0-$CB5F` (4 columns x 32 rows) to the actor's fine
X (`$1B` = (X-12)&3) and Y (`$1C` = (Y-29)&7), ANDs it with the bitmaps of the 3x4 chars under the actor and
sets contact bits: `$B6,x` (21 rows) and `$A7,x` (first 15 rows): bit0 = colour-1 pixels touched,
bit1 = colour-2, bit2 = colour-3 in cells with room colour, bit3 = colour-3 in cells whose colour RAM
has bits 0-2 clear (map cells with bit 7). Row tables: `$50E7` screen lo, `$50FF` screen hi, `$5117` colour RAM hi
(24 entries, index i = screen row i+1).

---------------------------------------------------------------------------------------------

## 5. Title screen

- Big font: `$8400-$87FF` = chars `$80-$FF` of the charset at `$8000` (`$D018=$30` at `$1544`), multicolour.
  Shown only by the VIC (no CPU reads).
- Text rows (40 screen codes each, written with `|$80` to the screen):
  `$4A0D` -> row 2 "DATASOFT PRESENTS", `$49BD`/`$49E5` -> rows 5/6 "BRUCE LEE" (double height),
  `$4A35` -> row 9 "BY RON J FORTIER". Fill char `$5C` (blank).
  Single-height letter = chars n, n+1 side by side. Double-height letter = n (top left), n+2 (top right),
  n+1 (bottom left), n+3 (bottom right).
- "PLAYER n" banner: `$4A5D` (16 codes, top), `$4A6D` (16, bottom); the player digit is patched from
  `$4A7D+2p` (top) / `$4A81+2p` (bottom) into `$4A6B` / `$4A7B`.
- The rest of the title uses the char ROM copy at `$8800` (`$D018=$32/$33`).

---------------------------------------------------------------------------------------------

## 6. Run-time areas

| range | content | written by |
|---|---|---|
| `$8180-$83FF` | 10 sprite blocks | cleared `$07C2`, built `$26A0` |
| `$8800-$8BFF` | char ROM copy + inverted copy (status line / title text) | `$044C-$0474` |
| `$8C00-$8FE7` | screen; `$8FF8-$8FFF` sprite pointers | |
| `$9000-$9FBF` | collision masks (over the charset source) | `$512F` |
| `$A000-$BFFF` | 4 expanded room charsets | `$4892` x4 |
| `$C000-$CADF` | collision masks | `$512F` |
| `$CAE0-$CB66` | mask work buffer | `$512F`, `$52AD` |

`$A000-$A9FF` image bytes are crack-mover leftovers; verified overwritten before any read.

## 7. Leftovers (not game data)
- `$5900-$59A4`: Apple II Merlin assembler source text ("DFB $F0,$C0..", "* CHAR 97"), ASCII with bit 7 set.
- `$572D-$58FF`: copy of `$4CF2-$4EC4`. `$4FE8-$50E6`: copy of `$482C-$492A`.
- `$4CBA-$4CCD`, `$59B3-$59BC`: unreferenced bytes.
