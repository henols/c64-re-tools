
## Sound and music data formats ($E000-$F5FF, under the KERNAL) — agent G

Two independent drivers live here, both write the SID directly, no zero page except the SFX stream pointers.

### 1. Music player: "MICROPEARL MUSIC PLAYER COPYRIGHT 1983 JOHN A. FITZPATRICK" (text at $E315)

API (jump table $E000):
- `$E000` JMP $E300 -> $E434: stop music, clear flags, zero SID $D400-$D417.
  The game writes `$E30A`=1 before some of these calls ($0547, $0726); this has no effect, the stop clears $E30A.
- `$E003` JMP $E306 -> $E479: start the song list at `$E870 + [$E86D]`. The game ($06CB) writes $E314=3, $E870=$00, $E871=$FF first
  (= play tune 0 and loop it). Done on the title screen every 5th time ($09BB countdown), only when sound is on ($1385=0).
- `$E006` JMP $E49E: per-frame update, called from the raster IRQ at $154D.
- Internal: `$E303` JMP $E352 = start tune `$E309`.

Tune table `$E8C0`, 8 bytes per tune: voice1 ptr, voice2 ptr, voice3 ptr, instrument table ptr (not read).
`$E86B` = highest tune number (1; tune 1 entry at $E8C8 holds stale pointers $EAB3/$EB60/$EC14). Only tune 0 is used:
voice 1 `$E8D0-$E97C`, voice 2 `$E97D-$EA30`, voice 3 `$EA31-$EAAC` (title theme, E minor, tempo 2 frames/tick).

Song list `$E870`: one byte per entry: bit7 = end of list; bit6 set = set transpose `$E100` = bits0-5; else tune number (bits 0-5).
End-of-tune action `$E314`: 0 stop; bit7 play tune (bits0-6); bit1 continue song list; else next tune number; bit0 = wrap/restart at the end.

Voice stream (one per voice, read byte by byte with a one-byte lookahead in `$E130`):
- `$00` rest, `$01-$7F` note (semitone index into `$E200/$E254`, 1 = C1 ... 82 = A7; NTSC values). The note plays with the
  current length/articulation/instrument; `$E100` transpose is added.
- Command bytes ($80-$FF) are applied when read; they affect the following notes. Commands before the first note are read at tune init.
  - `$8n` / `$Fn` (n<$F): note length index n -> `$E6F9 + n (+16 when long table)`; gate time and release time by articulation.
  - `$9n`: master volume n (written to $D418 together with the filter mode at the next note of this voice).
  - `$A0-$A3`: waveform tri $11 / saw $21 / pulse $41 / noise $81 (`$E71C`). `$AB`: $51 pulse+tri.
  - `$A4-$A6`: articulation 0 (gate 7/8 of length), 1 (gate 1/2), 2 (gate length-1, release 1 tick); selects the
    matching AD/SR pair from the voice's 6-byte set at `$E11C + voice*6`.
  - `$A7`/`$A8`: tie on/off (tie = no gate-off and no ADSR/gate rewrite at the next note).
  - `$A9`/`$AA`: ring modulation on/off (control bit 2).
  - `$AC`/`$AD` (also $AE/$AF): length table short/long (`$E2E7`, global).
  - `$Bn`: instrument n -> copy 6 bytes (AD/SR for articulations 0,1,2) from `$E80A + n*8` into the voice set.
  - `$C0 lo hi`: pulse width.
  - `$Dn xx`: filter preset n: `$E84A + n*4` = cutoff lo, cutoff hi, resonance nibble (ORed with xx -> $D417), mode bits (-> $D418 high nibble). Not used by the tune.
  - `$E0 nn`: tempo nn frames per tick.
  - `$FF`: end of tune (`$E30E`=$FF), then the end action.
- Length table `$E6F9` (ticks): short `20 10 08 04 02 01 08 08 30 18 0c 06 03 02 08 08`, long `40 20 10 08 04 02 08 08 60 30 18 0c 06 04 08 08`
  (index 0 whole, 1 half, 2 quarter, 3 eighth, 4 16th, 5 32nd, 8-13 dotted).
- Per-voice workspace `$E100-$E12D` is reset from the template `$E2A8-$E2D5` at tune start:
  $E100 transpose, $E101-3 tie, $E104-6 tick counter, $E107-9 release end (negative), $E10A-C gate ticks, $E10D-F release ticks,
  $E110-2 AD, $E113-5 SR, $E116-8 control, $E119-B articulation, $E11C-$E12D AD/SR sets. $E12E current voice, $E12F tempo counter.
- Voice stream pointers are the operands of self-modified `LDA abs` at $E3DE/$E3E2/$E3E6 (pointers at $E3DF/$E3E3/$E3E7).

### 2. Sound effect players (one per SID voice)

Request: game routine `$2509` with Y = $80 + effect number; it stores Y into the first free state byte `$EB00` (voice 1), `$EF70` (voice 2),
`$F070` (voice 3), or replaces a lower-priority effect (priority table `$2572`). The players `$EB03`, `$EF73`, `$F073` run once per frame from `$15A8`.

Per voice: state (`$EB00`: bit7 = start effect bits0-6, 1 = playing, 0 = idle), stream index (`$EB01`), wait frames (`$EB02`),
stream pointer in zero page (`$F6/$F7`, `$F8/$F9`, `$FA/$FB`). Same layout at $EF70 and $F070.

Effect table `$EBE5`: 15 little-endian stream addresses (effects 0-14, streams `$EC31-$EE82`).
Stream = records, first byte = opcode (dispatch via offsets `$EC03`):

| op | bytes | meaning |
|---|---|---|
| 0 | `00` | end: frequency 0, state 0 |
| 1 | `01 w n` | wait w frames, note n (freq from $E200/$E254) |
| 2 | `02 w n c` | + control register c |
| 3 | `03 w n a c` | + AD/SR from `$EC11 + a` (a = byte offset) |
| 4 | `04 w n a p c` | + pulse width from `$EC1B + p` (lo, hi; p = byte offset) |
| 5, 6 | `0x w n p c` | note, pulse, control |
| 7 | `07 c` | control only, no new wait (not used) |

On start the voice control is set to 0 and the first record runs in the same frame. Notes $53-$55 index past the 83-entry
frequency table and give a near-zero frequency. ADSR offsets $0A/$0C read into the pulse table (shared byte array $EC11-$EC30).
Effects 3 and 8 have no caller; 11 and 14 callers exist ($3E0D, $2FEC) but were not reached in the recorded runs.

### 3. Demo input stream `$F300`

Not sound: in demo mode `$179E` reads one byte per frame via ($1D) (= $F300 from $0570/$074F): low nibble -> $98 joystick bits,
high nibble -> $9B fire. The recorded runs read $F300-$F538. The bytes have the shape of (note, length) pairs of another
music format (same pattern also at $F200-$F27F), so the demo input is reused leftover data.
