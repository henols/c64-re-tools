# Bruce Lee (Datasoft 1984, REV.2 by Ron J Fortier) — shared context for naming agents

Project folder: /workspaces/c64_games/bruce_lee (run every script from there).
Skills: /workspaces/c64_games/.claude/skills/<skill>/SKILL.md — read c64-knowledge/SKILL.md before writing a batch.

## What we have
- `unpacked/image.bin` — 64 KiB RAM at the game entry `$0400` (crack and mover already gone from the segments).
- `unpacked/image.json` — segments: $033C-$A9FF, $CF00-$CFFF, $E000-$F5FF, $FE00-$FFFF.
- `unpacked/entry_state.json` — zero page, stack, pages 2-3, I/O at the entry.
- `src/segment_*.asm` — generated ACME source (current knowledge). `; not executed` marks code no run reached.
- `analysis/game.lst` — DXA listing (raw). `analysis/instructions.json` — every instruction, with `executed`.
- `.c64-re-tools/local/cov_all.bin` — OR of all coverage maps (bit0 RAM read, bit1 RAM write, bit2 RAM execute).
- `runs/rooms/roomNN.png` — screenshot of each of the 20 rooms (0-19); `runs/modes/*.png` — title, 2-player, pause, version line, etc.
- Knowledge reads: `node ../.claude/skills/c64-knowledge/scripts/knowledge.ts at '$2100'` (also `symbols`, `regions`, `references --start --end`).

## Established facts (observed)
- Entry `$0400`: SEI/CLD/TXS; if `$03FF`!=0 jump to `$04D1` (warm restart). Fills `$0200-$02FF` with SID voice-3 noise (random table).
  `JSR $0080` — `$0080` holds RTS ($60) put there by the crack (originally probably the disk protection check).
  Copies char ROM `$D000-$D1FF` to `$8800-$89FF` and an inverted copy to `$8A00-$8BFF` (title font).
  Calls `$4892` four times with ($04/$05)=src, ($06/$07),($08/$09)=dst, `$F3`=$7F: expands `$9000-$9FFF` into charsets `$A000-$BFFF`.
  `$050F` = (re)start to title; `$0531` = start of demo (attract) mode; `$0584` = game start.
- Memory config: `$01`=$35 in game (RAM under KERNAL). IRQ vector `$FFFE`=$1103, NMI/RESET `$FFFA/$FFFC`=$1116.
- VIC bank 2 (`$DD00`=$C1): screen `$8C00`, sprite pointers `$8FF8-$8FFF`, sprite data built at `$8180-$83FF`.
  In game: multicolor text, charset `$A000` ($D018=$39). Title: charset `$8800` ($D018=$33).
- `$29` = current room number (0-19). `$09BC` draws a room; colour table `$47A0,x` (20 entries).
  Room exits: at `$2F80` x=exit index; `$4B9A,x` = destination room, `$4C76,x`/`$4C8A,x` = entry x/y; stored to `$29` at `$2FA1`.
  Room 11 has a special case (`$09F6`). Room 19 is the final "CONGRATULATIONS" room.
- Keyboard: `$1386` init, `$139E` scan (matrix) -> `$0109` = key code (bit7=shift), `$010C`=1 key pending.
  `$010E` selects the scan mode (0 title: full matrix via `$142C`; 1 game: only a few keys via `$1462` and table `$1488`).
  Title loop `$08B1`: countdown `$49/$4A` -> demo `$0531`; keys F7($03)=start, F3($05)->`$092C` toggles `$42C9` (1/2 players),
  F5($06)->`$0908` toggles `$42CA` (computer/human opponent). L($2A)/Shift-L($AA)/R($11)/Shift-R($91) at `$0956`
  set `$1383`/`$1384` = left/right-handed joystick mode for joystick 1/2 (messages 8,9,10,13). Port-1 fire also starts.
  `$094B` waits for fire release (port 1 & 2).
  In game `$1B29`: F1($04)=restart to title, S($0D)=toggle sound `$1385`, SPACE($3C)=pause (`$1A22`), V($1F)=toggle
  version line "BRUCE LEE (C) 1984 DATASOFT REV.2 BY RJF" (text at `$4707`) in the top line `$8C00`.
- Player 1 joystick is port 1 (`$DC01`), player 2 port 2: `$1A14` uses `$DC00 + ((player^1)&1)`; `$03` = current player.
- `$17E2` prints message A at column X(?)/row Y via pointer table `$43BE` (text in screen codes +$20, $A0 ends);
  messages: 4 CONGRATULATIONS, 8-10,13 joystick handedness, 11 PAUSED.
- `$0101-$0103`: countdown timers for the flicker of lights (`$40BC`), they use random `$1159`.
- Falls counter decrements on death (game shows FALLS 04 -> 03). Score shown top line.
- `$A000-$CB7F` and `$8800-$9FBF` are written at run time (charsets, screen, buffers).
- `$5900-$817F` is read-only data (about 10 KB): graphics and room data sources.
- `$E000-$F13F` code + `$F300-$F53F` data under the KERNAL: likely sound/music; `$EB00`, `$EF70`, `$F070` zeroed at init.

## Rules for the batch you write
- Do NOT apply anything to the knowledge. Do NOT use the live emulator (c64_* MCP tools) or run.ts/test.ts/unpack.ts — another agent owns the emulator. Static analysis only (read listing, image, coverage, screenshots, knowledge reads).
- Write your result as a JSON list of knowledge ops (format in c64-knowledge/SKILL.md: rename, classify, comment, module, operand, reference) to the file named in your task.
- Names: lower_snake_case, descriptive, unique; prefix nothing with `l_` or `l` + hex. Kinds: routine for JSR/JMP targets that start a routine, label for branch targets inside a routine (only name labels that matter), variable for RAM variables, data for tables.
- Give every routine you name a `line` comment (one or two sentences: what it does, inputs/outputs). No confidence words ("probably", "maybe") in comment text — if you are not sure, do not write it; put it in your report instead.
- Classify data regions with the right type (bytes/words/petscii/screen/sprite/bitmap/addresses/addresses-split/rts-addresses/jumps/workspace/unused). Use `--element` style field `element` for tables of records. Workspace = RAM whose image bytes don't matter.
- Operand expressions: for immediate pairs that build an address of something in the image (lda #<x / lda #>x, pointer setups), add `operand` ops (select lo/hi with symbol). Only if you name the target symbol in the same batch or it already has a name.
- Zero-page and other global variables shared with other areas: put them in the batch too, but also list them separately in your final report so the coordinator can merge names.
- Flag anything that looks like a cheat/trainer, crack patch or copy protection remnant (with address and evidence) in your report.
- Report at the end: summary of the area (what it does), the batch path, number of ops, open questions, and any memory format you discovered (graphics, sprites, maps, music) with exact addresses and layout.
