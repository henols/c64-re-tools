# Bruce Lee: reverse engineering report

**Subject:** `original/saeger.d64`. It holds one file, `BRUCE LEE` (186 blocks), the October 1984 crack ("SSG") of *Bruce Lee*, Datasoft 1984. The game identifies itself as "REV.2 BY RJF" (Ron J. Fortier).

**Result:** the clean game without the cracktro and without the crack's mover.
- **Source:** ACME source in [src/](src/), with 63 module files.
- **Program:** a runnable program `build/bruce_lee.prg`, built by [tools/build.sh](tools/build.sh).
- **Room documentation:** how the rooms are stored, generated and run, in [docs/rooms.md](docs/rooms.md) and its four parts.
- **Assets:** the graphics, maps, tables, texts and sound are extracted into [assets/](assets/) by [tools/extract_assets.py](tools/extract_assets.py).

## 1. Acceptance

| Criterion (stage 1) | Result |
|---|---|
| **Identical source.** The generated source assembles byte for byte to the unpacked game. | **Met.** c64-source `check.identical` is true for all segments of both `unpacked/image.json` and `unpacked/clean/image.json`. c64-assembler `--compare unpacked/clean/image.json` reports `identical` for `build/game.prg`. |
| **Verified loader.** The clean program starts the game in the captured entry state. | **Met, with exception E2.** In `runs/loader_verify`, `build/bruce_lee.prg` was run to `$0400` and its RAM compared byte by byte with the image and pages 0-3 of `entry_state.json`. One byte differs: `$01F6`, the loader's documented stack byte. The registers are equal. The VIC registers are equal except the live raster counter (`$D012` reads `$FA`, the entry state has `$F9`, one line apart). CIA 2 is equal. CIA 1 differs only in the interrupt flag (`$81` at the entry), which c64-source lists as a limit: only an event sets a flag. |
| **Passed c64-testing scenarios.** Original against the rebuild. | **Met.** 10 of 10 PASS: `title`, `title_options`, `game_start`, `walk_right`, `demo`, `room05`, `room11`, `room18`, `room19`, `game_over` (in [tests/](tests/)). |
| **Assets documented and extracted:** jump tables, graphics, sprites, maps and other data. | **Met.** `tools/extract_assets.py` writes 72 files: rooms, charsets, sprites, fonts, texts, jump and dispatch tables, room tables, music, sound effects and demo input. Section 6. |
| **Cheats** (added during the work): keep any cheats and add a switch that disables them. | **No cheat or trainer exists in this release.** Seven area analyses checked all the code. Falls are decremented only at `$1826` (`lose_fall`), and nothing skips it. Nothing was added, so no switch was needed (exception E3). |

### Exceptions

**E1. The clean image drops two crack leftovers.**

`unpacked/clean/image.json` is the captured image without:
- `$A000-$A9FF`: bytes the mover left behind. The game overwrites them before it reads them. Evidence: `runs/a000_zero` and `runs/a000_orig` have identical memory at `$8000-$8FFF` and `$A000-$CBFF`.
- `$FE00-$FFF9`: the crack's loader code. Coverage shows it is never read or executed.

The full capture `unpacked/image.json` still exists, and the source generated from it is also identical.

**E2. Hand fix of the generated loader.**

`src/loader.asm` (c64-source) copies its copier from the end of the PRG. Because the program is about 46 KB, that end lies above `$A000`, and with BASIC ROM banked in the stub copied ROM bytes. The c64-source verification therefore stopped at `$E5CD`.

`tools/build.sh` assembles a copy of `src/loader.asm` with two added instructions, `lda #$34 / sta $01`, before the copy. `src/` stays as c64-source generated it.

This looks like a defect in c64-source: its loader stub assumes the PRG ends below `$A000`.

**E3. No cheat switch.** There are no cheats to switch off. The protection checks listed in section 5 are not cheats; they are left as they are.

### What "removed" means here

- **Cracktro:** `$0871` prints "CRACKED IN OKTOBER 1984 BY … SSG" and `$08F0` waits for SPACE. It is not in the rebuild.
- **Mover / "cruncher":** `$0821` and the code it copies to `$C000` move the game from `$0900-$AEFF` to `$0400-$A9FF` and set up the entry state. They are not in the rebuild.
- **Not compressed:** c64-unpacker `inspect` found no compressed data (entropy median 5.29, no high-entropy blocks). The only "cruncher" is this mover.
- **Crack changes kept:** the crack's changes to the machine state stay, because the game needs them:
  - `$0080` = RTS. It replaces the original protection routine, which `cold_start` calls.
  - `$00` = `$EF` and `$02` = `$32`. The protection checks test these values.
  - The vectors at `$0302` and `$0318`.

  The rebuild's loader sets all of these from `entry_state.json`.

## 2. The program

**What it is.** *Bruce Lee* is a single-load game. Bruce moves through 20 rooms (`current_room` `$29`), collects lanterns, and fights the Ninja and the Yamo. A human can play the Yamo, with a joystick in port 2. Room 18 holds the wizard, and room 19 is the "CONGRATULATIONS" room.

**Structure (observed):**
- **Start:** `cold_start` `$0400` builds the random table, the title font and the four room charsets. It then goes to the title screen `$0584` through `restart_to_title` `$050F`.
- **Title:** `title_menu_loop` `$08B1` reads these inputs:

  | Input | Effect |
  |---|---|
  | F3 | 1 or 2 players |
  | F5 | Computer or human opponent |
  | F7, or port-1 fire | Start (`start_game` `$070E`) |
  | L, Shift-L, R, Shift-R | Left- or right-handed joysticks |

  After a timeout the title starts the demo, `start_demo` `$0531`.
- **Main loop:** `main_loop` `$1BC2` runs every 3 frames. It handles keys and pause, the light flicker, enemy spawning, the room script, the actor collisions and the actor input, and draws the sprites.
- **Raster IRQs:** the IRQ at `$1103` jumps through `irq_chain_vector` (`$0408`) into a chain of raster IRQs: `$48C1`, `$491E` and `$4982` in game, `$152C` and `$1574` on the title. Each frame they set the charset, the colour bands, the status line and the sound.
- **Sound:** the music is the *MicroPearl Music Player*, (C) 1983 John A. Fitzpatrick, at `$E000`, playing one title tune. Sound effects are played by one player per SID voice, at `$EB03`, `$EF73` and `$F073`.
- **Graphics:**
  - The rooms are RLE-coded tile maps (`$68F9-$817F`), drawn in multicolour text mode with 8x16 tiles.
  - The actors are hi-res X-expanded sprites built each frame from 210 one-bit frames (`$5D91-$68F8`).
  - Collisions are tested against 96-byte pixel masks built at start.
- **In-game keys:** F1 restarts, S toggles the sound, SPACE pauses, and V toggles the version line.

**Conclusions** (from the code; not every one is shown by a run):
- The demo is deterministic, because `random_byte` returns 1 in demo mode.
- After 128×256 idle frames the game pauses itself and starts a colour-cycling screen saver.

## 3. Modules

| File | Range | Title |
|---|---|---|
| casbuf.asm | $033C-$03FF | Cassette buffer: saved lantern flags |
| init.asm | $0400-$050E | Cold start and one-time initialisation |
| restart.asm | $050F-$0583 | Restart to title and demo start |
| title.asm | $0584-$0762 | Title screen and game start |
| game_setup.asm | $0763-$08B0 | Game screen and interrupt setup |
| title_menu.asm | $08B1-$09BB | Title menu input loop |
| room_draw.asm | $09BC-$0B8D | Room drawing |
| actors.asm | $0B8E-$0E2D | Actor set-up and enemy spawning |
| title_options.asm | $0E2E-$0EA6 | Title sprite and option highlights |
| player_turn.asm | $0EA7-$0F71 | Player turn screen |
| game_vars.asm | $0F72-$102A | Game variables and player swap |
| room_state.asm | $102B-$1102 | Colour save/restore, cycling objects, small helpers |
| interrupts.asm | $1103-$1165 | IRQ entry, NMI/RESET stub, sprite buffer clears, random numbers |
| actor_room_tables.asm | $1166-$1385 | Protection key, actor frame address tables, per-room enemy tables, options |
| keyboard.asm | $1386-$14A3 | Keyboard scanner |
| raster_irq_screens.asm | $14A4-$15A7 | Raster IRQs of the player-up and title / game-over screens |
| frame_update.asm | $15A8-$179D | Per-frame work: sound, timers, joysticks, screen saver, protection checks |
| actor_input.asm | $179E-$17E1 | Actor input (demo stream or joystick) |
| text.asm | $17E2-$1817 | Double-height message printer |
| game_over.asm | $1818-$199E | Loss of a fall, change of player, game over |
| status.asm | $199F-$1BC1 | Status line, pause, demo exit, game keys |
| main_loop.asm | $1BC2-$1C38 | Main game loop |
| actor_movement.asm | $1C39-$2007 | Actor movement and action selection |
| object_actions.asm | $2008-$2508 | Action state machine: jumps, kicks, punches, climbing, enemy states |
| sound_effects.asm | $2509-$2583 | Sound effect start and channel allocation |
| sprite_render.asm | $2584-$277F | Sprite rendering into double-buffered blocks, sprite registers |
| object_pose.asm | $2780-$29C2 | Animation pose selection |
| combat_hits.asm | $29C3-$2C6F | Sprite collision, hits, damage, knock-out |
| animated_chars.asm | $2C70-$2D54 | Moving climbing-texture characters |
| actor_checks.asm | $2D55-$2E38 | Knock-out check, enemy AI wake-up, distance and facing helpers |
| background_touch.asm | $2E39-$312B | Contact with background chars: exits, lanterns, deadly chars, traps, room change |
| score.asm | $312C-$3216 | Score, extra falls, high score |
| room_entry_traps.asm | $3217-$32DB | Respawn into a room and floor trap animation |
| score_bcd_regsave.asm | $32DC-$331B | Score to BCD, register save/restore |
| lanterns.asm | $331C-$33F4 | Lantern lists |
| room_init.asm | $33F5-$3641 | Per-room init handlers |
| room_update.asm | $3642-$404D | Per-room frame handlers (rooms 0-18) and passage drawing |
| room_tiles.asm | $404E-$40BB | Sliding tiles and travelling hazards |
| light_flicker.asm | $40BC-$4132 | Flickering lights in the charsets |
| fireballs.asm | $4133-$424E | Room 18 wizard fireballs |
| final_room.asm | $424F-$42C4 | Sound helper and room 19 |
| variables.asm | $42C5-$43BD | Game variables and small tables |
| messages.asm | $43BE-$4785 | Message pointer table and texts |
| pointer_helpers.asm | $4786-$479A | 16-bit pointer increment helpers |
| room_colours.asm | $479B-$480A | VIC start colours, room colours, raster band colours |
| room_split_tables.asm | $480B-$485A | Room colour-split and raster-line pointer tables |
| charset_expand.asm | $485B-$48C0 | Room-draw row advance and charset expander |
| raster_irq_game.asm | $48C1-$49BC | Game raster IRQ chain |
| room_tables.asm | $49BD-$4EEB | Title text, room exits, spawns, lanterns, room handler tables |
| actor_vars.asm | $4EEC-$50E6 | Actor, collision and tile animation variables |
| collision.asm | $50E7-$58FF | Collision masks and actor-background pixel collision |
| sprite_data.asm | $5900-$68F8 | Actor frame tables and 1-bpp sprite graphics |
| room_maps.asm | $68F9-$817F | Room map streams (RLE) |
| vic_bank2.asm | $8180-$8FFF | VIC bank 2: sprite blocks, title font, screen |
| room_charset_src.asm | $9000-$9FFF | Room charset sources: 4 sets of 128 tiles |
| protection_signature.asm | $CF00-$CFFF | Disk protection signature bytes |
| music_player.asm | $E000-$E809 | MicroPearl music player |
| music_data.asm | $E80A-$EAFF | Music tables and the title tune |
| sfx_voice1.asm | $EB00-$EBE4 | Sound effect player, SID voice 1 |
| sfx_data.asm | $EBE5-$EF6F | Sound effect tables and streams |
| sfx_voice2.asm | $EF70-$F06F | Sound effect player, SID voice 2 |
| sfx_voice3.asm | $F070-$F2FF | Sound effect player, SID voice 3 |
| demo_input.asm | $F300-$F5FF | Demo-mode input stream |
| vectors.asm | $FFFA-$FFFF | CPU hardware vectors |

The knowledge also has `runtime_charsets.asm` at `$A000` and `crack_leftover_fe00.asm` at `$FE00`. They are used only for the full image `unpacked/image.json`.

## 4. Untested code

**Coverage:** 52 coverage files in `coverage/`. They come from:
- the title, title keys, demo, game, game over and F1 restart;
- all 20 rooms, entered by forcing the room number at `$2FA1`;
- two players;
- the room-event experiments of `docs/rooms.md`: every room entered with all lanterns taken, the wizard defeat, the room 11 diversion, the ending, and the texture logs.

**601 instructions in 121 ranges never ran** (down from 1189 before the room experiments). All ranges are in `src/not_executed.json`. Listed by file:

| File | Ranges (routine) | Why not executed |
|---|---|---|
| init.asm | $0412-$0414 (cold_start) | Warm start: `warm_start_flag` `$03FF` is never set. |
| title.asm | $06b2-$06b4, $06ba-$06bc, $06f3-$06f9 (title_screen) | Title music path (every 5th visit to the title); protection failure (memory wipe). |
| room_draw.asm | $0b47-$0b48 (inc_work_ptr_a) | Pointer increment carry. |
| actors.asm | $0d3a-$0d3b (try_spawn_yamo); $0d6f-$0d71, $0d96-$0d98 (reset_yamo_timer); $0df5-$0df6 (try_spawn_ninja) | Spawn-preference and room-timer branches not taken. |
| title_options.asm | $0e7d-$0e91 (toggle_players_highlight) | Highlight path not taken. |
| room_state.asm | $102b-$104a (save_raster_colours) | Screen saver (needs 128×256 idle frames). |
| interrupts.asm | $1110-$1112 (irq_handler); $1116 (nmi_reset_handler); $111d-$1130 (clear_sprite_blocks_6_7_11_12) | BRK path disabled by `AND #$00`; NMI not triggered; uncalled routine. |
| keyboard.asm | $13ae-$1487 (keyboard_scan) | The VICE in use (bug #2202) holds `$DC00`/`$DC01` bits low; keys were injected through `key_code`/`key_pending`. |
| frame_update.asm | $15f7-$15f8, $160f-$1610, $1634-$163e, $1643-$1644, $164d-$1652, $165b-$1669, $16b3-$16bc, $16ea-$16f3, $1709-$1716, $177f-$1780, $178f-$1790 (game_frame_update) | Screen saver, idle auto-pause, human Yamo handed back to the computer; protection failure loop. |
| text.asm | $180e-$1816 (print_message) | Message longer than 256 bytes: never happens. |
| game_over.asm | $1971-$1978 (game_over) | Two-player game-over branch. |
| status.asm | $19d1-$19ea (check_demo_exit); $1a35-$1a37 (toggle_pause); $1a52-$1a55 (clear_text_lines_from_2); $1ad1-$1aec (debug_print_values); $1afc-$1b01 (print_falls_count); $1b64 (handle_game_keys); $1b8e-$1b90, $1b9d-$1b9f (print_hex_byte) | Key-based demo exit, pause and print branches; `debug_print_values` is dead code behind an RTS. |
| actor_movement.asm | $1d63-$1d65, $1dad-$1db2 (actor_undo_moves); $1e17-$1e38 (actor_move_up); $1e49-$1e58 (actor_move_down); $1e80-$1e82 (actor_left_or_fire_move); $1ec1-$1ec3 (actor_right_or_fire_move); $1efa-$1f09, $1f33-$1f36, $1f64-$1f75 (actor_move_right); $1fd3-$1fe4, $1fea-$1ffe (play_sound_80_checked) | Movement edge cases (screen limits, ladders); protection traps that run only with a wrong signature. |
| object_actions.asm | $207c-$207f, $2082-$208c, $217d-$217f, $2194-$21a8, $21c5-$21cd, $21df-$21e4, $21f8-$2200, $221a-$2227, $2278-$2282 (continue_object_action); $22b2-$22b7, $22c7-$22c9, $2399-$239b (start_attack_recovery) | Action states not reached: some flying kicks, knocked back, some enemy states. |
| sound_effects.asm | $255d (play_sound_effect) | All channels busy. |
| object_pose.asm | $279c-$27a0, $27e4-$27f1, $28ef-$28f1 (select_object_pose) | Poses of states not reached. |
| combat_hits.asm | $2ace-$2acf, $2af4-$2af5, $2b37-$2b38 (check_sprite_collisions); $2b79-$2b7e, $2b90-$2b95, $2bbb-$2bc3, $2bdf-$2be7, $2c03-$2c0b, $2c2a-$2c46 (mark_hit_landed) | Bruce hitting and knocking out enemies (the runs had no real fighting). |
| actor_checks.asm | $2dd3-$2ddc (ai_wake_idle_enemies) | Enemy AI wake-up branch. |
| background_touch.asm | $2ef1-$2ef3, $2f00 (handle_touched_char); $2fd6-$3000 (room16_bonus_fall); $3051 (touch_deadly_char); $30b0-$30c7 (trigger_floor_trap); $30f7-$30fc, $3103-$3107 (check_exit_direction) | Room 16 bonus-fall object, floor-trap slot 2, exits at the top and bottom screen edges. |
| score.asm | $3146-$3159 (add_score_and_check_bonus); $3191-$31a3 (update_high_score) | Extra fall at 40000 points; protection trap in `update_high_score`. |
| lanterns.asm | $333e-$333f, $335a-$335b (collect_lantern_at) | Branches of the lantern search. |
| room_init.asm | $3553-$3554 (room13_init); $35c0-$35c2 (room16_init) | Room 13 floor bonus already used; room 16 bonus-fall object used up. |
| room_update.asm | $3caf-$3cbc (room10_update); $3cca-$3cd5 (room11_update); $3d28-$3d37 (room18_wizard_update); $3e87-$3ebb (room13_update); $3fa2-$3fa5, $3ff6-$4005, $4012-$4015, $4022-$402e, $4039-$4048 (room17_update) | Room 10 protection failure path (`$00`≠`$EF`); room 11 handler branches; a fireball hitting Bruce in room 18; room 13 floor bonus; room 17 events after its first pass (the PAL freeze bug stopped the room 17 runs, see `docs/rooms.md`). |
| fireballs.asm | $41b8-$41bc, $41cf-$41d3 (update_fireballs) | Fireball reaching its limit. |
| collision.asm | $535a-$535d (setup_char_row_test) | Edge row. |
| music_player.asm | $e368-$e36a (music_set_voice_ptrs); $e3fb-$e3fd (music_read_byte); $e43b-$e440, $e445-$e454, $e466-$e46f (music_end_of_tune); $e486-$e488 (music_start_song_list); $e4bb-$e4bd, $e4e9-$e4eb, $e523-$e525 (music_update); $e5f7-$e5f9 (music_read_command); $e677-$e680, $e69d-$e6b4 (music_cmd_misc); $e6e9-$e6f8 (music_calc_note_ticks); $e779-$e7b1 (music_cmd_filter) | Player features the title tune does not use (filter, tie, ring modulation, end of song list). |
| sfx_voice1.asm | $eb49-$eb4b, $eb4f-$eb51 (sfx_v1_update); $ebdd-$ebe4 (sfx_v1_op_ctrl) | Effect opcodes the effects that ran did not use. |
| sfx_voice2.asm | $efb9-$efbb, $efbf-$efc1 (sfx_v2_update); $f04d-$f054 (sfx_v2_op_ctrl) | As voice 1. |
| sfx_voice3.asm | $f0b9-$f0bb, $f0bf-$f0c1 (sfx_v3_update); $f14d-$f154 (sfx_v3_op_ctrl) | As voice 1. |

## 5. Open questions

**Protection (observed in the code; it passes in this release):**
- The game still holds several checks of the original disk protection. Each fails unless the right values are present:
  - the signature page at `$CF79-$CFB8` (checked at `$06DD`, `$0CD5`, `$1C13`, `$3189` and `$512F`);
  - `$00` = `$EF` (checked at `$166A`, `$36A6` and `$3CA7`);
  - `$02` = `$32` (checked at `$1703` and `$3428`).
- Some failures are delayed sabotage. They write `TXS` into `random_byte` or at `$1FFE`, wipe memory, or blank three room maps.
- **Kept as they are:** removing them would change the game code, and they pass in the rebuild.

**Possible crack patches inside the game code (not proven):**
- `$110C` `AND #$00` disables a BRK test in the IRQ entry.
- `init_hook_rts` `$10F7` is a bare RTS called from init, next to dead code.
- `dummy_table_read` `$0E2E` loads 5 bytes and discards them.

Without an uncracked original these cannot be told apart from the original game.

**Leftover data in the original file** (not crack bytes):
- Apple II assembler source text at `$5900-$59A4`.
- A copy of `$482C-$492A` at `$4FE8-$50E6`, and a copy of `$4CF2-$4EC4` at `$572D-$58FF`.
- Unreferenced texts (credits, "GAME OVER").
- Message 98, **"DIABOLO PRESENTS"** (`$4770`). Nothing prints it. It may be a crack-group text placed over an original string, or an original leftover; the evidence does not say which.

**PAL freeze bug of the original (observed, `runs/r17_freeze`):**
- `draw_room` changes `$D011` with read-modify-writes at `$09BC` and `$0B33`.
- A redraw that runs on raster lines 256-311 copies raster bit 8 into the raster compare.
- The pending IRQ line `$40` becomes `$140`, which PAL never reaches, and the game hangs in `main_loop_wait`.
- It was seen in room 17; the details are in `docs/rooms.md`.
- It is kept, because the rebuild must equal the original. A one-byte fix (`and #$6f` at `$09BF`, and an `and #$7f` before the store at `$0B38`) would go into a mod build.

**Original bugs (from the code, not shown by a run):**
- `$31B8` copies 4 bytes into `high_score`, so the 4th byte overwrites the first byte of `first_extra_life_score`.
- Rooms 4, 7, 10, 13, 17 and 18 encode 442 cells instead of 440, which writes 2 bytes into collision mask 0.
- `$3175` (add score) does not keep X, which its callers at `$2BBF`, `$2BE3` and `$2C07` rely on.

**Unknown meaning:**
- The game meaning of a few actor states and contact bits (`$B6`).
- `room_timer` `$88` thresholds.
- What reads `$4326-$432D`, `$E007-$E02D` and `$10F8-$1130`: coverage shows reads, but no code was found that does them.

**Character identities:** actor 1 = Yamo and actor 2 = Ninja. This rests on the colours and on the opponent option. It was not confirmed by a run.

## 6. Assets

Run `python3 -I tools/extract_assets.py` to write 72 files to [assets/](assets/). The run is deterministic. [assets/README.md](assets/README.md) is the index and gives the formats.

| Folder | Content |
|---|---|
| `rooms/` | All 20 rooms as PNG (320×176), rendered from the RLE maps, the room charsets, the raster colour bands and colour RAM. Each room also has a JSON file with the decoded 40×11 cell map, charset, colours, exits, spawns, enemy delays, lantern records and handlers. |
| `charsets/` | The 4 room charset sources (128 tiles of 8×16 multicolour) as PNG and raw `.bin`. |
| `sprites/` | Sheets for Bruce, Yamo and Ninja (70 frames each, and the layer pairs composed as the game draws them); `frames.json` with all 210 frames; the TM sprite. |
| `fonts/` | The big title font (`$8400-$87FF`) and the title layout. |
| `text/messages.json` | All 101 messages of the message table, the version line, and the unreferenced and leftover texts. |
| `tables/` | `jump_tables.json`: every address, RTS-address and jump table in the knowledge. `room_handlers.json`: the room init and frame dispatch tables. `irq_chain.json`, `room_tables.json`, and `actor_frame_addr.json` (the frame mask address tables). |
| `sound/` | `title_tune.json` (3 decoded voice streams), `sfx.json` (15 effects with their callers), and the raw player, tune and effect data. |
| `demo_input.*` | The 569-step demo input stream from `$F300`. |

**Check against the screenshots** (map area, `--check`):
- Rooms 0-3, 7, 10, 12-16 and 18 match at 98.6-99.7%.
- Rooms 4, 5, 6 and 19 match at 95-97%, and rooms 8, 9 and 11 at 86-92%.
- The remaining differences come from the running game: sprites, the lamp flicker, scrolling texture tiles, cells and colour RAM that the room scripts change, and lanterns already taken.
- Room 17: both screenshots happen to show the playfield with the status charset (`$D018=$32`). Its snapshot RAM drawn with the room charset matches at 99.3%. Why the screenshots show `$32` is open.

The extraction showed that the lantern record's row byte is a text row of `print_message`. The knowledge comment is now corrected.
